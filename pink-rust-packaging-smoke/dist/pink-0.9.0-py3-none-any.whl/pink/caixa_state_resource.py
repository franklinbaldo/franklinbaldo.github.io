"""Live Kanoê box-search Resource used to reconcile box creation."""

from __future__ import annotations

from base64 import urlsafe_b64decode, urlsafe_b64encode
from pydantic import Field, TypeAdapter

from pink.catalogo import Catalogo, Conteudo
from pink.domain_types import CaixaId, SetorId
from pink.models import (
    Desconhecido,
    Disponibilidade,
    Observacao,
    Observado,
    OperationHandle,
    PinkModel,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure

_SETOR_ID = TypeAdapter(SetorId)


class CaixaBuscaItem(PinkModel):
    """One live Kanoê box matched by an exact-name reconciliation search."""

    caixa_id: CaixaId = Field(description="Identidade da caixa observada")
    nome: str = Field(min_length=1, description="Nome da caixa observado no Kanoê")


class CaixaBuscaObservacao(PinkModel):
    """Live exact-name box search used to reconcile a submitted creation."""

    setor_id: SetorId = Field(description="Setor no qual a busca foi executada")
    nome: str = Field(min_length=1, description="Nome normalizado pesquisado no Kanoê")
    caixas: Observacao[tuple[CaixaBuscaItem, ...]] = Field(
        description=(
            "`observado` com as caixas de nome exato atualmente no setor (vazio é ausência "
            "observada); `desconhecido` quando a busca não pôde ser reobservada"
        )
    )


def caixa_busca_handle(setor_id: SetorId, nome: str) -> OperationHandle:
    """Build a deterministic Resource URI without leaking arbitrary text into URI syntax."""
    normalized = nome.strip().upper()
    token = urlsafe_b64encode(normalized.encode("utf-8")).decode("ascii").rstrip("=")
    return f"kanoe:caixa-busca:{setor_id}:{token}"


def _decode_name(token: str) -> str:
    padding = "=" * (-len(token) % 4)
    # Handle malformado é input inválido, não falha de observação: o remoto
    # nunca foi consultado. Anunciá-lo como observação falha convidaria o
    # agente a repetir o mesmo handle quebrado esperando outro resultado.
    decoded = urlsafe_b64decode(token + padding).decode("utf-8")
    if not decoded:
        raise ValueError("handle de busca de caixa sem nome")
    return decoded


async def _exigir_kanoe(kanoe) -> None:
    """Known unavailability is a reason for not knowing, raised where the read happens."""
    status = await kanoe.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        raise RemoteObservationFailure(status.detalhe or "Kanoê indisponível")


def build_caixa_state_resource_catalogo(runtime: Runtime) -> Catalogo:
    """Expose the exact live observation required after an uncertain box creation."""
    catalogo = Catalogo()
    kanoe = runtime.kanoe

    @catalogo.recurso(
        "kanoe:caixa-busca:{setor_id}:{nome_token}",
        mime="application/json",
        tags={"write-state", "read", "caixa", "kanoe"},
    )
    async def caixa_busca(setor_id: str, nome_token: str) -> Conteudo:
        identity = _SETOR_ID.validate_python(setor_id)
        nome = _decode_name(nome_token)
        try:
            await _exigir_kanoe(kanoe)
            boxes = await kanoe.find_boxes(nome, identity)
            caixas: Observacao[tuple[CaixaBuscaItem, ...]] = Observado[tuple[CaixaBuscaItem, ...]](
                valor=tuple(
                    CaixaBuscaItem(caixa_id=box.id, nome=box.nome)
                    for box in boxes
                    if box.nome.strip().upper() == nome
                )
            )
        except RemoteObservationFailure as exc:
            # Depois de um `caixa_criar` despachado, não conseguir buscar não é
            # "nenhuma caixa": é não saber, e o handle continua relegível.
            caixas = Desconhecido(motivo=str(exc))
        conteudo = CaixaBuscaObservacao(
            setor_id=identity, nome=nome, caixas=caixas
        ).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    return catalogo
