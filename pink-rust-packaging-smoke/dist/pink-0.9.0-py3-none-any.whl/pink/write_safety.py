"""Write-safety primitives shared by Pink 0.8 domain capabilities."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol, TypeVar

from pink.models import (
    Ambigua,
    Confirmada,
    Disponibilidade,
    EfeitoEscrita,
    IntegracaoStatus,
    OperationHandle,
    Recusada,
    Submetida,
)

T = TypeVar("T")


class AvailabilityProbe(Protocol):
    """Minimal availability surface needed before a remote write."""

    async def probe(self) -> IntegracaoStatus: ...


class RemoteWriteFailure(RuntimeError):
    """Transport failure with explicit knowledge about possible remote effect."""

    def __init__(self, message: str, *, effect_may_have_occurred: bool) -> None:
        super().__init__(message)
        self.effect_may_have_occurred = effect_may_have_occurred


class RemoteObservationFailure(RuntimeError):
    """A remote observation could not be completed reliably."""


class ConsultaSemCard(RemoteObservationFailure):
    """Native SQL was denied and this physical query has no saved equivalent."""


async def refuse_if_unavailable(
    integration: AvailabilityProbe,
    *,
    operacao: str,
    nome: str,
) -> Recusada | None:
    """Represent an unavailable integration as a typed no-dispatch write result."""
    status = await integration.probe()
    if status.estado is Disponibilidade.DISPONIVEL:
        return None
    return Recusada(
        operacao=operacao,
        motivo=status.detalhe or f"{nome} indisponível",
    )


async def observe_precondition(
    *,
    operacao: str,
    observe: Callable[[], Awaitable[T]],
) -> T | Recusada:
    """Observe a write precondition without letting a failed read trigger a blind write."""
    try:
        return await observe()
    except RemoteObservationFailure as exc:
        return Recusada(
            operacao=operacao,
            motivo=f"não foi possível observar a precondition da escrita: {exc}",
        )


async def write_and_confirm(
    *,
    operacao: str,
    recurso_id: int | str | None,
    write: Callable[[], Awaitable[None]],
    observe: Callable[[], Awaitable[T]],
    expected: T,
    handle: OperationHandle | None = None,
) -> EfeitoEscrita:
    """Dispatch once; distinguish uncertain dispatch from pending postcondition."""
    try:
        await write()
    except RemoteWriteFailure as exc:
        if not exc.effect_may_have_occurred:
            raise
        return Ambigua(
            operacao=operacao,
            handle=handle,
            detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
        )

    try:
        observed = await observe()
    except RemoteObservationFailure as exc:
        if handle is not None:
            return Submetida(
                operacao=operacao,
                handle=handle,
                detalhe=f"escrita aceita; a postcondition ainda não pôde ser observada: {exc}",
            )
        return Ambigua(
            operacao=operacao,
            detalhe=f"escrita aceita, mas a postcondition não pôde ser reobservada e não há handle: {exc}",
        )

    if observed != expected:
        if handle is not None:
            return Submetida(
                operacao=operacao,
                handle=handle,
                detalhe=(
                    "escrita aceita, mas a postcondition observada ainda diverge: "
                    f"esperado {expected!r}, observado {observed!r}"
                ),
            )
        return Ambigua(
            operacao=operacao,
            detalhe=f"postcondition divergente sem handle de reobservação: esperado {expected!r}, observado {observed!r}",
        )
    return Confirmada(operacao=operacao, recurso_id=recurso_id)
