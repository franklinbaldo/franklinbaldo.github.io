"""Documento writes and binary resources over a narrow semantic Kanoê boundary."""

from __future__ import annotations

from dataclasses import replace
from typing import Protocol, cast

from pydantic import TypeAdapter

from pink.catalogo import Catalogo, Conteudo, Efeito
from pink.artifacts import ArtifactStore
from pink.domain_types import ComponenteDigitalId, DocumentoId, FileArtifactUri, PastaId, TarefaId
from pink.integrations import Probe
from pink.models import (
    Ambigua,
    Confirmada,
    Disponibilidade,
    EfeitoEscrita,
    PinkModel,
    Recusada,
    Submetida,
)
from pink.queries_case import componente_mimetype
from pink.system import Runtime
from pink.write_safety import (
    RemoteObservationFailure,
    RemoteWriteFailure,
    observe_precondition,
    refuse_if_unavailable,
)

WRITE = Efeito(
    leitura=False,
    destrutivo=False,
    idempotente=False,
    mundo_aberto=True,
)
DESTRUCTIVE = replace(WRITE, destrutivo=True)
IDEMPOTENT_DESTRUCTIVE = replace(DESTRUCTIVE, idempotente=True)
_COMPONENT_ID = TypeAdapter(ComponenteDigitalId)


class KanoeDocumentoRef(PinkModel):
    """Minimal live document identity required for ownership/postcondition checks."""

    documento_id: DocumentoId


class DocumentoKanoe(Probe, Protocol):
    """Only the Kanoê behavior needed by document capabilities."""

    async def task_documents(self, tarefa_id: int) -> tuple[KanoeDocumentoRef, ...]: ...
    async def upload_document(
        self,
        *,
        pasta_id: int,
        tarefa_id: int,
        nome: str,
        mime_type: str,
        data: bytes,
    ) -> None: ...
    async def delete_document(self, documento_id: int) -> None: ...
    async def component_bytes(self, componente_id: int) -> bytes: ...


async def _require_read_available(kanoe: DocumentoKanoe) -> None:
    status = await kanoe.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        raise RemoteObservationFailure(status.detalhe or "Kanoê indisponível")


def build_documento_write_catalogo(runtime: Runtime) -> Catalogo:
    """Build document mutations that never accept arbitrary client filesystem paths."""
    catalogo = Catalogo()

    def get_kanoe() -> DocumentoKanoe:
        return cast(DocumentoKanoe, runtime.kanoe)

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="documento_enviar",
        tags={"documento", "write"},
        efeito=WRITE,
    )
    async def documento_enviar(
        pasta_id: PastaId,
        tarefa_id: TarefaId,
        arquivo_uri: FileArtifactUri,
    ) -> EfeitoEscrita:
        """Anexa um arquivo publicado por `arquivo_publicar`, identificado pela sua `pink://file` URI."""
        kanoe = get_kanoe()
        artifacts = get_artifacts()
        unavailable = await refuse_if_unavailable(kanoe, operacao="documento_enviar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        try:
            artifact, data = artifacts.file_from_uri(arquivo_uri)
        except (ValueError, FileNotFoundError) as exc:
            return Recusada(operacao="documento_enviar", motivo=str(exc))

        observed_before = await observe_precondition(
            operacao="documento_enviar",
            observe=lambda: kanoe.task_documents(tarefa_id),
        )
        if isinstance(observed_before, Recusada):
            return observed_before
        before = {item.documento_id for item in observed_before}
        handle = f"kanoe://tarefa/{tarefa_id}/documentos"

        try:
            await kanoe.upload_document(
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                nome=artifact.nome,
                mime_type=artifact.mime_type,
                data=data,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="documento_enviar",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha no upload: {exc}",
                )
            raise

        try:
            after = {item.documento_id for item in await kanoe.task_documents(tarefa_id)}
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="documento_enviar",
                handle=handle,
                detalhe=f"upload aceito; a lista de documentos não pôde ser reobservada: {exc}",
            )
        created = sorted(after - before)
        if len(created) == 1:
            return Confirmada(operacao="documento_enviar", recurso_id=created[0])
        if not created:
            return Submetida(
                operacao="documento_enviar",
                handle=handle,
                detalhe="upload aceito, mas nenhum documento novo apareceu ainda na tarefa",
            )
        return Ambigua(
            operacao="documento_enviar",
            handle=handle,
            detalhe=f"mais de um documento novo apareceu após o upload: {created!r}",
        )

    @catalogo.operacao(
        nome="documento_excluir",
        tags={"documento", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def documento_excluir(
        documento_id: DocumentoId,
        tarefa_id: TarefaId,
    ) -> EfeitoEscrita:
        """Exclui somente depois de provar que o documento pertence à tarefa informada."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="documento_excluir", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        observed_before = await observe_precondition(
            operacao="documento_excluir",
            observe=lambda: kanoe.task_documents(tarefa_id),
        )
        if isinstance(observed_before, Recusada):
            return observed_before
        before = {item.documento_id for item in observed_before}
        if documento_id not in before:
            return Recusada(
                operacao="documento_excluir",
                motivo=(
                    f"documento {documento_id} não pertence à tarefa {tarefa_id}; "
                    f"documentos observados={sorted(before)!r}"
                ),
            )
        handle = f"kanoe://tarefa/{tarefa_id}/documentos"
        try:
            await kanoe.delete_document(documento_id)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="documento_excluir",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após DELETE: {exc}",
                )
            raise
        try:
            after = {item.documento_id for item in await kanoe.task_documents(tarefa_id)}
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="documento_excluir",
                handle=handle,
                detalhe=f"DELETE aceito; a ausência não pôde ser reobservada: {exc}",
            )
        if documento_id not in after:
            return Confirmada(operacao="documento_excluir", recurso_id=documento_id)
        return Submetida(
            operacao="documento_excluir",
            handle=handle,
            detalhe="DELETE aceito, mas o documento ainda aparece na tarefa",
        )

    return catalogo


def build_documento_resource_catalogo(runtime: Runtime) -> Catalogo:
    """Expose Kanoê component bytes as Resources instead of a download tool."""
    catalogo = Catalogo()
    kanoe = cast(DocumentoKanoe, runtime.kanoe)
    metabase = runtime.metabase

    async def _mime_observado(component_id: int) -> str:
        """MIME que o Kanoê registrou para o componente, ou binário genérico.

        A mesma fonte que a URI anunciada por `documento_obter` aponta. O download
        do Kanoê devolve `binaryContent` e o nome do arquivo, sem MIME, então o
        tipo real só existe na metadata -- e sem consultá-la o link anunciaria
        PDF enquanto a leitura devolveria binário genérico, para o mesmo objeto.
        Octet-stream fica para quando o tipo é de fato desconhecido -- ou quando
        a metadata não pôde ser lida, porque os bytes vêm do Kanoê e não podem
        depender de uma consulta ao Metabase para chegar ao chamador.
        """
        try:
            linhas = await metabase.rows(componente_mimetype(component_id))
        except Exception:  # noqa: BLE001 - ver docstring: o conteúdo não depende disto
            # O Resource existe para entregar os bytes, que vêm do Kanoê. O MIME
            # é um refinamento vindo de outra boundary, e uma falha lá não pode
            # derrubar uma leitura que o Kanoê conseguiu servir.
            return "application/octet-stream"
        if not linhas:
            return "application/octet-stream"
        observado = linhas[0].get("mimetype")
        return (
            observado
            if isinstance(observado, str) and observado.strip()
            else "application/octet-stream"
        )

    @catalogo.recurso(
        "pink://documento/componente/{componente_id}",
        mime="application/octet-stream",
        tags={"documento", "read", "binary"},
    )
    async def componente(componente_id: str) -> Conteudo:
        """Read one Kanoê digital component by its stable component id."""
        component_id = _COMPONENT_ID.validate_python(componente_id)
        await _require_read_available(kanoe)
        conteudo = await kanoe.component_bytes(component_id)
        return Conteudo(conteudo, mime=await _mime_observado(component_id))

    return catalogo
