"""Compile Pink 0.8's Markdown/CSS IR into native Google Docs batchUpdate requests.

Parsing is delegated to markdown-it-py and tinycss2. This module owns only the
semantic translation from those parsed structures into the Google Docs API.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Literal

from markdown_it import MarkdownIt
from markdown_it.token import Token
import tinycss2


_SUPPORTED_SELECTORS = frozenset(
    {"p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote", "pre"}
)
_SUPPORTED_PROPERTIES = frozenset(
    {
        "font-family",
        "font-size",
        "font-weight",
        "font-style",
        "text-align",
        "margin-top",
        "margin-bottom",
        "margin-left",
        "text-indent",
    }
)


@dataclass(frozen=True)
class TextStyle:
    font_family: str = "Arial"
    font_size_pt: float = 12.0
    bold: bool = False
    italic: bool = False
    alignment: Literal["START", "CENTER", "END", "JUSTIFIED"] = "JUSTIFIED"
    margin_top_pt: float = 0.0
    margin_bottom_pt: float = 8.0
    margin_left_pt: float = 0.0
    text_indent_pt: float = 0.0


@dataclass(frozen=True)
class Span:
    text: str
    bold: bool = False
    italic: bool = False
    code: bool = False
    link: str | None = None


@dataclass(frozen=True)
class Block:
    tag: str
    spans: tuple[Span, ...]
    list_kind: Literal["bullet", "ordered"] | None = None

    @property
    def text(self) -> str:
        return "".join(span.text for span in self.spans)


@dataclass(frozen=True)
class CompiledMarkdown:
    requests: list[dict[str, Any]]
    characters: int
    paragraphs: int
    headings: int


def compile_markdown(
    markdown: str,
    *,
    stylesheet: str | None,
    current_end_index: int,
) -> CompiledMarkdown:
    """Compile non-empty Markdown into one atomic Google Docs request list."""
    if not markdown.strip():
        raise ValueError("markdown vazio não pode substituir uma minuta")
    if current_end_index < 1:
        raise ValueError("current_end_index deve ser positivo")

    blocks = _parse_blocks(markdown)
    if not blocks:
        raise ValueError("markdown não produziu conteúdo publicável")
    styles = _parse_stylesheet(stylesheet or "")

    requests: list[dict[str, Any]] = []
    if current_end_index > 2:
        requests.append(
            {"deleteContentRange": {"range": {"startIndex": 1, "endIndex": current_end_index - 1}}}
        )

    text = "".join(block.text + "\n" for block in blocks)
    requests.append({"insertText": {"location": {"index": 1}, "text": text}})

    cursor = 1
    headings = 0
    for block in blocks:
        block_text = block.text + "\n"
        block_end = cursor + _utf16_len(block_text)
        style = styles.get(block.tag, _default_style(block.tag))
        if block.tag.startswith("h") and block.tag[1:].isdigit():
            headings += 1

        paragraph_style: dict[str, Any] = {
            "alignment": style.alignment,
            "spaceAbove": {"magnitude": style.margin_top_pt, "unit": "PT"},
            "spaceBelow": {"magnitude": style.margin_bottom_pt, "unit": "PT"},
            "indentStart": {"magnitude": style.margin_left_pt, "unit": "PT"},
            "indentFirstLine": {"magnitude": style.text_indent_pt, "unit": "PT"},
            "namedStyleType": _named_style(block.tag),
        }
        requests.append(
            {
                "updateParagraphStyle": {
                    "range": {"startIndex": cursor, "endIndex": block_end},
                    "paragraphStyle": paragraph_style,
                    "fields": (
                        "alignment,spaceAbove,spaceBelow,indentStart,indentFirstLine,namedStyleType"
                    ),
                }
            }
        )

        if block.list_kind is not None:
            preset = (
                "BULLET_DISC_CIRCLE_SQUARE"
                if block.list_kind == "bullet"
                else "NUMBERED_DECIMAL_ALPHA_ROMAN"
            )
            requests.append(
                {
                    "createParagraphBullets": {
                        "range": {"startIndex": cursor, "endIndex": block_end},
                        "bulletPreset": preset,
                    }
                }
            )

        span_cursor = cursor
        for span in block.spans:
            span_end = span_cursor + _utf16_len(span.text)
            if span_end == span_cursor:
                continue
            text_style: dict[str, Any] = {
                "weightedFontFamily": {
                    "fontFamily": "Roboto Mono" if span.code else style.font_family,
                    "weight": 700 if style.bold or span.bold else 400,
                },
                "fontSize": {"magnitude": style.font_size_pt, "unit": "PT"},
                "bold": style.bold or span.bold,
                "italic": style.italic or span.italic,
            }
            fields = ["weightedFontFamily", "fontSize", "bold", "italic"]
            if span.link:
                text_style["link"] = {"url": span.link}
                fields.append("link")
            requests.append(
                {
                    "updateTextStyle": {
                        "range": {"startIndex": span_cursor, "endIndex": span_end},
                        "textStyle": text_style,
                        "fields": ",".join(fields),
                    }
                }
            )
            span_cursor = span_end
        cursor = block_end

    return CompiledMarkdown(
        requests=requests,
        characters=len(text),
        paragraphs=len(blocks),
        headings=headings,
    )


def _parse_blocks(markdown: str) -> list[Block]:
    # Parse CommonMark with its native HTML recognition enabled so raw HTML is
    # observable as HTML tokens and can be rejected rather than silently
    # literalized into the document. Code spans/fences remain ordinary code.
    tokens = MarkdownIt("commonmark").parse(markdown)
    _reject_raw_html(tokens)
    blocks: list[Block] = []
    list_stack: list[Literal["bullet", "ordered"]] = []
    blockquote_depth = 0
    current_tag: str | None = None

    for token in tokens:
        if token.type == "bullet_list_open":
            list_stack.append("bullet")
        elif token.type == "ordered_list_open":
            list_stack.append("ordered")
        elif token.type in {"bullet_list_close", "ordered_list_close"}:
            if list_stack:
                list_stack.pop()
        elif token.type == "blockquote_open":
            blockquote_depth += 1
        elif token.type == "blockquote_close":
            blockquote_depth = max(0, blockquote_depth - 1)
        elif token.type == "heading_open":
            current_tag = token.tag
        elif token.type == "paragraph_open":
            if list_stack:
                current_tag = "li"
            elif blockquote_depth:
                current_tag = "blockquote"
            else:
                current_tag = "p"
        elif token.type == "inline" and current_tag is not None:
            blocks.append(
                Block(
                    tag=current_tag,
                    spans=tuple(_inline_spans(token.children or [])),
                    list_kind=list_stack[-1] if current_tag == "li" and list_stack else None,
                )
            )
        elif token.type in {"heading_close", "paragraph_close"}:
            current_tag = None
        elif token.type in {"fence", "code_block"}:
            blocks.append(
                Block(tag="pre", spans=(Span(text=token.content.rstrip("\n"), code=True),))
            )
        elif token.type == "hr":
            blocks.append(Block(tag="p", spans=(Span(text="―"),)))
    return blocks


def _reject_raw_html(tokens: list[Token]) -> None:
    """Keep Markdown as the sole content IR instead of accepting an HTML dialect."""
    for token in tokens:
        if token.type == "html_block":
            raise ValueError("HTML cru não é aceito no Markdown da minuta")
        if token.type != "inline":
            continue
        if any(child.type == "html_inline" for child in token.children or []):
            raise ValueError("HTML cru não é aceito no Markdown da minuta")


def _inline_spans(tokens: list[Token]) -> list[Span]:
    spans: list[Span] = []
    bold = False
    italic = False
    link: str | None = None

    for token in tokens:
        if token.type == "strong_open":
            bold = True
            continue
        if token.type == "strong_close":
            bold = False
            continue
        if token.type == "em_open":
            italic = True
            continue
        if token.type == "em_close":
            italic = False
            continue
        if token.type == "link_open":
            attrs = token.attrs or {}
            href = attrs.get("href") if isinstance(attrs, dict) else None
            link = href if isinstance(href, str) else None
            continue
        if token.type == "link_close":
            link = None
            continue
        if token.type in {"softbreak", "hardbreak"}:
            spans.append(Span(text="\n", bold=bold, italic=italic, link=link))
            continue
        if token.type == "code_inline":
            spans.append(Span(text=token.content, code=True, link=link))
            continue
        if token.type == "text":
            spans.append(Span(text=token.content, bold=bold, italic=italic, link=link))
    return _merge_spans(spans)


def _merge_spans(spans: list[Span]) -> list[Span]:
    merged: list[Span] = []
    for span in spans:
        if not span.text:
            continue
        if merged and replace(merged[-1], text=span.text) == span:
            previous = merged.pop()
            merged.append(replace(previous, text=previous.text + span.text))
        else:
            merged.append(span)
    return merged


def _parse_stylesheet(css: str) -> dict[str, TextStyle]:
    """Parse the deliberately small CSS dialect without silent degradation."""
    styles: dict[str, TextStyle] = {}
    if not css.strip():
        return styles
    rules = tinycss2.parse_stylesheet(css, skip_comments=True, skip_whitespace=True)
    for rule in rules:
        rule_type = getattr(rule, "type", None)
        if rule_type == "error":
            raise ValueError(f"CSS inválido: {getattr(rule, 'message', 'erro de sintaxe')}")
        if rule_type != "qualified-rule":
            raise ValueError("CSS da minuta aceita somente regras de seletores simples")

        selectors = [part.strip().lower() for part in tinycss2.serialize(rule.prelude).split(",")]
        if not selectors or any(not selector for selector in selectors):
            raise ValueError("seletor CSS vazio não é aceito")
        unsupported_selectors = [
            selector for selector in selectors if selector not in _SUPPORTED_SELECTORS
        ]
        if unsupported_selectors:
            raise ValueError(
                "seletor CSS não suportado: " + ", ".join(sorted(set(unsupported_selectors)))
            )

        declarations = tinycss2.parse_declaration_list(
            rule.content,
            skip_comments=True,
            skip_whitespace=True,
        )
        for declaration in declarations:
            declaration_type = getattr(declaration, "type", None)
            if declaration_type == "error":
                raise ValueError(
                    f"declaração CSS inválida: {getattr(declaration, 'message', 'erro de sintaxe')}"
                )
            if declaration_type != "declaration":
                raise ValueError("conteúdo CSS não suportado dentro de regra")
            if declaration.lower_name not in _SUPPORTED_PROPERTIES:
                raise ValueError(f"propriedade CSS não suportada: {declaration.lower_name}")
            if declaration.important:
                raise ValueError("!important não é suportado no CSS da minuta")

        for selector in selectors:
            style = styles.get(selector, _default_style(selector))
            for declaration in declarations:
                value = tinycss2.serialize(declaration.value).strip()
                style = _apply_css(style, declaration.lower_name, value)
            styles[selector] = style
    return styles


def _apply_css(style: TextStyle, name: str, value: str) -> TextStyle:
    if name == "font-family":
        family = value.split(",", 1)[0].strip(" '\"")
        if not family:
            raise ValueError("font-family exige uma família não vazia")
        return replace(style, font_family=family)
    if name == "font-size":
        return replace(style, font_size_pt=_required_pt(name, value))
    if name == "font-weight":
        normalized = value.lower()
        if normalized in {"normal", "400"}:
            return replace(style, bold=False)
        if normalized in {"bold", "600", "700", "800", "900"}:
            return replace(style, bold=True)
        raise ValueError(f"valor CSS não suportado para font-weight: {value}")
    if name == "font-style":
        normalized = value.lower()
        if normalized == "normal":
            return replace(style, italic=False)
        if normalized in {"italic", "oblique"}:
            return replace(style, italic=True)
        raise ValueError(f"valor CSS não suportado para font-style: {value}")
    if name == "text-align":
        alignment = {
            "left": "START",
            "center": "CENTER",
            "right": "END",
            "justify": "JUSTIFIED",
        }.get(value.lower())
        if alignment is None:
            raise ValueError(f"valor CSS não suportado para text-align: {value}")
        return replace(style, alignment=alignment)
    if name == "margin-top":
        return replace(style, margin_top_pt=_required_pt(name, value))
    if name == "margin-bottom":
        return replace(style, margin_bottom_pt=_required_pt(name, value))
    if name == "margin-left":
        return replace(style, margin_left_pt=_required_pt(name, value))
    if name == "text-indent":
        return replace(style, text_indent_pt=_required_pt(name, value))
    raise ValueError(f"propriedade CSS não suportada: {name}")


def _required_pt(name: str, value: str) -> float:
    parsed = _pt(value)
    if parsed is None:
        raise ValueError(f"{name} aceita somente valores não negativos em pt (ou 0): {value}")
    return parsed


def _default_style(tag: str) -> TextStyle:
    if tag == "h1":
        return TextStyle(font_size_pt=18, bold=True, margin_top_pt=12, margin_bottom_pt=8)
    if tag == "h2":
        return TextStyle(font_size_pt=15, bold=True, margin_top_pt=10, margin_bottom_pt=6)
    if tag in {"h3", "h4", "h5", "h6"}:
        return TextStyle(font_size_pt=12, bold=True, margin_top_pt=8, margin_bottom_pt=4)
    if tag == "blockquote":
        return TextStyle(margin_left_pt=24, italic=True)
    if tag == "pre":
        return TextStyle(font_family="Roboto Mono", alignment="START")
    return TextStyle()


def _named_style(tag: str) -> str:
    return {
        "h1": "HEADING_1",
        "h2": "HEADING_2",
        "h3": "HEADING_3",
        "h4": "HEADING_4",
        "h5": "HEADING_5",
        "h6": "HEADING_6",
    }.get(tag, "NORMAL_TEXT")


def _pt(value: str) -> float | None:
    raw = value.strip().lower()
    if raw == "0":
        return 0.0
    if not raw.endswith("pt"):
        return None
    try:
        parsed = float(raw[:-2])
    except ValueError:
        return None
    return parsed if parsed >= 0 else None


def _utf16_len(value: str) -> int:
    return len(value.encode("utf-16-le")) // 2
