"""Document and case-binary HTTP behavior layered on the Pink 0.8 Kanoê adapter."""

from __future__ import annotations

import base64
import binascii

import httpx
from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from pink.documento_write import KanoeDocumentoRef
from pink.kanoe_http import KanoeHttp
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure


class _RemoteModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class _RemoteDocument(_RemoteModel):
    id: int


class _RemotePasta(_RemoteModel):
    id: int
    fonteDados: str | None = None


class _PastaEnvelope(_RemoteModel):
    resultados: list[_RemotePasta] = Field(default_factory=list)


_DOCUMENTS = TypeAdapter(list[_RemoteDocument])


class KanoeDocumentoHttp(KanoeHttp):
    """Kanoê adapter including document and full-process binary primitives."""

    async def task_documents(self, tarefa_id: int) -> tuple[KanoeDocumentoRef, ...]:
        payload = await self._read_json("GET", f"/api/documentos/tarefa/{tarefa_id}")
        raw = payload.get("resultados", []) if isinstance(payload, dict) else payload
        try:
            docs = _DOCUMENTS.validate_python(raw)
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida de documentos da tarefa {tarefa_id}: {exc}"
            ) from exc
        return tuple(KanoeDocumentoRef(documento_id=doc.id) for doc in docs)

    async def upload_document(
        self,
        *,
        pasta_id: int,
        tarefa_id: int,
        nome: str,
        mime_type: str,
        data: bytes,
    ) -> None:
        """Upload bytes owned by the runtime; no client-local path is accepted."""
        await self._write_multipart(
            "/api/upload/arquivo",
            data={"pastaId": str(pasta_id), "tarefaId": str(tarefa_id)},
            files={"file": (nome, data, mime_type)},
        )

    async def delete_document(self, documento_id: int) -> None:
        await self._write_json("DELETE", f"/api/documentos/{documento_id}")

    async def component_bytes(self, componente_id: int) -> bytes:
        payload = await self._read_json(
            "GET",
            f"/api/componente-digital/{componente_id}/documento/download",
        )
        if not isinstance(payload, dict):
            raise RemoteObservationFailure(
                f"resposta inválida ao baixar componente {componente_id}: envelope não é objeto"
            )
        encoded = payload.get("binaryContent")
        if not isinstance(encoded, str) or not encoded:
            raise RemoteObservationFailure(f"componente {componente_id} não retornou binaryContent")
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise RemoteObservationFailure(
                f"binaryContent inválido para componente {componente_id}"
            ) from exc

    async def pasta_pdf(self, pasta_id: int) -> bytes:
        """Fetch the complete process PDF for one concrete Kanoê pasta.

        Pink observes the pasta's ``fonteDados`` because the timeline endpoint
        requires it. No fallback source, size heuristic or alternate legacy
        response format is assumed by the 0.8 contract.
        """
        payload = await self._read_json("GET", f"/api/pasta/{pasta_id}")
        try:
            envelope = _PastaEnvelope.model_validate(payload)
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida de pasta {pasta_id} ao resolver fonteDados: {exc}"
            ) from exc
        if not envelope.resultados:
            raise RemoteObservationFailure(f"pasta {pasta_id} não encontrada no Kanoê")

        fonte_dados = (envelope.resultados[0].fonteDados or "").strip()
        if not fonte_dados:
            raise RemoteObservationFailure(
                f"pasta {pasta_id} não expôs fonteDados; Pink não adivinha a origem do PDF"
            )

        try:
            response = await self.client.request(
                "GET",
                "/api/timeline-pje/processo/download",
                params={"pastaId": pasta_id, "fonteDadosCodigo": fonte_dados},
                headers=self._headers,
                timeout=600.0,
            )
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(
                f"falha ao baixar PDF da pasta {pasta_id}: {exc}"
            ) from exc
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise RemoteObservationFailure(
                f"Kanoê respondeu HTTP {response.status_code} ao baixar PDF da pasta {pasta_id}"
            ) from exc

        data = response.content
        if not data.startswith(b"%PDF-"):
            raise RemoteObservationFailure(f"Kanoê não retornou um PDF para a pasta {pasta_id}")
        return data

    async def _write_multipart(
        self,
        path: str,
        *,
        data: dict[str, str],
        files: dict[str, tuple[str, bytes, str]],
    ) -> None:
        try:
            response = await self.client.request(
                "POST",
                path,
                data=data,
                files=files,
                headers=self._headers,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=False) from exc
        except httpx.HTTPError as exc:
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=True) from exc
        if 400 <= response.status_code < 500:
            raise RemoteWriteFailure(
                f"Kanoê rejeitou o upload com HTTP {response.status_code}",
                effect_may_have_occurred=False,
            )
        if response.status_code >= 500:
            raise RemoteWriteFailure(
                f"Kanoê respondeu HTTP {response.status_code} após o upload",
                effect_may_have_occurred=True,
            )
