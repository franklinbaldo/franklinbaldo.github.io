"""Single runtime configuration contract for Pink 0.8.

Precedence is explicit init > OS keyring > environment > ``pink.toml`` > model
defaults. Dotenv and file-secret settings sources are deliberately excluded.
"""

from __future__ import annotations

import logging
from pathlib import Path

import keyring
import keyring.errors
from typing import TYPE_CHECKING, Any

from pydantic import Field, SecretStr
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    TomlConfigSettingsSource,
)

from pink.kanoe_http import DEFAULT_BASE_URL as DEFAULT_KANOE_URL
from pink.setor_config import PeticaoSetor, atualizar_toml

if TYPE_CHECKING:
    from pydantic.fields import FieldInfo

logger = logging.getLogger(__name__)
METABASE_KEYRING = "pink-metabase"
KANOE_KEYRING = "pink-kanoe"
# Usuário e senha da Caipora (SSO institucional): com eles o token do Kanoê
# nasce e renova sozinho. Mesmo serviço de keyring que a 0.7 usava.
CAIPORA_KEYRING = "pink-caipora"
GOOGLE_KEYRING = "pink-google"
CONFIG_PATH = Path("pink.toml")


class KeyringSource(PydanticBaseSettingsSource):
    """Resolve persisted credentials; non-secret identity stays in TOML/env."""

    def get_field_value(self, field: FieldInfo, field_name: str) -> tuple[Any, str, bool]:
        del field
        return None, field_name, False

    def __call__(self) -> dict[str, Any]:
        values: dict[str, Any] = {}
        try:
            metabase = keyring.get_credential(METABASE_KEYRING, None)
            if metabase is not None:
                if metabase.username:
                    values["metabase_email"] = metabase.username
                if metabase.password:
                    values["metabase_password"] = metabase.password
            kanoe = keyring.get_password(KANOE_KEYRING, "authorization")
            if kanoe:
                values["kanoe_authorization"] = kanoe
            caipora = keyring.get_credential(CAIPORA_KEYRING, None)
            if caipora is not None:
                if caipora.username:
                    values["caipora_usuario"] = caipora.username
                if caipora.password:
                    values["caipora_senha"] = caipora.password
            google = keyring.get_password(GOOGLE_KEYRING, "authorization")
            if google:
                values["google_authorization"] = google
        except (OSError, RuntimeError, ImportError, keyring.errors.KeyringError) as exc:
            logger.warning("keyring indisponível; continuando com ambiente/TOML: %s", exc)
        return values


class Settings(BaseSettings):
    """Everything needed to construct the production Pink 0.8 runtime."""

    model_config = SettingsConfigDict(
        env_prefix="PINK_",
        case_sensitive=False,
        extra="ignore",
        toml_file=str(CONFIG_PATH),
    )

    setor: str | None = None
    peticao: PeticaoSetor = Field(default_factory=PeticaoSetor)

    metabase_url: str = "https://metabase.sistemas.pge.ro.gov.br"
    # Nome do banco Caipora no Metabase; o id é descoberto por ele. `metabase_database_id`
    # continua como override explícito, assim como a identidade Kanoê abaixo.
    metabase_database: str = "ratio"
    metabase_database_id: int | None = None
    # Collection onde as Cards do setor vivem: configuração de cada setor (o
    # judicial declara a sua no pink.toml), não um argumento a repetir a cada uso.
    metabase_collection_id: int | None = Field(default=None, gt=0)
    metabase_email: str | None = None
    metabase_password: SecretStr | None = None

    kanoe_base_url: str = DEFAULT_KANOE_URL
    kanoe_authorization: SecretStr | None = None
    kanoe_user_id: int | None = None
    kanoe_user_name: str | None = None
    # Com usuário e senha da Caipora, `kanoe_authorization` é opcional: o token
    # é obtido no primeiro uso e renovado quando expira (seis horas, medido).
    caipora_usuario: str | None = None
    caipora_senha: SecretStr | None = None

    google_authorization: SecretStr | None = None

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Use one deliberate source order and never read dotenv/secret files."""
        del dotenv_settings, file_secret_settings
        return (
            init_settings,
            KeyringSource(settings_cls),
            env_settings,
            TomlConfigSettingsSource(settings_cls),
        )


def update_local_config(
    *,
    metabase_database_id: int | None = None,
    metabase_collection_id: int | None = None,
    kanoe_user_id: int | None = None,
    kanoe_user_name: str | None = None,
    path: Path = CONFIG_PATH,
) -> Path:
    """Merge non-secret setup values into the same ``pink.toml`` Settings reads."""
    updates: dict[str, object] = {}
    if metabase_database_id is not None:
        if metabase_database_id <= 0:
            raise ValueError("metabase_database_id deve ser positivo")
        updates["metabase_database_id"] = metabase_database_id
    if metabase_collection_id is not None:
        if metabase_collection_id <= 0:
            raise ValueError("metabase_collection_id deve ser positivo")
        updates["metabase_collection_id"] = metabase_collection_id
    if kanoe_user_id is not None:
        if kanoe_user_id <= 0:
            raise ValueError("kanoe_user_id deve ser positivo")
        updates["kanoe_user_id"] = kanoe_user_id
    if kanoe_user_name is not None:
        if not kanoe_user_name.strip():
            raise ValueError("kanoe_user_name não pode ser vazio")
        updates["kanoe_user_name"] = kanoe_user_name.strip()

    atualizar_toml(path, updates)
    return path
