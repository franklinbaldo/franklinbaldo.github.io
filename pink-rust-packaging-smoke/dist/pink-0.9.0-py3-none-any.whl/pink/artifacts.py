"""Runtime-owned immutable artifacts: Parquet datasets and published files."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable, Mapping
import datetime
import decimal
from hashlib import sha256
import mimetypes
from pathlib import Path
import shutil
import tempfile
from typing import TYPE_CHECKING, Annotated, Any, Sequence
from uuid import uuid4

import ibis
from ibis.backends.sql.datatypes import DuckDBType
from ibis.expr.schema import Schema
from pydantic import BaseModel, Field
from sqlglot import exp

from pink.catalogo import Catalogo, Conteudo, Efeito
from pink.metabase import ObservacaoTruncada
from pink.models import (
    AMOSTRA_INLINE_MAX,
    Colecao,
    DatasetArtifact,
    Disponibilidade,
    FileArtifact,
    Fonte,
    Indisponivel,
    Observado,
    Parcial,
    PinkModel,
    ResultadoColecao,
)
from pink.write_safety import ConsultaSemCard, RemoteObservationFailure

from ibis.expr import types as ir

if TYPE_CHECKING:
    from pink.integrations import Metabase

AMOSTRA = AMOSTRA_INLINE_MAX
PARQUET_MIME = "application/vnd.apache.parquet"
BINARY_MIME = "application/octet-stream"


def _literal_sql(valor: object) -> str:
    """One Python value as a DuckDB literal; typed columns cast on insert."""
    if valor is None:
        return "NULL"
    if isinstance(valor, bool):
        return "TRUE" if valor else "FALSE"
    if isinstance(valor, (int, decimal.Decimal)):
        return str(valor)
    if isinstance(valor, float):
        return repr(valor)
    if isinstance(valor, (datetime.datetime, datetime.date, datetime.time)):
        return exp.Literal.string(valor.isoformat()).sql("duckdb")
    if isinstance(valor, str):
        return exp.Literal.string(valor).sql("duckdb")
    raise TypeError(f"valor sem literal SQL definido: {type(valor).__name__}")


def _insert_sql(tabela: str, tuplas: list[str]) -> str:
    """One INSERT for a batch of literal tuples.

    Concatenação, não parâmetros, de propósito: o binding de parâmetros do
    DuckDB é o que importa pandas. Nada aqui vem de fora -- o identificador e
    cada literal já passaram pelo sqlglot, e o alvo é um DuckDB em memória que
    só contém linhas validadas pelo Pydantic.
    """
    return f"INSERT INTO {tabela} VALUES " + ", ".join(tuplas)  # nosec B608


def carregar_linhas(
    backend: Any,
    nome: str,
    schema: Schema,
    linhas: Iterable[Mapping[str, object]],
    *,
    lote: int = 500,
) -> None:
    """Put validated Python rows into a DuckDB table on an Ibis backend, by SQL only.

    Every Ibis entry point for in-memory rows -- `memtable`, `insert`,
    `create_table(obj=...)` -- goes through pandas or pyarrow. The first import
    of that native stack inside a request running on the event loop
    loads numpy's DLL on the event-loop thread and never returns. The schema
    is still Ibis (types via the DuckDB dialect it ships); the rows enter as
    SQL; everything after is Ibis IR.
    """
    tabela = exp.to_identifier(nome, quoted=True).sql("duckdb")
    nomes = [str(coluna) for coluna, _ in schema.items()]
    definicoes = [
        f"{exp.to_identifier(str(coluna), quoted=True).sql('duckdb')} "
        f"{DuckDBType.from_ibis(tipo).sql('duckdb')}"
        for coluna, tipo in schema.items()
    ]
    backend.raw_sql(f"CREATE TABLE {tabela} (" + ", ".join(definicoes) + ")")
    pendentes: list[str] = []
    for linha in linhas:
        pendentes.append("(" + ", ".join(_literal_sql(linha.get(c)) for c in nomes) + ")")
        if len(pendentes) >= lote:
            backend.raw_sql(_insert_sql(tabela, pendentes))
            pendentes.clear()
    if pendentes:
        backend.raw_sql(_insert_sql(tabela, pendentes))


class ArtifactStore:
    """Directory-backed store for immutable generated or imported artifacts.

    Everything an artifact is lives on disk -- the bytes and, for a file, its
    `FileArtifact` beside them -- so one CLI invocation can resolve what an
    earlier one published under the same root.
    """

    def __init__(self, root: Path, *, ephemeral: bool = False) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._ephemeral = ephemeral

    @classmethod
    def temporary(cls) -> ArtifactStore:
        """Create an ephemeral process-local store owned by the runtime lifespan."""
        return cls(Path(tempfile.mkdtemp(prefix="pink-artifacts-")), ephemeral=True)

    async def aclose(self) -> None:
        """Release runtime-owned artifacts; caller-owned roots are never deleted."""
        if self._ephemeral:
            shutil.rmtree(self.root, ignore_errors=True)

    def publish_parquet[T: BaseModel](
        self,
        *,
        rows: Sequence[object],
        model: type[T],
        schema: Schema,
    ) -> tuple[DatasetArtifact, list[T]]:
        """Validate every row with Pydantic, then persist the complete set as Parquet."""
        validated = [model.model_validate(row) for row in rows]
        payload = [item.model_dump(mode="python") for item in validated]
        artifact_id = uuid4().hex
        path = self.root / f"{artifact_id}.parquet"

        backend = ibis.duckdb.connect()
        try:
            carregar_linhas(backend, "linhas", schema, payload)
            backend.to_parquet(ibis.table(schema, name="linhas"), path)
        except Exception:
            path.unlink(missing_ok=True)
            raise
        finally:
            backend.disconnect()

        artifact = DatasetArtifact(
            uri=f"pink://artifact/{artifact_id}",
            linhas=len(validated),
            colunas=tuple(schema),
            tamanho_bytes=path.stat().st_size,
            modelo=model.__name__,
        )
        return artifact, validated

    def publish_file(self, *, nome: str, data: bytes, mime_type: str) -> FileArtifact:
        """Publish bytes the runtime already owns without accepting an arbitrary client path."""
        clean_name = Path(nome).name.strip()
        if not clean_name or clean_name in {".", ".."}:
            raise ValueError("nome de artifact inválido")
        if not mime_type.strip():
            raise ValueError("mime_type não pode ser vazio")
        artifact_id = uuid4().hex
        path = self.root / f"{artifact_id}.bin"
        artifact = FileArtifact(
            uri=f"pink://file/{artifact_id}",
            nome=clean_name,
            mime_type=mime_type,
            tamanho_bytes=len(data),
            sha256=sha256(data).hexdigest(),
        )
        # The metadata is written last: a file without it does not exist yet.
        metadata = self.root / f"{artifact_id}.json"
        try:
            path.write_bytes(data)
            metadata.write_text(artifact.model_dump_json(), encoding="utf-8")
        except Exception:
            path.unlink(missing_ok=True)
            metadata.unlink(missing_ok=True)
            raise
        return artifact

    def read(self, artifact_id: str) -> bytes:
        """Read one immutable Parquet artifact, rejecting path traversal and malformed ids."""
        _validate_artifact_id(artifact_id)
        path = self.root / f"{artifact_id}.parquet"
        if not path.is_file():
            raise FileNotFoundError(f"artifact {artifact_id} não encontrado")
        return path.read_bytes()

    def file(self, artifact_id: str) -> tuple[FileArtifact, bytes]:
        """Resolve one immutable binary artifact by opaque id."""
        _validate_artifact_id(artifact_id)
        metadata = self.root / f"{artifact_id}.json"
        if not metadata.is_file():
            raise FileNotFoundError(f"file artifact {artifact_id} não encontrado")
        artifact = FileArtifact.model_validate_json(metadata.read_text(encoding="utf-8"))
        data = (self.root / f"{artifact_id}.bin").read_bytes()
        if sha256(data).hexdigest() != artifact.sha256:
            raise ValueError(f"file artifact {artifact_id} foi alterado depois de publicado")
        return artifact, data

    def file_from_uri(self, uri: str) -> tuple[FileArtifact, bytes]:
        """Resolve only Pink-owned file URIs; never interpret file:// or local paths."""
        prefix = "pink://file/"
        if not uri.startswith(prefix):
            raise ValueError("arquivo_uri deve ser uma URI pink://file/... já materializado")
        return self.file(uri.removeprefix(prefix))


async def materializar_colecao[T: PinkModel](
    metabase: Metabase,
    artifacts: ArtifactStore,
    expression: ir.Table | Callable[[], Awaitable[ir.Table]],
    model: type[T],
    *,
    limite: int,
    alternativa: ir.Table | None = None,
    enriquecer: Callable[[list[dict[str, Any]]], Awaitable[list[dict[str, Any]]]] | None = None,
) -> ResultadoColecao[T]:
    """One flow for every agent-facing collection.

    `listar` means an explicitly limited selection: the caller's limit enters
    the Ibis expression -- after filters and the deterministic ordering, in the
    same query block -- before anything is materialized. Limiting after
    materialization is RED. No offset, no pagination, no automatic count: what
    the source returns is validated row by row and persisted as Parquet, and
    `total` is the exact size of this selection.

    `enriquecer`, when supplied, runs only after the actual limited selection
    was observed (including a Saved-Card fallback). It may attach data derived
    from those identities, but it must preserve one output row per observed
    row. This keeps source selection semantics separate from lossless domain
    enrichment.
    """
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return ResultadoColecao[T](
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )
    truncado: ObservacaoTruncada | None = None
    try:
        base = expression if isinstance(expression, ir.Table) else await expression()
        selecao = base.limit(limite)
        try:
            rows = await metabase.rows(selecao)
        except ConsultaSemCard:
            if alternativa is None:
                raise
            selecao = alternativa.limit(limite)
            rows = await metabase.rows(selecao)
    except ObservacaoTruncada as exc:
        rows, truncado = exc.linhas, exc
    except RemoteObservationFailure as exc:
        return ResultadoColecao[T](dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
    if len(rows) > limite:
        return ResultadoColecao[T](
            dados=Indisponivel(
                fonte=Fonte.METABASE,
                motivo=(
                    f"contrato quebrado: a fonte devolveu {len(rows)} linhas para um limite "
                    f"de {limite}; a seleção não é confiável"
                ),
            )
        )
    if enriquecer is not None:
        try:
            enriquecidas = await enriquecer([dict(row) for row in rows])
        except RemoteObservationFailure as exc:
            return ResultadoColecao[T](dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
        if len(enriquecidas) != len(rows):
            return ResultadoColecao[T](
                dados=Indisponivel(
                    fonte=Fonte.METABASE,
                    motivo=(
                        "contrato quebrado: enriquecimento alterou a cardinalidade da seleção "
                        f"({len(rows)} -> {len(enriquecidas)})"
                    ),
                )
            )
        rows = enriquecidas
    dataset, items = artifacts.publish_parquet(rows=rows, model=model, schema=selecao.schema())
    colecao = Colecao[T](total=len(items), amostra=items[:AMOSTRA], dataset=dataset)
    if truncado is not None and len(items) < limite:
        return ResultadoColecao[T](
            dados=Parcial(
                valor=colecao,
                ausente=(
                    f"itens do {len(items) + 1}º ao {limite}º desta seleção: a fonte truncou a "
                    f"resposta em {truncado.truncado_em} linhas. O Parquet contém as "
                    f"{len(items)} observadas. Um limite menor só pede uma seleção menor; "
                    f"para alcançar outra seleção, refine os filtros",
                ),
            )
        )
    return ResultadoColecao[T](dados=Observado(valor=colecao))


def _validate_artifact_id(artifact_id: str) -> None:
    if len(artifact_id) != 32 or any(char not in "0123456789abcdef" for char in artifact_id):
        raise ValueError("artifact_id inválido")


def build_artifact_catalogo(store: ArtifactStore) -> Catalogo:
    """Publish local files as artifacts and read Parquet datasets and files back by URI."""
    catalogo = Catalogo()

    @catalogo.operacao(
        nome="arquivo_publicar",
        tags={"artifact", "file", "write"},
        efeito=Efeito(mundo_aberto=False),
    )
    def arquivo_publicar(
        caminho: Annotated[Path, Field(description="Arquivo local a publicar")],
        mime_type: Annotated[
            str | None,
            Field(description="MIME type do conteúdo; omita para inferir pela extensão"),
        ] = None,
    ) -> FileArtifact:
        """Copia um arquivo local para o store de artifacts e devolve a `pink://file` URI imutável.

        Operações como `documento_enviar` e `peticionamento_preparar` recebem essa
        URI, nunca o caminho. Sem --mime-type, o tipo é inferido pela extensão.
        """
        tipo = mime_type or mimetypes.guess_type(caminho.name)[0] or BINARY_MIME
        return store.publish_file(nome=caminho.name, data=caminho.read_bytes(), mime_type=tipo)

    @catalogo.recurso(
        "pink://artifact/{artifact_id}",
        mime=PARQUET_MIME,
        tags={"artifact", "parquet", "read"},
    )
    def artifact(artifact_id: str) -> Conteudo:
        """Read one immutable Parquet dataset generated by a Pink collection tool."""
        conteudo = store.read(artifact_id)
        return Conteudo(conteudo, mime=PARQUET_MIME)

    @catalogo.recurso(
        "pink://file/{artifact_id}",
        mime=BINARY_MIME,
        tags={"artifact", "file", "read"},
    )
    def file_artifact(artifact_id: str) -> Conteudo:
        """Read one immutable binary artifact already owned by the Pink runtime."""
        artifact, conteudo = store.file(artifact_id)
        return Conteudo(conteudo, mime=artifact.mime_type)

    return catalogo
