"""Expediente write capabilities with observable postconditions."""

from __future__ import annotations

from dataclasses import replace

from datetime import date
from typing import Annotated

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.domain_types import ExpedienteId, PastaId, TextoNaoVazio
from pink.expediente_state import fechar_expediente, reabrir_expediente
from pink.integrations import ExpedienteRemoto, Kanoe
from pink.models import (
    Ambigua,
    Confirmada,
    EfeitoEscrita,
    PinkModel,
    Recusada,
    Submetida,
)
from pink.system import Runtime
from pink.write_safety import (
    RemoteObservationFailure,
    RemoteWriteFailure,
    observe_precondition,
    refuse_if_unavailable,
)

WRITE = Efeito(
    leitura=False,
    destrutivo=False,
    idempotente=False,
    mundo_aberto=True,
)
IDEMPOTENT_WRITE = replace(WRITE, idempotente=True)
DESTRUCTIVE = replace(WRITE, destrutivo=True)
IDEMPOTENT_DESTRUCTIVE = replace(IDEMPOTENT_WRITE, destrutivo=True)


class ExpedienteAlteracao(PinkModel):
    """Os campos de um expediente que podem ser alterados; só o que vier preenchido muda."""

    prazo: date | None = Field(default=None, description="Novo prazo final do expediente")
    teor: TextoNaoVazio | None = Field(default=None, description="Novo teor (HTML)")
    tipo: int | None = Field(default=None, gt=0, description="Novo código do tipo de expediente")
    # `comentario` não entra: `PUT /api/expedientes/alterar` aceita o campo e não
    # o persiste (medido em 2026-09-10, reobservação voltou nula).

    def vazia(self) -> bool:
        return all(v is None for v in (self.prazo, self.teor, self.tipo))

    def satisfeita_por(self, observado: ExpedienteRemoto) -> bool:
        """Whether the observed expediente already carries every requested value."""
        return (
            (self.prazo is None or observado.prazo == self.prazo.isoformat())
            and (self.teor is None or observado.teor == self.teor)
            and (self.tipo is None or observado.tipo == self.tipo)
        )


def build_expediente_write_catalogo(runtime: Runtime) -> Catalogo:
    """Build expediente mutations over the semantic Kanoê boundary."""
    catalogo = Catalogo()

    def get_kanoe() -> Kanoe:
        return runtime.kanoe

    @catalogo.operacao(
        nome="expediente_criar",
        tags={"expediente", "write"},
        efeito=WRITE,
    )
    async def expediente_criar(
        pasta_id: PastaId,
        prazo: Annotated[date, Field(description="Data final do prazo do expediente")],
        teor: TextoNaoVazio,
    ) -> EfeitoEscrita:
        """Cria expediente aberto e confirma pelo endpoint de detalhe quando possível."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="expediente_criar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        try:
            expediente_id = await kanoe.create_expediente(pasta_id, prazo.isoformat(), teor)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="expediente_criar",
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        if expediente_id is None:
            return Ambigua(
                operacao="expediente_criar",
                detalhe="Kanoê aceitou a criação sem devolver a identidade do expediente",
            )
        handle = f"kanoe:expediente:{expediente_id}"
        try:
            closed = await kanoe.expediente_closed(expediente_id)
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="expediente_criar",
                handle=handle,
                detalhe=f"expediente {expediente_id} criado, mas a reobservação falhou: {exc}",
            )
        if closed is False:
            return Confirmada(operacao="expediente_criar", recurso_id=expediente_id)
        return Submetida(
            operacao="expediente_criar",
            handle=handle,
            detalhe=(
                f"expediente {expediente_id} criado, mas a projeção ainda o mostra fechado; "
                "releia o handle antes de decidir qualquer ação corretiva"
            ),
        )

    @catalogo.operacao(
        nome="expediente_comentar",
        tags={"expediente", "write"},
        efeito=WRITE,
    )
    async def expediente_comentar(
        expediente_id: ExpedienteId,
        conteudo: TextoNaoVazio,
    ) -> EfeitoEscrita:
        """Adiciona comentário; sem read-back direto comprovado, sucesso fica `submetida`."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="expediente_comentar", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        handle = f"pink://expediente/{expediente_id}"
        try:
            await kanoe.add_expediente_comment(expediente_id, conteudo)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="expediente_comentar",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        return Submetida(
            operacao="expediente_comentar",
            handle=handle,
            detalhe="comentário aceito; releia o handle até o comentário aparecer na observação",
        )

    @catalogo.operacao(
        nome="expediente_alterar",
        tags={"expediente", "write"},
        efeito=IDEMPOTENT_WRITE,
    )
    async def expediente_alterar(
        expediente_id: ExpedienteId,
        alteracao: Annotated[
            ExpedienteAlteracao,
            Field(description="Campos a alterar; os omitidos ficam como estão no Kanoê"),
        ],
    ) -> EfeitoEscrita:
        """Altera prazo, teor ou tipo de um expediente e reobserva o resultado.

        Declarativa: se o expediente observado já tem os valores pedidos, é
        `confirmada` sem escrita. Medido ao vivo em 2026-09-10 (`PUT
        /api/expedientes/alterar` com o objeto inteiro).
        """
        kanoe = get_kanoe()
        if alteracao.vazia():
            return Recusada(operacao="expediente_alterar", motivo="nenhum campo a alterar")
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="expediente_alterar", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        atual = await observe_precondition(
            operacao="expediente_alterar",
            observe=lambda: kanoe.expediente_detail(expediente_id),
        )
        if isinstance(atual, Recusada):
            return atual
        if alteracao.satisfeita_por(atual):
            return Confirmada(
                operacao="expediente_alterar",
                recurso_id=expediente_id,
                detalhe="o expediente observado já tem os valores pedidos",
            )
        handle = f"kanoe:expediente:{expediente_id}"
        try:
            await kanoe.alterar_expediente(
                expediente_id,
                prazo=alteracao.prazo.isoformat() if alteracao.prazo else None,
                teor=alteracao.teor,
                tipo=alteracao.tipo,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="expediente_alterar",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        try:
            depois = await kanoe.expediente_detail(expediente_id)
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="expediente_alterar",
                handle=handle,
                detalhe=f"alteração aceita, mas a reobservação falhou: {exc}",
            )
        if alteracao.satisfeita_por(depois):
            return Confirmada(operacao="expediente_alterar", recurso_id=expediente_id)
        return Submetida(
            operacao="expediente_alterar",
            handle=handle,
            detalhe="alteração aceita, mas o expediente reobservado ainda não mostra todos os valores pedidos",
        )

    @catalogo.operacao(
        nome="expediente_fechar",
        tags={"expediente", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def expediente_fechar(
        expediente_id: ExpedienteId,
    ) -> EfeitoEscrita:
        """Fecha expediente somente depois de observar seu estado atual."""
        kanoe = get_kanoe()
        return await fechar_expediente(kanoe, expediente_id)

    @catalogo.operacao(
        nome="expediente_reabrir",
        tags={"expediente", "write"},
        efeito=IDEMPOTENT_WRITE,
    )
    async def expediente_reabrir(
        expediente_id: ExpedienteId,
    ) -> EfeitoEscrita:
        """Reabre expediente somente depois de observar seu estado atual."""
        kanoe = get_kanoe()
        return await reabrir_expediente(kanoe, expediente_id)

    return catalogo
