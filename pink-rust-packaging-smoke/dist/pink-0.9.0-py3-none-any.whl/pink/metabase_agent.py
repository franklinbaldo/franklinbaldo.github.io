"""Opt-in direct REST access to the configured Metabase using the user's permissions.

The raw server exposes reads and writes for work not covered by Pink domain
queries, including saved Cards and structured queries when Native SQL is denied.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, Protocol, cast

from pydantic import Field, JsonValue
from pydantic.experimental.missing_sentinel import MISSING

from pink.catalogo import Catalogo, Efeito
from pink.metabase import validate_api_path

from pink.models import (
    Ambigua,
    Disponibilidade,
    Fonte,
    Indisponivel,
    IntegracaoStatus,
    JsonObject,
    Observacao,
    Observado,
    PinkModel,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure

REST = Efeito(leitura=False, destrutivo=True, idempotente=False, mundo_aberto=True)


class AgentMetabase(Protocol):
    async def probe(self) -> IntegracaoStatus: ...

    async def agent_request(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: JsonValue | MISSING = MISSING,
    ) -> tuple[int, JsonValue]: ...


class MetabaseAgentHttp(PinkModel):
    """One response actually observed from Metabase's REST API."""

    status_code: int = Field(ge=100, le=599, description="HTTP status observado na API REST")
    corpo: JsonValue = Field(description="JSON observado na API REST do Metabase")


class MetabaseAgentResposta(PinkModel):
    """Exploratory API REST response, or explicit Metabase unavailability."""

    dados: Observacao[MetabaseAgentHttp] | Ambigua = Field(
        description="Resposta HTTP observada, indisponibilidade antes do dispatch ou escrita de efeito incerto"
    )


def build_metabase_agent_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> AgentMetabase:
        return cast(AgentMetabase, runtime.metabase)

    @catalogo.operacao(
        nome="metabase_agent",
        tags={"raw", "metabase", "agent", "write", "destructive", "open-world"},
        efeito=REST,
    )
    async def metabase_agent(
        method: Annotated[
            Literal["GET", "POST", "PUT", "PATCH", "DELETE"],
            Field(
                description="Método HTTP; escritas usam as permissões da conta e não são repetidas automaticamente"
            ),
        ],
        path: Annotated[
            str,
            Field(
                pattern=r"^/api/",
                description="Caminho /api/ do Metabase configurado, incluindo Cards, consultas e Agent API",
            ),
        ],
        query: Annotated[
            JsonObject | None,
            Field(description="Query-string da API REST, quando o endpoint exigir"),
        ] = None,
        body: Annotated[
            JsonValue | MISSING,
            Field(
                description="JSON da requisição; omitido envia corpo vazio, null envia JSON null"
            ),
        ] = MISSING,
    ) -> MetabaseAgentResposta:
        """Acessa diretamente a API REST do Metabase com as permissões da conta.

        Permite consultar e alterar Cards e usar consultas estruturadas quando
        Native SQL não está disponível. Prefira tools de domínio quando cobrirem
        a necessidade. Escritas podem criar, modificar ou excluir conteúdo.
        O status HTTP observado não é confirmação de sucesso de negócio; após
        falha ou resposta inconclusiva, reobserve antes de repetir uma escrita.
        """
        metabase = get_metabase()
        path = validate_api_path(path)
        probe = getattr(metabase, "probe_api", metabase.probe)
        disponibilidade = await probe()
        if disponibilidade.estado is Disponibilidade.INDISPONIVEL:
            return MetabaseAgentResposta(
                dados=Indisponivel(
                    fonte=Fonte.METABASE,
                    motivo=disponibilidade.detalhe or "Metabase indisponível",
                )
            )
        try:
            status_code, payload = await metabase.agent_request(
                method,
                path,
                query=dict(query) if query is not None else None,
                body=body,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return MetabaseAgentResposta(
                    dados=Ambigua(operacao="metabase_agent", detalhe=str(exc))
                )
            return MetabaseAgentResposta(dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
        except RemoteObservationFailure as exc:
            return MetabaseAgentResposta(dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
        return MetabaseAgentResposta(
            dados=Observado(
                valor=MetabaseAgentHttp(status_code=status_code, corpo=payload),
                proveniencia=None,
            )
        )

    return catalogo
