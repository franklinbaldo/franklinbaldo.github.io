"""Pasta domain contracts and catalog operations."""

from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import (
    CaixaId,
    Cnj,
    Limite,
    PastaId,
    SetorSigla,
    SetorId,
    cnj_storage_variants,
)
from pink.integrations import Metabase
from pink.models import (
    PinkModel,
    ResultadoColecao,
)
from pink.queries import pastas_filter
from pink.queries_setoriais import pastas_setor
from pink.setores import ids_do_setor
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class PastaResumo(PinkModel):
    """Small operational projection used by pasta navigation."""

    setor_responsavel_etiqueta_id: SetorId | None = Field(
        description="Setor vinculado à etiqueta de autarquia; não é o setor atual da pasta",
    )
    setor_responsavel_etiqueta_sigla: SetorSigla | None = Field(
        description="Sigla observada do setor da etiqueta de autarquia"
    )
    setor_responsavel_etiqueta_nome: str | None = Field(
        description="Nome observado do setor da etiqueta de autarquia"
    )
    setor_responsavel_etiqueta_cnpj: str | None = Field(
        description="CNPJ informado pela fonte identifica a autarquia responsável pela pasta; preservado como texto sem validar formato ou dígitos verificadores; null significa responsabilidade não identificada por CNPJ",
    )

    pasta_id: PastaId
    numero: Cnj | None = Field(default=None, description="Número CNJ quando associado à pasta")
    setor: SetorSigla = Field(description="Setor atual da pasta na observação")
    caixa_id: CaixaId | None = Field(
        default=None, description="Caixa organizadora ativa, se houver"
    )
    n_correntes: int = Field(ge=0, description="Quantidade observada de correntes temáticas ativas")
    n_tarefas_abertas: int = Field(ge=0, description="Quantidade observada de tarefas abertas")
    n_expedientes_abertos: int = Field(
        ge=0,
        description="Quantidade observada de expedientes abertos",
    )
    proximo_prazo: date | None = Field(default=None, description="Próximo prazo observado")
    atividade_em: datetime | None = Field(
        default=None,
        description="Instante da atividade mais recente usada para ordenação",
    )


class PastaFiltro(PinkModel):
    """Composable query replacing historical one-view-per-tool pasta APIs."""

    setor: SetorSigla | None = Field(default=None, description="Filtra pela sigla do setor")
    processo: Cnj | None = Field(default=None, description="Filtra pelo número CNJ do processo")
    caixa_id: CaixaId | None = Field(default=None, description="Filtra pela caixa ativa atual")
    com_tarefa: bool | None = Field(
        default=None,
        description="True exige tarefa aberta; False exige ausência observada de tarefa aberta",
    )
    com_caixa: bool | None = Field(
        default=None,
        description="True exige caixa ativa; False seleciona pastas observadas sem caixa ativa",
    )
    com_corrente: bool | None = Field(
        default=None,
        description="True exige corrente ativa; False seleciona pastas observadas sem corrente ativa",
    )
    prazo_ate: date | None = Field(
        default=None,
        description="Mantém pastas cujo próximo prazo observado cai até esta data",
    )
    ordenar_por: Literal["prazo", "atividade"] = Field(
        default="prazo",
        description="Critério de ordenação da consulta e da amostra",
    )


class PastaListagem(ResultadoColecao[PastaResumo]):
    """Resultado Pydantic concreto da coleção de pastas."""


def _projection(filtro: PastaFiltro, *, setor_ids: tuple[int, ...] | None):
    expression = pastas_filter(
        setor_ids=setor_ids,
        processo=None,
        caixa_id=filtro.caixa_id,
        com_tarefa=filtro.com_tarefa,
        com_caixa=filtro.com_caixa,
        com_corrente=filtro.com_corrente,
        prazo_ate=filtro.prazo_ate,
        ordenar_por=filtro.ordenar_por,
    )
    if filtro.processo is not None:
        expression = expression.filter(
            expression.numero.isin(cnj_storage_variants(filtro.processo))
        )
    return expression


async def _listar(
    metabase: Metabase,
    artifacts: ArtifactStore,
    filtro: PastaFiltro,
    *,
    limite: int,
) -> PastaListagem:
    async def selecao():
        ids = await ids_do_setor(metabase, filtro.setor) if filtro.setor is not None else None
        return _projection(filtro, setor_ids=ids)

    alternativa = (
        pastas_setor(filtro.setor)
        if filtro.setor is not None and filtro == PastaFiltro(setor=filtro.setor)
        else None
    )
    resultado = await materializar_colecao(
        metabase, artifacts, selecao, PastaResumo, limite=limite, alternativa=alternativa
    )
    return PastaListagem(dados=resultado.dados)


def build_pasta_catalogo(runtime: Runtime) -> Catalogo:
    """Build the pasta catalogo over expression-first Metabase and Parquet artifacts."""
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="pasta_listar",
        tags={"pasta", "read", "parquet"},
        efeito=READ,
    )
    async def pasta_listar(
        limite: Limite,
        filtro: Annotated[
            PastaFiltro,
            Field(description="Filtros combináveis da listagem; omita para listar sem restrições"),
        ] = PastaFiltro(),
    ) -> PastaListagem:
        """Materializa uma seleção de pastas limitada por `limite` em Parquet e devolve uma pequena amostra tipada."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        result = await _listar(metabase, artifacts, filtro, limite=limite)
        return result

    return catalogo
