"""Caipora SSO: the Kanoê Bearer token comes from the institutional login, not from a paste.

Two plain HTTP requests, the same shape the browser sends -- measured live on
2026-09-10 (and on 2026-07-01, in the 0.7): `POST /login` answers 302 to
`/internal/home`; `POST /internal/redirecionar` answers 302 to the Kanoê home
with `jwt=` in the query string. No CSRF field, one cookie jar across the two.
The token lives six hours.
"""

from __future__ import annotations

import re
from urllib.parse import urlsplit

import httpx

CAIPORA_BASE_URL = "https://caipora.sistemas.pge.ro.gov.br"
KANOE_HOME_URL = "https://kanoe.sistemas.pge.ro.gov.br/home"
_JWT_NA_URL = re.compile(r"[?&]jwt=([^&]+)")
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) pink/0.8"


class CaiporaAuthFailure(RuntimeError):
    """No Kanoê token could be obtained: rejected credentials, an unexpected answer, or no way to renew."""


def _redirect_kanoe_valido(location: str) -> bool:
    """Accept only the exact Kanoê origin/path; never trust a jwt from another redirect target."""
    esperado = urlsplit(KANOE_HOME_URL)
    recebido = urlsplit(location)
    return (
        recebido.scheme == esperado.scheme
        and recebido.netloc == esperado.netloc
        and recebido.path == esperado.path
    )


async def token_kanoe_por_sso(
    usuario: str, senha: str, *, client: httpx.AsyncClient | None = None
) -> str:
    """`Bearer <jwt>` for the Kanoê API, by logging the user into the Caipora SSO."""
    proprio = client is None
    client = client or httpx.AsyncClient(
        base_url=CAIPORA_BASE_URL,
        headers={"user-agent": _USER_AGENT},
        follow_redirects=False,
        timeout=30.0,
    )
    try:
        try:
            login = await client.post(
                "/login", data={"ipOrigem": "", "username": usuario, "password": senha}
            )
        except httpx.HTTPError as exc:
            raise CaiporaAuthFailure(f"login na Caipora não pôde ser feito: {exc}") from exc
        if login.status_code != 302 or "/internal/home" not in login.headers.get("location", ""):
            raise CaiporaAuthFailure(
                f"Caipora recusou as credenciais de {usuario!r} (HTTP {login.status_code})"
            )
        try:
            redirect = await client.post(
                "/internal/redirecionar",
                data={"urlSistema": KANOE_HOME_URL},
                headers={"referer": f"{CAIPORA_BASE_URL}/internal/home"},
            )
        except httpx.HTTPError as exc:
            raise CaiporaAuthFailure(
                f"redirecionamento ao Kanoê não pôde ser feito: {exc}"
            ) from exc
    finally:
        if proprio:
            await client.aclose()
    location = redirect.headers.get("location", "")
    if redirect.status_code != 302 or not _redirect_kanoe_valido(location):
        raise CaiporaAuthFailure(
            f"Caipora devolveu redirect inesperado ao Kanoê (HTTP {redirect.status_code})"
        )
    encontrado = _JWT_NA_URL.search(location)
    if encontrado is None:
        raise CaiporaAuthFailure(
            f"Caipora não devolveu um jwt no redirect ao Kanoê (HTTP {redirect.status_code})"
        )
    return f"Bearer {encontrado.group(1)}"
