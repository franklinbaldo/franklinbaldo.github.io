"""Autarquia observations with the same contract over Kanoê and Metabase."""

from datetime import UTC, datetime
from typing import Annotated

from pydantic import Field, ValidationError

from pink.catalogo import Catalogo, Efeito
from pink.pasta_models import PastaResponsabilidade, SetorResponsavelResultado, FonteSetor
from pink.domain_types import PastaId
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observado,
    Proveniencia,
)
from pink.queries_context import pasta_autarquia
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure


async def obter_autarquia(
    runtime: Runtime, pasta_id: PastaId, fonte: FonteSetor = "kanoe"
) -> SetorResponsavelResultado:
    origem = Fonte(fonte)
    adapter = runtime.kanoe if fonte == "kanoe" else runtime.metabase
    try:
        status = await adapter.probe()
        if status.estado is Disponibilidade.INDISPONIVEL:
            return SetorResponsavelResultado(
                dados=Indisponivel(fonte=origem, motivo=status.detalhe or "Fonte indisponível")
            )
        if fonte == "kanoe":
            valor = await runtime.kanoe.pasta_setor_responsavel(pasta_id)
        else:
            rows = await runtime.metabase.rows(pasta_autarquia(pasta_id))
            if len(rows) > 1:
                return SetorResponsavelResultado(
                    dados=Indisponivel(
                        fonte=origem, motivo="Metabase retornou mais de uma linha para a pasta"
                    )
                )
            valor = PastaResponsabilidade.model_validate(rows[0]) if rows else None
        if valor is not None and valor.pasta_id != pasta_id:
            return SetorResponsavelResultado(
                dados=Indisponivel(
                    fonte=origem, motivo="A fonte retornou identidade de pasta divergente"
                )
            )
    except (RemoteObservationFailure, ValidationError) as exc:
        return SetorResponsavelResultado(dados=Indisponivel(fonte=origem, motivo=str(exc)))
    if valor is None:
        return SetorResponsavelResultado(
            dados=Ausente(fonte=origem, motivo=f"pasta {pasta_id} não encontrada")
        )
    return SetorResponsavelResultado(
        dados=Observado(
            valor=valor,
            proveniencia=Proveniencia(fonte=origem, observado_em=datetime.now(UTC)),
        )
    )


def build_pasta_autarquia_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    @catalogo.operacao(
        nome="pasta_autarquia_obter",
        tags={"pasta", "read"},
        efeito=Efeito(leitura=True, idempotente=True, mundo_aberto=True),
    )
    async def pasta_autarquia_obter(
        pasta_id: PastaId,
        fonte: Annotated[
            FonteSetor,
            Field(
                description="kanoe lê a API viva; metabase lê a réplica. Não há troca silenciosa de fonte"
            ),
        ] = "kanoe",
    ) -> SetorResponsavelResultado:
        """Lê o setor da etiqueta de autarquia e seu CNPJ, com fonte e instante explícitos.

        O padrão consulta o Kanoê sem depender do Metabase. Para levantamento
        em lote, pasta_listar publica os mesmos campos sem uma chamada por pasta.
        """
        return await obter_autarquia(runtime, pasta_id, fonte)

    return catalogo
