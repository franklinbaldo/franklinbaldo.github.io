"""Integration boundaries and executable fakes for Pink 0.8 tests."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import Any, Never, Protocol

import ibis
import ibis.expr.datatypes as dt
from ibis.expr import types as ir

from pink import schema as physical_schema
from pink.pasta_models import PastaResponsabilidade
from pink.models import Disponibilidade, IntegracaoStatus, PinkModel
from pink.artifacts import carregar_linhas


class Probe(Protocol):
    """Minimal material health contract shared by external integrations."""

    async def probe(self) -> IntegracaoStatus: ...


class Metabase(Probe, Protocol):
    """Expression-first Metabase boundary.

    Production implementations compile the expression for the remote transport.
    Test fakes execute the same expression locally before compilation.
    """

    async def rows(self, expression: ir.Table) -> list[dict[str, Any]]: ...


class BoxRef(PinkModel):
    """Minimal organizer-box identity returned by the Kanoê search boundary."""

    id: int
    nome: str


class PastaOrganization(PinkModel):
    """Organization state observable from Kanoê's received-work-area projection."""

    caixa_id: int | None
    corrente_ids: tuple[int, ...]


class ResumoRemoto(PinkModel):
    """A summary as the Kanoê API returns it, for a pasta or a componente digital."""

    resumo_id: int
    resumo: str
    versao: int
    avaliacao_media: float | None = None
    avaliacoes: int = 0
    criado_em: datetime | None = None
    atualizado_em: datetime | None = None
    autor: str | None = None
    tipo_documento: str | None = None


class FonteTimeline(PinkModel):
    """One data source (instância) of a pasta's PJe timeline."""

    codigo: str
    nome: str


class ExpedienteRemoto(PinkModel):
    """The fields of an expediente that `expediente_alterar` reads, edits and re-observes."""

    expediente_id: int
    pasta_id: int
    tipo: int | None = None
    teor: str | None = None
    prazo: str | None = None
    comentario: str | None = None
    fechado: bool = False


class TarefaRemota(PinkModel):
    """What the Kanoê echoes back after a task write: enough to compare with the intent."""

    tarefa_id: int
    post_it: str | None = None
    prazo: str | None = None
    urgente: bool | None = None


class Kanoe(Probe, Protocol):
    """Semantic Kanoê boundary used by domain capabilities.

    Providers operate on domain effects and postconditions. HTTP paths, auth,
    response JSON and retry mechanics belong to the production adapter.
    """

    async def set_pasta_annotation(self, pasta_id: int, texto: str) -> None: ...
    async def pasta_annotation(self, pasta_id: int) -> str | None: ...
    async def pasta_setor_responsavel(self, pasta_id: int) -> PastaResponsabilidade | None: ...

    async def set_pasta_box(self, pasta_id: int, caixa_id: int) -> None: ...
    async def update_pasta_correntes(
        self,
        pasta_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None: ...
    async def pasta_correntes(self, pasta_id: int) -> tuple[int, ...]: ...
    async def pasta_organization(self, pasta_id: int, setor: str) -> PastaOrganization: ...

    async def receive_tramitacao(self, pasta_id: int, tramitacao_id: int) -> None: ...
    async def tramitacao_pending(self, pasta_id: int, tramitacao_id: int) -> bool: ...

    async def create_box(self, nome: str, setor_id: int) -> None: ...
    async def find_boxes(self, nome: str, setor_id: int) -> tuple[BoxRef, ...]: ...

    async def create_tarefa(
        self,
        *,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> int | None: ...
    async def tarefa_pending(self, tarefa_id: int) -> bool: ...
    async def add_tarefa_comment(self, tarefa_id: int, texto: str) -> None: ...
    async def update_tarefa_etiquetas(
        self,
        tarefa_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None: ...
    async def tarefa_etiquetas(self, tarefa_id: int) -> tuple[int, ...]: ...
    async def delete_tarefa(self, tarefa_id: int) -> None: ...

    async def create_expediente(self, pasta_id: int, prazo: str, teor: str) -> int | None: ...
    async def expediente_closed(self, expediente_id: int) -> bool: ...
    async def set_expediente_closed(self, expediente_id: int, closed: bool) -> None: ...
    async def add_expediente_comment(self, expediente_id: int, conteudo: str) -> None: ...
    async def pasta_resumo(self, pasta_id: int) -> ResumoRemoto | None: ...
    async def componente_resumo(self, componente_id: int) -> ResumoRemoto | None: ...
    async def timeline_fontes(self, pasta_id: int) -> tuple[FonteTimeline, ...]: ...
    async def timeline_movimentacoes(
        self, pasta_id: int, fonte_codigo: str
    ) -> list[dict[str, Any]]: ...
    async def expediente_detail(self, expediente_id: int) -> ExpedienteRemoto: ...
    async def alterar_expediente(
        self,
        expediente_id: int,
        *,
        prazo: str | None,
        teor: str | None,
        tipo: int | None,
    ) -> None: ...
    async def update_tarefa(
        self,
        *,
        tarefa_id: int,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> TarefaRemota | None: ...
    async def set_pasta_annotations(self, anotacoes: Mapping[int, str]) -> None: ...


def _inferir_schema(name: str, rows: Sequence[Mapping[str, Any]]) -> ibis.Schema:
    """Schema for a fixture outside the physical model, from the first non-null values."""
    if not rows:
        raise ValueError(f"fixture {name!r} sem linhas e fora do schema físico: não há como tipar")
    colunas: dict[str, dt.DataType] = {}
    for coluna in {c for row in rows for c in row}:
        amostra = next((row[coluna] for row in rows if row.get(coluna) is not None), None)
        tipo = dt.infer(amostra) if amostra is not None else dt.string
        if tipo.is_integer():
            tipo = dt.int64
        elif tipo.is_floating():
            tipo = dt.float64
        colunas[coluna] = tipo
    return ibis.schema(colunas)


def _fixture_schema(name: str, rows: Sequence[Mapping[str, Any]]) -> ibis.Schema | None:
    """Use the physical schema for known Caipora tables, narrowed to fixture columns."""
    table = getattr(physical_schema, name, None)
    if table is None or not isinstance(table, ir.Table):
        return None

    full_schema = table.schema()
    columns = {column for row in rows for column in row}
    if not columns:
        return full_schema
    unknown = columns - set(full_schema.names)
    if unknown:
        names = ", ".join(sorted(unknown))
        message = f"fixture {name!r} contém coluna(s) fora do schema físico: {names}"
        raise ValueError(message)
    return ibis.schema({column: full_schema[column] for column in columns})


class FakeMetabase:
    """DuckDB-backed Metabase fake that accepts Ibis expressions, never SQL."""

    def __init__(
        self,
        *,
        tables: Mapping[str, Sequence[Mapping[str, Any]]] | None = None,
        status: IntegracaoStatus | None = None,
    ) -> None:
        self._status = status or IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)
        self._backend = ibis.duckdb.connect()
        for name, source_rows in (tables or {}).items():
            rows = list(source_rows)
            schema = _fixture_schema(name, rows) or _inferir_schema(name, rows)
            # A mesma ingestão da produção: por SQL, a partir do schema Ibis.
            # `memtable`/`create_table(obj=)` passariam por pandas, e o fake
            # tem de exercitar o caminho que o servidor real percorre.
            carregar_linhas(self._backend, name, schema, rows)

    async def probe(self) -> IntegracaoStatus:
        return self._status

    async def rows(self, expression: ir.Table) -> list[dict[str, Any]]:
        """Execute an unbound expression against same-named DuckDB fixture tables.

        Compiled by Ibis for the DuckDB dialect and fetched through the
        backend cursor: `to_pyarrow`/`to_pandas` would import the native stack
        inside the request, which is exactly what the stdio journey forbids.
        """
        cursor = self._backend.raw_sql(ibis.to_sql(expression, dialect="duckdb"))
        names = [column[0] for column in cursor.description]
        return [dict(zip(names, row, strict=True)) for row in cursor.fetchall()]


class FakeKanoe:
    """Stateful Kanoê fake that proves effects through observable postconditions."""

    def __init__(
        self,
        status: IntegracaoStatus | None = None,
        *,
        responsabilidades: Mapping[int, PastaResponsabilidade] | None = None,
        annotations: Mapping[int, str | None] | None = None,
        boxes: Mapping[int, int | None] | None = None,
        correntes: Mapping[int, Sequence[int]] | None = None,
        pending_tramitacoes: Mapping[int, int] | None = None,
        box_names: Mapping[int, str] | None = None,
        tarefas_pending: Sequence[int] = (),
        tarefa_labels: Mapping[int, Sequence[int]] | None = None,
        expedientes_closed: Mapping[int, bool] | None = None,
        resumos: Mapping[int, ResumoRemoto] | None = None,
        componente_resumos: Mapping[int, ResumoRemoto] | None = None,
        timelines: Mapping[int, Sequence[Mapping[str, Any]]] | None = None,
        expedientes: Mapping[int, ExpedienteRemoto] | None = None,
    ) -> None:
        self.resumos = dict(resumos or {})
        self.componente_resumos = dict(componente_resumos or {})
        self.timelines = {k: list(v) for k, v in (timelines or {}).items()}
        self.expedientes = dict(expedientes or {})
        self.tarefas_alteradas: dict[int, dict[str, Any]] = {}
        self._status = status or IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)
        self.responsabilidades = dict(responsabilidades or {})
        self.annotations = dict(annotations or {})
        self.boxes = dict(boxes or {})
        self.correntes = {key: tuple(sorted(value)) for key, value in (correntes or {}).items()}
        self.pending_tramitacoes = dict(pending_tramitacoes or {})
        self.box_names = dict(box_names or {})
        self.tarefas_pending = set(tarefas_pending)
        self.tarefa_labels = {
            key: tuple(sorted(set(value))) for key, value in (tarefa_labels or {}).items()
        }
        self.tarefa_comments: dict[int, list[str]] = {}
        self.expedientes_closed = dict(expedientes_closed or {})
        self.expediente_comments: dict[int, list[str]] = {}
        self._next_box_id = max(self.box_names, default=1000) + 1
        self._next_tarefa_id = max(self.tarefas_pending, default=2000) + 1
        self._next_expediente_id = max(self.expedientes_closed, default=3000) + 1

    async def probe(self) -> IntegracaoStatus:
        return self._status

    async def set_pasta_annotation(self, pasta_id: int, texto: str) -> None:
        self.annotations[pasta_id] = texto

    async def pasta_setor_responsavel(self, pasta_id: int) -> PastaResponsabilidade | None:
        return self.responsabilidades.get(pasta_id)

    async def pasta_annotation(self, pasta_id: int) -> str | None:
        return self.annotations.get(pasta_id)

    async def set_pasta_box(self, pasta_id: int, caixa_id: int) -> None:
        self.boxes[pasta_id] = caixa_id

    async def update_pasta_correntes(
        self,
        pasta_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        current = set(self.correntes.get(pasta_id, ()))
        current.difference_update(remover)
        current.update(adicionar)
        self.correntes[pasta_id] = tuple(sorted(current))

    async def pasta_correntes(self, pasta_id: int) -> tuple[int, ...]:
        return self.correntes.get(pasta_id, ())

    async def pasta_organization(self, pasta_id: int, setor: str) -> PastaOrganization:
        del setor
        return PastaOrganization(
            caixa_id=self.boxes.get(pasta_id),
            corrente_ids=self.correntes.get(pasta_id, ()),
        )

    async def receive_tramitacao(self, pasta_id: int, tramitacao_id: int) -> None:
        if self.pending_tramitacoes.get(pasta_id) == tramitacao_id:
            self.pending_tramitacoes.pop(pasta_id)

    async def tramitacao_pending(self, pasta_id: int, tramitacao_id: int) -> bool:
        return self.pending_tramitacoes.get(pasta_id) == tramitacao_id

    async def create_box(self, nome: str, setor_id: int) -> None:
        del setor_id
        caixa_id = self._next_box_id
        self._next_box_id += 1
        self.box_names[caixa_id] = nome.upper()

    async def find_boxes(self, nome: str, setor_id: int) -> tuple[BoxRef, ...]:
        del setor_id
        needle = nome.upper()
        return tuple(
            BoxRef(id=caixa_id, nome=box_name)
            for caixa_id, box_name in sorted(self.box_names.items())
            if needle in box_name.upper()
        )

    async def create_tarefa(
        self,
        *,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> int | None:
        del (
            pasta_id,
            especie_id,
            prazo,
            prazo_inicio,
            post_it,
            expediente_id,
            setor_responsavel_id,
            urgente,
        )
        tarefa_id = self._next_tarefa_id
        self._next_tarefa_id += 1
        self.tarefas_pending.add(tarefa_id)
        return tarefa_id

    async def tarefa_pending(self, tarefa_id: int) -> bool:
        return tarefa_id in self.tarefas_pending

    async def add_tarefa_comment(self, tarefa_id: int, texto: str) -> None:
        self.tarefa_comments.setdefault(tarefa_id, []).append(texto)

    async def update_tarefa_etiquetas(
        self,
        tarefa_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        current = set(self.tarefa_labels.get(tarefa_id, ()))
        current.difference_update(remover)
        current.update(adicionar)
        self.tarefa_labels[tarefa_id] = tuple(sorted(current))

    async def tarefa_etiquetas(self, tarefa_id: int) -> tuple[int, ...]:
        return self.tarefa_labels.get(tarefa_id, ())

    async def delete_tarefa(self, tarefa_id: int) -> None:
        self.tarefas_pending.discard(tarefa_id)
        self.tarefa_labels.pop(tarefa_id, None)

    async def create_expediente(self, pasta_id: int, prazo: str, teor: str) -> int | None:
        del pasta_id, prazo, teor
        expediente_id = self._next_expediente_id
        self._next_expediente_id += 1
        self.expedientes_closed[expediente_id] = False
        return expediente_id

    async def expediente_closed(self, expediente_id: int) -> bool:
        if expediente_id not in self.expedientes_closed:
            raise RuntimeError(f"expediente {expediente_id} não existe no fake")
        return self.expedientes_closed[expediente_id]

    async def set_expediente_closed(self, expediente_id: int, closed: bool) -> None:
        self.expedientes_closed[expediente_id] = closed

    async def add_expediente_comment(self, expediente_id: int, conteudo: str) -> None:
        self.expediente_comments.setdefault(expediente_id, []).append(conteudo)

    async def pasta_resumo(self, pasta_id: int) -> ResumoRemoto | None:
        return self.resumos.get(pasta_id)

    async def componente_resumo(self, componente_id: int) -> ResumoRemoto | None:
        return self.componente_resumos.get(componente_id)

    async def timeline_fontes(self, pasta_id: int) -> tuple[FonteTimeline, ...]:
        return tuple(
            FonteTimeline(codigo=f["fonteDados"]["codigo"], nome=f["fonteDados"]["nome"])
            for f in self.timelines.get(pasta_id, [])
        )

    async def timeline_movimentacoes(
        self, pasta_id: int, fonte_codigo: str
    ) -> list[dict[str, Any]]:
        return [
            dict(f)
            for f in self.timelines.get(pasta_id, [])
            if f["fonteDados"]["codigo"] == fonte_codigo
        ]

    async def expediente_detail(self, expediente_id: int) -> ExpedienteRemoto:
        return self.expedientes[expediente_id]

    async def alterar_expediente(
        self,
        expediente_id: int,
        *,
        prazo: str | None,
        teor: str | None,
        tipo: int | None,
    ) -> None:
        atual = self.expedientes[expediente_id]
        mudancas = {
            k: v
            for k, v in {
                "prazo": prazo,
                "teor": teor,
                "tipo": tipo,
            }.items()
            if v is not None
        }
        self.expedientes[expediente_id] = atual.model_copy(update=mudancas)

    async def update_tarefa(
        self,
        *,
        tarefa_id: int,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> TarefaRemota | None:
        if tarefa_id not in self.tarefas_pending:
            return None
        self.tarefas_alteradas[tarefa_id] = {
            "pasta_id": pasta_id,
            "especie_id": especie_id,
            "prazo": prazo,
            "prazo_inicio": prazo_inicio,
            "post_it": post_it,
            "expediente_id": expediente_id,
            "setor_responsavel_id": setor_responsavel_id,
            "urgente": urgente,
        }
        return TarefaRemota(tarefa_id=tarefa_id, post_it=post_it, prazo=prazo, urgente=urgente)

    async def set_pasta_annotations(self, anotacoes: Mapping[int, str]) -> None:
        for pasta_id, texto in anotacoes.items():
            self.annotations[pasta_id] = texto


class FakeGoogle:
    """Minimal Google integration fake for capability-level behavior tests."""

    def __init__(self, status: IntegracaoStatus | None = None) -> None:
        self._status = status or IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)

    async def probe(self) -> IntegracaoStatus:
        return self._status


class UnavailableIntegration:
    """Default placeholder until a real generic integration factory lands."""

    def __init__(self, reason: str) -> None:
        self._status = IntegracaoStatus(
            estado=Disponibilidade.INDISPONIVEL,
            detalhe=reason,
        )

    async def probe(self) -> IntegracaoStatus:
        return self._status


class UnavailableMetabase(UnavailableIntegration):
    """Unconfigured Metabase boundary that never invents query results."""

    async def rows(self, expression: ir.Table) -> Never:
        raise RuntimeError(f"Metabase indisponível: {self._status.detalhe}; query={expression!r}")


class UnavailableKanoe(UnavailableIntegration):
    """Unconfigured Kanoê boundary that satisfies the semantic protocol honestly."""

    def _fail(self) -> Never:
        raise RuntimeError(f"Kanoê indisponível: {self._status.detalhe}")

    async def set_pasta_annotation(self, pasta_id: int, texto: str) -> None:
        del pasta_id, texto
        self._fail()

    async def pasta_setor_responsavel(self, pasta_id: int) -> PastaResponsabilidade | None:
        del pasta_id
        self._fail()

    async def pasta_annotation(self, pasta_id: int) -> str | None:
        del pasta_id
        self._fail()

    async def set_pasta_box(self, pasta_id: int, caixa_id: int) -> None:
        del pasta_id, caixa_id
        self._fail()

    async def update_pasta_correntes(
        self,
        pasta_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        del pasta_id, adicionar, remover
        self._fail()

    async def pasta_correntes(self, pasta_id: int) -> tuple[int, ...]:
        del pasta_id
        self._fail()

    async def pasta_organization(self, pasta_id: int, setor: str) -> PastaOrganization:
        del pasta_id, setor
        self._fail()

    async def receive_tramitacao(self, pasta_id: int, tramitacao_id: int) -> None:
        del pasta_id, tramitacao_id
        self._fail()

    async def tramitacao_pending(self, pasta_id: int, tramitacao_id: int) -> bool:
        del pasta_id, tramitacao_id
        self._fail()

    async def create_box(self, nome: str, setor_id: int) -> None:
        del nome, setor_id
        self._fail()

    async def find_boxes(self, nome: str, setor_id: int) -> tuple[BoxRef, ...]:
        del nome, setor_id
        self._fail()

    async def create_tarefa(
        self,
        *,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> int | None:
        del (
            pasta_id,
            especie_id,
            prazo,
            prazo_inicio,
            post_it,
            expediente_id,
            setor_responsavel_id,
            urgente,
        )
        self._fail()

    async def tarefa_pending(self, tarefa_id: int) -> bool:
        del tarefa_id
        self._fail()

    async def add_tarefa_comment(self, tarefa_id: int, texto: str) -> None:
        del tarefa_id, texto
        self._fail()

    async def update_tarefa_etiquetas(
        self,
        tarefa_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        del tarefa_id, adicionar, remover
        self._fail()

    async def tarefa_etiquetas(self, tarefa_id: int) -> tuple[int, ...]:
        del tarefa_id
        self._fail()

    async def delete_tarefa(self, tarefa_id: int) -> None:
        del tarefa_id
        self._fail()

    async def create_expediente(self, pasta_id: int, prazo: str, teor: str) -> int | None:
        del pasta_id, prazo, teor
        self._fail()

    async def expediente_closed(self, expediente_id: int) -> bool:
        del expediente_id
        self._fail()

    async def set_expediente_closed(self, expediente_id: int, closed: bool) -> None:
        del expediente_id, closed
        self._fail()

    async def add_expediente_comment(self, expediente_id: int, conteudo: str) -> None:
        del expediente_id, conteudo
        self._fail()

    async def pasta_resumo(self, pasta_id: int) -> ResumoRemoto | None:
        del pasta_id
        self._fail()

    async def componente_resumo(self, componente_id: int) -> ResumoRemoto | None:
        del componente_id
        self._fail()

    async def timeline_fontes(self, pasta_id: int) -> tuple[FonteTimeline, ...]:
        del pasta_id
        self._fail()

    async def timeline_movimentacoes(
        self, pasta_id: int, fonte_codigo: str
    ) -> list[dict[str, Any]]:
        del pasta_id, fonte_codigo
        self._fail()

    async def expediente_detail(self, expediente_id: int) -> ExpedienteRemoto:
        del expediente_id
        self._fail()

    async def alterar_expediente(
        self,
        expediente_id: int,
        *,
        prazo: str | None,
        teor: str | None,
        tipo: int | None,
    ) -> None:
        del expediente_id, prazo, teor, tipo
        self._fail()

    async def update_tarefa(
        self,
        *,
        tarefa_id: int,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> TarefaRemota | None:
        del tarefa_id, pasta_id, especie_id, prazo, prazo_inicio, post_it
        del expediente_id, setor_responsavel_id, urgente
        self._fail()

    async def set_pasta_annotations(self, anotacoes: Mapping[int, str]) -> None:
        del anotacoes
        self._fail()
