"""Typed async Google Docs/Drive boundary for Pink 0.8 minutas."""

from __future__ import annotations

from typing import Any, Protocol

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from pink.integrations import Probe
from pink.minuta_observation import MinutaDocumentNotFound
from pink.models import Disponibilidade, IntegracaoStatus, PinkModel
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure

DOCS_BASE = "https://docs.googleapis.com"
DRIVE_BASE = "https://www.googleapis.com"


class GoogleDocumentNotFound(MinutaDocumentNotFound):
    """Google proved the requested document is absent or invisible to this identity."""


class GoogleDocState(PinkModel):
    google_doc_id: str = Field(min_length=1)
    revision_id: str = Field(min_length=1)
    title: str | None = None
    end_index: int = Field(ge=1)


class GoogleBatchResult(PinkModel):
    revision_id: str = Field(min_length=1)
    replies: list[dict[str, Any]] = Field(default_factory=list)


class GoogleDocs(Probe, Protocol):
    async def document_state(self, google_doc_id: str) -> GoogleDocState: ...
    async def export(self, google_doc_id: str, mime_type: str) -> bytes: ...
    async def batch_update(
        self,
        google_doc_id: str,
        *,
        requests: list[dict[str, Any]],
        required_revision_id: str,
    ) -> GoogleBatchResult: ...


class RawGoogleDocs(GoogleDocs, Protocol):
    """Explicit escape-hatch boundary used only by the disabled raw surface."""

    async def document_json(self, google_doc_id: str) -> dict[str, Any]: ...


class UnavailableGoogleDocs:
    """Unconfigured Google boundary that preserves semantic failure on every surface."""

    def __init__(self, reason: str) -> None:
        self._status = IntegracaoStatus(estado=Disponibilidade.INDISPONIVEL, detalhe=reason)

    async def probe(self) -> IntegracaoStatus:
        return self._status

    def _observation_error(self) -> RemoteObservationFailure:
        return RemoteObservationFailure(self._status.detalhe or "Google indisponível")

    async def document_json(self, google_doc_id: str) -> dict[str, Any]:
        del google_doc_id
        raise self._observation_error()

    async def document_state(self, google_doc_id: str) -> GoogleDocState:
        del google_doc_id
        raise self._observation_error()

    async def export(self, google_doc_id: str, mime_type: str) -> bytes:
        del google_doc_id, mime_type
        raise self._observation_error()

    async def batch_update(
        self,
        google_doc_id: str,
        *,
        requests: list[dict[str, Any]],
        required_revision_id: str,
    ) -> GoogleBatchResult:
        del google_doc_id, requests, required_revision_id
        raise RemoteWriteFailure(
            self._status.detalhe or "Google indisponível",
            effect_may_have_occurred=False,
        )


class _RemoteModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class _WriteControl(_RemoteModel):
    requiredRevisionId: str | None = None
    targetRevisionId: str | None = None


class _BatchResponse(_RemoteModel):
    replies: list[dict[str, Any]] = Field(default_factory=list)
    writeControl: _WriteControl | None = None


class GoogleDocsHttp:
    """Direct REST adapter; authentication is supplied explicitly by the runtime."""

    def __init__(self, *, authorization: str, client: httpx.AsyncClient | None = None) -> None:
        if not authorization.strip():
            raise ValueError("authorization não pode ser vazio")
        self._headers = {"authorization": authorization, "accept": "application/json"}
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(timeout=120.0, follow_redirects=True)

    async def aclose(self) -> None:
        if self._owns_client:
            await self.client.aclose()

    async def probe(self) -> IntegracaoStatus:
        try:
            response = await self.client.get(
                f"{DRIVE_BASE}/drive/v3/about",
                params={"fields": "user(emailAddress)"},
                headers=self._headers,
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            return IntegracaoStatus(estado=Disponibilidade.INDISPONIVEL, detalhe=str(exc))
        return IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)

    async def document_json(self, google_doc_id: str) -> dict[str, Any]:
        try:
            response = await self.client.get(
                f"{DOCS_BASE}/v1/documents/{google_doc_id}",
                params={"includeTabsContent": "true"},
                headers=self._headers,
            )
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(
                f"falha ao ler Google Doc {google_doc_id}: {exc}"
            ) from exc
        if response.status_code == 404:
            raise GoogleDocumentNotFound(f"Google Doc {google_doc_id} ausente ou invisível")
        try:
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(
                f"falha ao ler Google Doc {google_doc_id}: {exc}"
            ) from exc
        try:
            payload = response.json()
        except ValueError as exc:
            raise RemoteObservationFailure("Google Docs retornou JSON inválido") from exc
        if not isinstance(payload, dict):
            raise RemoteObservationFailure(
                "Google Docs retornou documento fora do formato esperado"
            )
        return payload

    async def document_state(self, google_doc_id: str) -> GoogleDocState:
        payload = await self.document_json(google_doc_id)
        revision = payload.get("revisionId")
        if not isinstance(revision, str) or not revision:
            raise RemoteObservationFailure(
                "Google Docs não retornou revisionId; a conta pode não ter permissão de edição"
            )
        return GoogleDocState(
            google_doc_id=google_doc_id,
            revision_id=revision,
            title=payload.get("title") if isinstance(payload.get("title"), str) else None,
            end_index=_document_end_index(payload),
        )

    async def export(self, google_doc_id: str, mime_type: str) -> bytes:
        try:
            response = await self.client.get(
                f"{DRIVE_BASE}/drive/v3/files/{google_doc_id}/export",
                params={"mimeType": mime_type},
                headers=self._headers,
            )
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(
                f"falha ao exportar Google Doc {google_doc_id} como {mime_type}: {exc}"
            ) from exc
        if response.status_code == 404:
            raise GoogleDocumentNotFound(f"Google Doc {google_doc_id} ausente ou invisível")
        try:
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(
                f"falha ao exportar Google Doc {google_doc_id} como {mime_type}: {exc}"
            ) from exc
        if not response.content:
            raise RemoteObservationFailure("Google Drive respondeu à exportação sem conteúdo")
        return response.content

    async def batch_update(
        self,
        google_doc_id: str,
        *,
        requests: list[dict[str, Any]],
        required_revision_id: str,
    ) -> GoogleBatchResult:
        if not requests:
            raise ValueError("batchUpdate requer ao menos uma request")
        try:
            response = await self.client.post(
                f"{DOCS_BASE}/v1/documents/{google_doc_id}:batchUpdate",
                headers=self._headers,
                json={
                    "requests": requests,
                    "writeControl": {"requiredRevisionId": required_revision_id},
                },
            )
        except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=False) from exc
        except httpx.HTTPError as exc:
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=True) from exc
        if response.status_code == 404:
            raise RemoteWriteFailure(
                f"Google Doc {google_doc_id} ausente ou invisível",
                effect_may_have_occurred=False,
            )
        if 400 <= response.status_code < 500:
            raise RemoteWriteFailure(
                f"Google Docs rejeitou batchUpdate com HTTP {response.status_code}",
                effect_may_have_occurred=False,
            )
        if response.status_code >= 500:
            raise RemoteWriteFailure(
                f"Google Docs respondeu HTTP {response.status_code} após batchUpdate",
                effect_may_have_occurred=True,
            )
        try:
            parsed = _BatchResponse.model_validate(response.json())
        except (ValueError, ValidationError) as exc:
            raise RemoteWriteFailure(
                "Google Docs aceitou a escrita, mas retornou resposta inválida",
                effect_may_have_occurred=True,
            ) from exc
        revision = parsed.writeControl.requiredRevisionId if parsed.writeControl else None
        if not revision:
            raise RemoteWriteFailure(
                "Google Docs aceitou a escrita, mas não retornou a revisão resultante",
                effect_may_have_occurred=True,
            )
        return GoogleBatchResult(revision_id=revision, replies=parsed.replies)


def _document_end_index(payload: dict[str, Any]) -> int:
    candidates: list[int] = []

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            end = value.get("endIndex")
            if isinstance(end, int):
                candidates.append(end)
            for nested in value.values():
                visit(nested)
        elif isinstance(value, list):
            for nested in value:
                visit(nested)

    visit(payload.get("body", {}))
    visit(payload.get("tabs", []))
    return max(candidates, default=1)
