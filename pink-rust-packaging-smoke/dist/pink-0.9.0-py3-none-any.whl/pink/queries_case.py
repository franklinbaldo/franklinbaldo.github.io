"""Physical Ibis queries for expediente and documento read capabilities."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date, timedelta

import ibis
from ibis.expr import types as ir

from pink import schema


def _tarefas_abertas_base(
    *,
    setor_ids: Sequence[int] | ir.IntegerColumn | None = None,
    pasta_id: int | None = None,
):
    t = schema.tarefas
    p = schema.pastas
    if setor_ids is not None:
        pastas_da_selecao = p.filter(p.apagado_em.isnull() & p.setores_id.isin(setor_ids)).select(
            pasta_id=p.id
        )
        t = t.filter(t.pastas_id.isin(pastas_da_selecao.pasta_id))
    if pasta_id is not None:
        t = t.filter(t.pastas_id == pasta_id)
    return t.filter(
        t.apagado_em.isnull() & t.data_hora_conclusao_prazo.isnull() & t.expediente_id.notnull()
    )


def tarefas_abertas_for_expedientes(expediente_ids: Sequence[int]):
    """One row per open task; grouping into ids happens losslessly in Python."""
    t = schema.tarefas
    return (
        t.filter(
            t.apagado_em.isnull()
            & t.data_hora_conclusao_prazo.isnull()
            & t.expediente_id.isin(expediente_ids)
        )
        .select(expediente_id=t.expediente_id, tarefa_id=t.id)
        .order_by(t.expediente_id, t.id)
    )


def tarefas_abertas_for_expediente(expediente_id: int):
    """Stable one-expediente shape used as Saved-Card fallback."""
    t = schema.tarefas
    return (
        t.filter(
            t.apagado_em.isnull()
            & t.data_hora_conclusao_prazo.isnull()
            & (t.expediente_id == expediente_id)
        )
        .select(expediente_id=t.expediente_id, tarefa_id=t.id)
        .order_by(t.id)
    )


def expedientes_filter(
    *,
    setor_ids: Sequence[int] | ir.IntegerColumn | None = None,
    processo: str | None = None,
    pasta_id: int | None = None,
    aberto: bool | None = None,
    prazo_de: date | None = None,
    prazo_ate: date | None = None,
    tipo: int | None = None,
    com_tarefa: bool | None = None,
):
    e = schema.expedientes
    p = schema.pastas
    s = schema.setores
    pj = schema.processos_jud

    pastas_ativas = p.filter(p.apagado_em.isnull())
    if setor_ids is not None:
        pastas_ativas = pastas_ativas.filter(p.setores_id.isin(setor_ids))

    q = (
        e.inner_join(pastas_ativas, e.pastas_id == pastas_ativas.id)
        .inner_join(s, pastas_ativas.setores_id == s.id)
        .left_join(pj, pastas_ativas.processos_judiciais_id == pj.id)
        .select(
            expediente_id=e.id,
            pasta_id=pastas_ativas.id,
            setor=s.sigla,
            numero=pj.numero,
            tipo=e.tipo,
            prazo=e.prazo,
            fechado=e.fechado.cast("boolean"),
            criado_em=e.criado_em,
            documento_id=e.documento_id,
            tarefas_ids=ibis.null().cast("string"),
        )
    )
    if processo is not None:
        q = q.filter(q.numero == processo)
    if pasta_id is not None:
        q = q.filter(q.pasta_id == pasta_id)
    if aberto is True:
        q = q.filter(~q.fechado)
    elif aberto is False:
        q = q.filter(q.fechado)
    if tipo is not None:
        q = q.filter(q.tipo == tipo)
    if com_tarefa is not None:
        open_tasks = _tarefas_abertas_base(setor_ids=setor_ids, pasta_id=pasta_id).select(
            expediente_id=schema.tarefas.expediente_id
        )
        condition = q.expediente_id.isin(open_tasks.expediente_id)
        q = q.filter(condition if com_tarefa else ~condition)
    if prazo_de is not None:
        q = q.filter(q.prazo >= prazo_de)
    if prazo_ate is not None:
        q = q.filter(q.prazo < prazo_ate + timedelta(days=1))
    return q.order_by(q.fechado, q.prazo, q.expediente_id)


def expediente_detail(expediente_id: int):
    e = schema.expedientes
    p = schema.pastas
    s = schema.setores
    pj = schema.processos_jud
    d = schema.documentos
    return (
        e.filter(e.id == expediente_id)
        .inner_join(p, [e.pastas_id == p.id, p.apagado_em.isnull()])
        .inner_join(s, p.setores_id == s.id)
        .left_join(pj, p.processos_judiciais_id == pj.id)
        .left_join(d, e.documento_id == d.id)
        .select(
            expediente_id=e.id,
            pasta_id=p.id,
            setor=s.sigla,
            processo_id=pj.id,
            numero=pj.numero,
            tipo=e.tipo,
            teor=e.teor,
            prazo=e.prazo,
            fechado=e.fechado.cast("boolean"),
            criado_em=e.criado_em,
            documento_id=e.documento_id,
            documento_autor=d.autor,
        )
    )


def comentarios_for_expediente(expediente_id: int):
    c = schema.expedientes_comentario
    return (
        c.filter((c.expedientes_id == expediente_id) & c.apagado_em.isnull())
        .select(
            comentario_id=c.id,
            comentario=c.comentario,
            criado_em=c.criado_em,
            criado_por=c.criado_por,
        )
        .order_by(c.criado_em)
    )


def documentos_filter(
    *,
    processo: str | None = None,
    pasta_id: int | None = None,
    tarefa_id: int | None = None,
    minuta: bool | None = None,
    termo: str | None = None,
    tipo: str | None = None,
):
    d = schema.documentos
    p = schema.pastas
    pj = schema.processos_jud
    td = schema.tipos_documentos
    q = (
        d.filter(d.apagado_em.isnull())
        .left_join(p, [d.pastas_destinatario_id == p.id, p.apagado_em.isnull()])
        .left_join(pj, p.processos_judiciais_id == pj.id)
        .left_join(td, d.tipos_documentos_id == td.id)
        .select(
            documento_id=d.id,
            pasta_id=p.id,
            numero=pj.numero,
            tarefa_id=d.tarefas_origem_id,
            autor=d.autor,
            redator=d.redator,
            observacao=d.observacao,
            produzido_em=d.data_hora_producao,
            criado_em=d.criado_em,
            minuta=d.minuta.cast("boolean"),
            tipo=td.nome,
            tipo_sigla=td.sigla,
        )
    )
    if processo is not None:
        q = q.filter(q.numero == processo)
    if pasta_id is not None:
        q = q.filter(q.pasta_id == pasta_id)
    if tarefa_id is not None:
        q = q.filter(q.tarefa_id == tarefa_id)
    if minuta is not None:
        q = q.filter(q.minuta == minuta)
    if tipo is not None:
        normalized_type = tipo.strip().lower()
        if normalized_type:
            q = q.filter(
                (q.tipo.lower() == normalized_type) | (q.tipo_sigla.lower() == normalized_type)
            )
    if termo is not None:
        normalized_term = termo.strip().lower()
        if normalized_term:
            q = q.filter(
                q.autor.lower().contains(normalized_term)
                | q.redator.lower().contains(normalized_term)
                | q.observacao.lower().contains(normalized_term)
                | q.tipo.lower().contains(normalized_term)
                | q.tipo_sigla.lower().contains(normalized_term)
            )
    return q.order_by(q.criado_em, q.documento_id)


def documento_detail(documento_id: int):
    q = documentos_filter()
    return q.filter(q.documento_id == documento_id)


def componente_mimetype(componente_id: int):
    c = schema.componentes_digitais
    return c.filter((c.id == componente_id) & c.apagado_em.isnull()).select(mimetype=c.mimetype)


def componentes_for_documento(documento_id: int):
    c = schema.componentes_digitais
    return (
        c.filter((c.documentos_id == documento_id) & c.apagado_em.isnull())
        .select(
            componente_id=c.id,
            google_doc_id=c.google_doc_id,
            file_name=c.file_name,
            hash=c.hash,
            tamanho=c.tamanho,
            mimetype=c.mimetype,
            extensao=c.extensao,
            criado_em=c.criado_em,
        )
        .order_by(c.id)
    )
