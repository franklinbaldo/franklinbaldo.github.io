"""Read-only resources behind submitted-operation handles.

A submitted write is only useful to an agent if its explicit handle can be
reobserved. These Resources expose the narrow observation needed for the
specific pending effect; they are not a workflow engine and do not prescribe a
next action.

Every observed field here is an `Observacao`, never a bare value. `Submetida`
and `Ambigua` are emitted precisely when the source could not be read after a
known dispatch, so the Resource behind the handle must be able to say "not yet
determinable" -- as `desconhecido` with the reason -- instead of raising. Known
unavailability of the integration is one of those reasons. Inconclusive never
becomes an observed `False`, an observed empty set or a fictional absence.
"""

from __future__ import annotations

from typing import cast

from pydantic import Field, TypeAdapter

from pink.catalogo import Catalogo, Conteudo
from pink.documento_write import DocumentoKanoe
from pink.domain_types import (
    CaixaId,
    CorrenteTematicaId,
    DocumentoId,
    ExpedienteId,
    PastaId,
    SetorSigla,
    TarefaId,
    TramitacaoId,
)
from pink.expediente import _obter as obter_expediente
from pink.integrations import Probe
from pink.models import Desconhecido, Disponibilidade, Observacao, Observado, PinkModel
from pink.system import Runtime
from pink.tarefa import _obter as obter_tarefa
from pink.write_safety import RemoteObservationFailure

_TAREFA_ID = TypeAdapter(TarefaId)
_EXPEDIENTE_ID = TypeAdapter(ExpedienteId)
_PASTA_ID = TypeAdapter(PastaId)
_TRAMITACAO_ID = TypeAdapter(TramitacaoId)
_SETOR_SIGLA = TypeAdapter(SetorSigla)


class TarefaPendenteObservacao(PinkModel):
    """Live Kanoê projection used to reconcile task creation."""

    tarefa_id: TarefaId = Field(description="Identidade da tarefa reobservada")
    pendente: Observacao[bool] = Field(
        description=(
            "`observado` com True quando a tarefa aparece na projeção live de pendentes, "
            "com False quando não aparece; `desconhecido` quando a fonte não permitiu determinar"
        )
    )


class TarefaDocumentosObservacao(PinkModel):
    """Live Kanoê document identities used to reconcile upload/delete effects."""

    tarefa_id: TarefaId = Field(
        description="Tarefa cuja coleção live de documentos foi reobservada"
    )
    documento_ids: Observacao[tuple[DocumentoId, ...]] = Field(
        description=(
            "`observado` com as identidades dos documentos atualmente na tarefa; "
            "`desconhecido` quando a coleção não pôde ser reobservada"
        )
    )


class ExpedienteFechadoObservacao(PinkModel):
    """Live Kanoê open/closed state used to reconcile expediente creation/state writes."""

    expediente_id: ExpedienteId = Field(description="Identidade do expediente reobservado")
    fechado: Observacao[bool] = Field(
        description=(
            "`observado` com True quando o expediente está fechado, False quando aberto; "
            "`desconhecido` quando o estado não pôde ser reobservado"
        )
    )


class PastaAnotacaoObservacao(PinkModel):
    """Live Kanoê annotation used to reconcile a submitted replacement."""

    pasta_id: PastaId = Field(description="Identidade da pasta reobservada")
    anotacao: Observacao[str | None] = Field(
        description=(
            "`observado` com a anotação atual (None é ausência de anotação observada); "
            "`desconhecido` quando a anotação não pôde ser reobservada"
        )
    )


class PastaOrganizacaoValor(PinkModel):
    """Box and thematic currents as observed together in one Kanoê read."""

    caixa_id: CaixaId | None = Field(
        description="Caixa atualmente associada à pasta no setor; None representa ausência de caixa"
    )
    corrente_ids: tuple[CorrenteTematicaId, ...] = Field(
        description="Conjunto atualmente observado de correntes temáticas da pasta no setor"
    )


class PastaOrganizacaoObservacao(PinkModel):
    """Live Kanoê organization state for one pasta within one sector."""

    pasta_id: PastaId = Field(description="Identidade da pasta reobservada")
    setor: SetorSigla = Field(description="Setor no qual a organização da pasta foi observada")
    organizacao: Observacao[PastaOrganizacaoValor] = Field(
        description=(
            "`observado` com caixa e correntes da pasta no setor, lidas juntas; "
            "`desconhecido` quando a organização não pôde ser reobservada"
        )
    )


class TramitacaoPendenteObservacao(PinkModel):
    """Live Kanoê pending state for one specific tramitação.

    `pendente` é uma `Observacao`, não um bool, porque a fonte tem um terceiro
    resultado além de sim e não: não deu para determinar. Depois de um
    `tramitacao_receber` despachado o efeito volta `Submetida` apontando para
    este Resource, e um handle que só sabe levantar erro não é reobservável --
    uma leitura inconclusiva chega aqui como `Desconhecido` com o motivo, e o
    agente relê mais tarde.

    Inconclusivo nunca vira `Observado(valor=False)`: ausência ou leitura
    ilegível não provam que o recebimento aconteceu.
    """

    pasta_id: PastaId = Field(description="Pasta à qual a tramitação pertence")
    tramitacao_id: TramitacaoId = Field(description="Identidade da tramitação reobservada")
    pendente: Observacao[bool] = Field(
        description=(
            "`observado` com True quando a tramitação ainda aparece pendente para "
            "recebimento, com False quando o Kanoê a mostra fora da fila; "
            "`desconhecido` quando esta fonte não permitiu determinar"
        )
    )


async def _require_available(source: Probe, *, nome: str = "Kanoê") -> None:
    """Turn known integration unavailability into Resource read semantics."""
    status = await source.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        raise RemoteObservationFailure(status.detalhe or f"{nome} indisponível")


def build_submitted_resource_catalogo(runtime: Runtime) -> Catalogo:
    """Expose every currently emitted submitted-operation handle as a live Resource."""
    catalogo = Catalogo()
    documento_kanoe = cast(DocumentoKanoe, runtime.kanoe)
    kanoe = runtime.kanoe
    metabase = runtime.metabase

    @catalogo.recurso(
        "kanoe://tarefa/{tarefa_id}/estado",
        mime="application/json",
        tags={"write-state", "read", "kanoe"},
    )
    async def tarefa_estado(tarefa_id: str) -> Conteudo:
        """Reobserve whether a task is present in the live pending projection."""
        identity = _TAREFA_ID.validate_python(tarefa_id)
        try:
            await _require_available(kanoe)
            pendente: Observacao[bool] = Observado[bool](valor=await kanoe.tarefa_pending(identity))
        except RemoteObservationFailure as exc:
            pendente = Desconhecido(motivo=str(exc))
        conteudo = TarefaPendenteObservacao(tarefa_id=identity, pendente=pendente).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "kanoe://tarefa/{tarefa_id}/documentos",
        mime="application/json",
        tags={"write-state", "read", "kanoe"},
    )
    async def tarefa_documentos(tarefa_id: str) -> Conteudo:
        """Reobserve the live document identities for a submitted task write."""
        identity = _TAREFA_ID.validate_python(tarefa_id)
        try:
            await _require_available(documento_kanoe)
            documents = await documento_kanoe.task_documents(identity)
            documento_ids: Observacao[tuple[DocumentoId, ...]] = Observado[tuple[DocumentoId, ...]](
                valor=tuple(item.documento_id for item in documents)
            )
        except RemoteObservationFailure as exc:
            documento_ids = Desconhecido(motivo=str(exc))
        conteudo = TarefaDocumentosObservacao(
            tarefa_id=identity, documento_ids=documento_ids
        ).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "pink://tarefa/{tarefa_id}",
        mime="application/json",
        tags={"write-state", "read", "tarefa", "metabase"},
    )
    async def tarefa_detalhe(tarefa_id: str) -> Conteudo:
        """Reobserve full task detail, including comments, after a submitted comment/delete."""
        identity = _TAREFA_ID.validate_python(tarefa_id)
        result = await obter_tarefa(metabase, identity)
        conteudo = result.model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "kanoe:expediente:{expediente_id}",
        mime="application/json",
        tags={"write-state", "read", "kanoe"},
    )
    async def expediente_estado(expediente_id: str) -> Conteudo:
        """Reobserve the live open/closed state behind a submitted expediente write."""
        identity = _EXPEDIENTE_ID.validate_python(expediente_id)
        try:
            await _require_available(kanoe)
            fechado: Observacao[bool] = Observado[bool](
                valor=await kanoe.expediente_closed(identity)
            )
        except RemoteObservationFailure as exc:
            fechado = Desconhecido(motivo=str(exc))
        conteudo = ExpedienteFechadoObservacao(
            expediente_id=identity, fechado=fechado
        ).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "pink://expediente/{expediente_id}",
        mime="application/json",
        tags={"write-state", "read", "expediente", "metabase"},
    )
    async def expediente_detalhe(expediente_id: str) -> Conteudo:
        """Reobserve full expediente detail, including comments, after a submitted comment."""
        identity = _EXPEDIENTE_ID.validate_python(expediente_id)
        result = await obter_expediente(metabase, identity)
        conteudo = result.model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "kanoe:pasta:{pasta_id}:anotacao",
        mime="application/json",
        tags={"write-state", "read", "pasta", "kanoe"},
    )
    async def pasta_anotacao(pasta_id: str) -> Conteudo:
        """Reobserve the annotation after a submitted replacement."""
        identity = _PASTA_ID.validate_python(pasta_id)
        try:
            await _require_available(kanoe)
            anotacao: Observacao[str | None] = Observado[str | None](
                valor=await kanoe.pasta_annotation(identity)
            )
        except RemoteObservationFailure as exc:
            anotacao = Desconhecido(motivo=str(exc))
        conteudo = PastaAnotacaoObservacao(pasta_id=identity, anotacao=anotacao).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "kanoe:pasta:{pasta_id}:organizacao:{setor}",
        mime="application/json",
        tags={"write-state", "read", "pasta", "kanoe"},
    )
    async def pasta_organizacao(pasta_id: str, setor: str) -> Conteudo:
        """Reobserve box and thematic currents for one pasta/sector pair."""
        identity = _PASTA_ID.validate_python(pasta_id)
        setor_sigla = _SETOR_SIGLA.validate_python(setor)
        try:
            await _require_available(kanoe)
            organization = await kanoe.pasta_organization(identity, setor_sigla)
            organizacao: Observacao[PastaOrganizacaoValor] = Observado[PastaOrganizacaoValor](
                valor=PastaOrganizacaoValor(
                    caixa_id=organization.caixa_id, corrente_ids=organization.corrente_ids
                )
            )
        except RemoteObservationFailure as exc:
            organizacao = Desconhecido(motivo=str(exc))
        conteudo = PastaOrganizacaoObservacao(
            pasta_id=identity, setor=setor_sigla, organizacao=organizacao
        ).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    @catalogo.recurso(
        "kanoe:pasta:{pasta_id}:tramitacao:{tramitacao_id}",
        mime="application/json",
        tags={"write-state", "read", "pasta", "tramitacao", "kanoe"},
    )
    async def tramitacao_estado(pasta_id: str, tramitacao_id: str) -> Conteudo:
        """Reobserve whether one tramitação still awaits receipt."""
        pasta_identity = _PASTA_ID.validate_python(pasta_id)
        tramitacao_identity = _TRAMITACAO_ID.validate_python(tramitacao_id)
        try:
            # A indisponibilidade entra no mesmo `try`: Kanoê fora do ar é um
            # motivo de não saber, e o handle continua relegível.
            await _require_available(kanoe)
            pendente: Observacao[bool] = Observado[bool](
                valor=await kanoe.tramitacao_pending(pasta_identity, tramitacao_identity)
            )
        except RemoteObservationFailure as exc:
            # O handle promete ser relegível, não conclusivo. 404, envelope
            # ilegível ou linha ausente da resposta são estado que o agente lê e
            # relê, não erro de leitura.
            pendente = Desconhecido(motivo=str(exc))
        conteudo = TramitacaoPendenteObservacao(
            pasta_id=pasta_identity,
            tramitacao_id=tramitacao_identity,
            pendente=pendente,
        ).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    return catalogo
