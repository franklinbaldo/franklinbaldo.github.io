"""Physical Ibis queries for processo/pasta context aggregation."""

from __future__ import annotations

from pink import schema
from pink.domain_types import cnj_storage_variants


def processos_por_cnj(cnj: str):
    """Return every active physical processo row matching formatted or digits-only CNJ."""
    pj = schema.processos_jud
    cc = schema.classes_cnj
    variants = cnj_storage_variants(cnj)
    return (
        pj.filter(pj.numero.isin(variants) & pj.apagado_em.isnull())
        .left_join(cc, pj.classes_nacional_id == cc.id)
        .select(
            processo_id=pj.id,
            numero=pj.numero,
            fonte_dados=pj.fonte_dados,
            competencia=pj.competencia,
            valor_causa=pj.valor_causa,
            ajuizado_em=pj.data_hora_ajuizamento,
            criado_em=pj.criado_em,
            atualizado_em=pj.atualizado_em,
            classe=cc.nome,
            classe_codigo=cc.codigo_nacional,
            orgao_julgador_id=pj.orgaos_julgadores_id,
        )
        .order_by(pj.criado_em, pj.id)
    )


def pastas_por_cnj(cnj: str):
    pj = schema.processos_jud
    p = schema.pastas
    s = schema.setores
    ids = processos_por_cnj(cnj).select("processo_id")
    return (
        p.filter(p.apagado_em.isnull())
        .inner_join(pj, p.processos_judiciais_id == pj.id)
        .inner_join(ids, pj.id == ids.processo_id)
        .inner_join(s, p.setores_id == s.id)
        .select(
            pasta_id=p.id,
            processo_id=pj.id,
            anotacao=p.anotacao,
            aberto_em=p.data_hora_abertura,
            atualizado_em=p.atualizado_em,
            status=p.status_pasta,
            setor=s.sigla,
        )
        .order_by(p.id)
    )


def pasta_autarquia(pasta_id: int | None = None):
    """Preserve the label FK even when its sector or CNPJ cannot be resolved."""
    p = schema.pastas
    s = schema.setores
    scoped = p.filter(p.apagado_em.isnull())
    if pasta_id is not None:
        scoped = scoped.filter(p.id == pasta_id)
    return scoped.left_join(s, p.setor_responsavel_etiqueta == s.id).select(
        pasta_id=p.id,
        setor_responsavel_etiqueta_id=p.setor_responsavel_etiqueta,
        setor_responsavel_etiqueta_sigla=s.sigla,
        setor_responsavel_etiqueta_nome=s.nome,
        setor_responsavel_etiqueta_cnpj=s.cnpj,
    )


def pasta_detail(pasta_id: int):
    p = schema.pastas
    s = schema.setores
    pj = schema.processos_jud
    cc = schema.classes_cnj
    autarquia = pasta_autarquia(pasta_id)
    return (
        p.filter((p.id == pasta_id) & p.apagado_em.isnull())
        .inner_join(s, p.setores_id == s.id)
        .left_join(pj, p.processos_judiciais_id == pj.id)
        .left_join(cc, pj.classes_nacional_id == cc.id)
        .left_join(autarquia, p.id == autarquia.pasta_id)
        .select(
            setor_responsavel_etiqueta_id=autarquia.setor_responsavel_etiqueta_id,
            setor_responsavel_etiqueta_sigla=autarquia.setor_responsavel_etiqueta_sigla,
            setor_responsavel_etiqueta_nome=autarquia.setor_responsavel_etiqueta_nome,
            setor_responsavel_etiqueta_cnpj=autarquia.setor_responsavel_etiqueta_cnpj,
            pasta_id=p.id,
            outro_numero=p.outroNumero,
            anotacao=p.anotacao,
            aberto_em=p.data_hora_abertura,
            atualizado_em=p.atualizado_em,
            status=p.status_pasta,
            setor=s.sigla,
            processo_id=pj.id,
            numero=pj.numero,
            fonte_dados=pj.fonte_dados,
            competencia=pj.competencia,
            valor_causa=pj.valor_causa,
            ajuizado_em=pj.data_hora_ajuizamento,
            classe=cc.nome,
            classe_codigo=cc.codigo_nacional,
        )
    )


def pasta_resumo_latest(pasta_id: int):
    r = schema.pasta_resumo
    scoped = r.filter((r.pasta_id == pasta_id) & r.apagado_em.isnull())
    return (
        scoped.order_by(scoped.versao.desc(), scoped.id.desc())
        .limit(1)
        .select(
            resumo_id=scoped.id,
            resumo=scoped.resumo,
            versao=scoped.versao,
            criado_em=scoped.criado_em,
        )
    )


def correntes_for_pasta(pasta_id: int):
    link = schema.pastas_corrente_tematica
    corrente = schema.corrente_tematica
    return (
        link.filter(link.pastas_id == pasta_id)
        .inner_join(
            corrente,
            [
                link.corrente_tematica_id == corrente.id,
                corrente.apagado_em.isnull(),
                corrente.ativo == 1,
            ],
        )
        .select(corrente_id=corrente.id, nome=corrente.nome, descricao=corrente.descricao)
        .order_by(corrente.nome)
    )
