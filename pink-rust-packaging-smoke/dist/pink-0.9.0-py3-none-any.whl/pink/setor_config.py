"""Shared sector configuration contracts and local persistence boundary."""

from pathlib import Path
import logging
import os
import stat
import tempfile
from typing import Any, Protocol

import tomlkit

from pydantic import ConfigDict, Field, field_serializer, field_validator

from pink.models import PinkModel

logger = logging.getLogger(__name__)
_CAMPOS_CREDENCIAIS = (
    "metabase_password",
    "caipora_senha",
    "kanoe_authorization",
    "google_authorization",
)


class PeticaoSetor(PinkModel):
    """Shared document assets; paths are relative to the sector's pink.toml."""

    model_config = ConfigDict(extra="ignore", frozen=True)
    modelo_id: int | None = Field(default=None, gt=0)
    modelo: Path | None = None
    timbrado: Path | None = None
    css: Path | None = None

    @field_validator("modelo", "timbrado", "css")
    @classmethod
    def caminho_relativo(cls, value: Path | None) -> Path | None:
        if value is not None and value.is_absolute():
            raise ValueError("use um caminho relativo ao pink.toml do setor")
        return value

    @field_serializer("modelo", "timbrado", "css", when_used="json")
    def caminho_portavel(self, value: Path | None) -> str | None:
        return value.as_posix() if value is not None else None


class ConfiguracaoSetor(PinkModel):
    """Project-owned defaults, independent of an operator's credentials."""

    model_config = ConfigDict(extra="ignore", frozen=True)
    setor: str | None = None
    metabase_collection_id: int | None = Field(default=None, gt=0)
    peticao: PeticaoSetor = Field(default_factory=PeticaoSetor)

    @field_validator("setor")
    @classmethod
    def setor_nao_vazio(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("informe a sigla do setor no Kanoê")
        return value


class ConfiguracaoSetorSalva(PinkModel):
    """The shared configuration reread after a local save."""

    arquivo: Path
    configuracao: ConfiguracaoSetor


class PeticaoSetorEmEdicao(PinkModel):
    """Unvalidated local values that an operator can replace before saving."""

    model_config = ConfigDict(extra="ignore", frozen=True)
    modelo_id: Any = None
    modelo: Any = None
    timbrado: Any = None
    css: Any = None


class ConfiguracaoSetorEmEdicao(PinkModel):
    """Editable input preserves invalid legacy values until final validation."""

    model_config = ConfigDict(extra="ignore", frozen=True)
    setor: Any = None
    metabase_collection_id: Any = None
    peticao: PeticaoSetorEmEdicao = Field(default_factory=PeticaoSetorEmEdicao)


class RepositorioConfiguracaoSetor(Protocol):
    """Read and update a sector without replacing unrelated consumer settings."""

    def ler(self) -> ConfiguracaoSetor: ...

    def ler_para_edicao(self) -> ConfiguracaoSetorEmEdicao: ...

    def salvar(self, configuracao: ConfiguracaoSetor) -> ConfiguracaoSetorSalva: ...


class DialogoSetor(Protocol):
    """Interactive inputs are separate from configuration validation and storage."""

    def perguntar(self, campo: str, atual: str) -> str: ...

    def confirmar(self, mensagem: str) -> bool: ...


def atualizar_toml(path: Path, updates: dict[str, Any]) -> None:
    """Merge known fields atomically, retaining unrelated tables and comments."""
    document = (
        tomlkit.parse(path.read_text(encoding="utf-8")) if path.exists() else tomlkit.document()
    )
    for key, value in updates.items():
        if isinstance(value, dict):
            if key not in document:
                document[key] = tomlkit.table()
            table = document[key]
            for field, item in value.items():
                if item is None:
                    table.pop(field, None)
                else:
                    table[field] = item
        elif value is None:
            document.pop(key, None)
        else:
            document[key] = value
    removed = [key for key in _CAMPOS_CREDENCIAIS if key in document]
    for key in removed:
        del document[key]
    previous_mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else None
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, delete=False
        ) as handle:
            temporary = Path(handle.name)
            handle.write(tomlkit.dumps(document))
        if previous_mode is not None:
            os.chmod(temporary, previous_mode)
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    if removed:
        logger.warning(
            "Credenciais removidas do TOML compartilhado (%s); configure-as com pink auth ou ambiente.",
            ", ".join(removed),
        )


class TomlSetor:
    """Project file adapter; shared assets are checked without executing them."""

    def __init__(self, path: Path = Path("pink.toml")) -> None:
        self.path = path

    def ler(self) -> ConfiguracaoSetor:
        return ConfiguracaoSetor.model_validate(self.ler_para_edicao().model_dump())

    def ler_para_edicao(self) -> ConfiguracaoSetorEmEdicao:
        document = (
            tomlkit.parse(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
        )
        return ConfiguracaoSetorEmEdicao.model_validate(document)

    def salvar(self, configuracao: ConfiguracaoSetor) -> ConfiguracaoSetorSalva:
        if configuracao.setor is None:
            raise ValueError("informe --setor com a sigla do setor no Kanoê")
        for asset in (
            configuracao.peticao.modelo,
            configuracao.peticao.timbrado,
            configuracao.peticao.css,
        ):
            if asset is not None and not (self.path.parent / asset).is_file():
                raise ValueError(f"arquivo do setor não encontrado: {self.path.parent / asset}")
        atualizar_toml(self.path, configuracao.model_dump(mode="json"))
        return ConfiguracaoSetorSalva(arquivo=self.path, configuracao=self.ler())


def configurar_setor(
    repositorio: RepositorioConfiguracaoSetor,
    *,
    alteracoes: ConfiguracaoSetor,
    dialogo: DialogoSetor | None = None,
) -> ConfiguracaoSetorSalva | None:
    """Create or amend one sector; interactive cancellation leaves the file intact."""
    current = repositorio.ler_para_edicao().model_dump()
    if dialogo is not None:
        for key, label in (
            ("setor", "Sigla do setor no Kanoê"),
            ("metabase_collection_id", "ID da coleção Metabase (opcional)"),
            ("modelo_id", "ID do modelo compartilhado no Kanoê (opcional)"),
            ("modelo", "Arquivo de modelo (opcional)"),
            ("timbrado", "Arquivo do cabeçalho/timbrado (opcional)"),
            ("css", "Folha de estilo CSS (opcional)"),
        ):
            target = current if key in {"setor", "metabase_collection_id"} else current["peticao"]
            previous = target[key]
            value = dialogo.perguntar(label, str(previous) if previous is not None else "")
            if value:
                target[key] = None if value == "-" else value
    for key, value in alteracoes.model_dump(mode="json", exclude_unset=True).items():
        if key == "peticao":
            current[key].update(value)
        else:
            current[key] = value
    configuration = ConfiguracaoSetor.model_validate(current)
    if dialogo is not None and not dialogo.confirmar(
        f"Configuração do setor:\n{configuration.model_dump_json(indent=2)}\nSalvar em pink.toml?"
    ):
        return None
    return repositorio.salvar(configuration)
