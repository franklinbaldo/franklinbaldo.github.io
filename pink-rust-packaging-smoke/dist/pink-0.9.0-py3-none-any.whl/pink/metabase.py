"""Async production Metabase adapter for Pink 0.8.

The domain boundary receives Ibis expressions. SQL exists only here, at the
transport edge, and is never part of a capability contract or a test fake API.
Saved Cards and the direct REST API are alternate Metabase transports; no
Card id, hash, template tag or REST payload leaks into domain capabilities.
"""

from __future__ import annotations

from typing import Any, Literal

import json

import httpx
import ibis
import ibis.expr.operations as ops
from ibis.expr import types as ir
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SecretStr,
    ValidationError,
    JsonValue,
    model_validator,
)

from pydantic.experimental.missing_sentinel import MISSING

from pink.metabase_cards import CARD_SPECS, CardSpec, match_sql, provisioned_card_name
from pink.metabase_session import (
    delete_metabase_session,
    get_metabase_session,
    save_metabase_session,
)
from pink.models import Disponibilidade, IntegracaoStatus, PinkModel
from pink.write_safety import ConsultaSemCard, RemoteObservationFailure, RemoteWriteFailure


class MetabaseConfig(PinkModel):
    """Explicit runtime configuration for the Metabase integration."""

    base_url: str = Field(description="Base URL do Metabase, sem dependência de path específico")
    database: str = Field(
        default="ratio",
        description="Nome do banco Caipora no Metabase; o id é descoberto por ele quando não configurado",
    )
    database_id: int | None = Field(
        default=None, gt=0, description="ID do banco Caipora dentro do Metabase, quando configurado"
    )
    collection_id: int | None = Field(
        default=None, gt=0, description="Coleção escolhida pelo setor para as Cards Pink"
    )
    email: str | None = Field(default=None, description="Login do Metabase")
    password: SecretStr | None = Field(default=None, description="Senha do Metabase")


class MetabaseError(RuntimeError):
    """Base failure translated by the Metabase boundary."""


class MetabaseAuthenticationError(MetabaseError):
    """Credentials are absent or rejected."""


class MetabasePermissionError(MetabaseError):
    """Metabase is reachable but the requested operation is not permitted."""


class MetabaseResponseError(MetabaseError):
    """Metabase returned a malformed or failed response."""


class ObservacaoTruncada(RemoteObservationFailure):
    """The source answered but cut the selection short.

    Fail-closed is not "error without data": the rows Metabase did send are
    real observations and travel with the failure, so a collection can return
    them as `Parcial` instead of pretending the selection was satisfied.
    """

    def __init__(self, *, linhas: list[dict[str, Any]], truncado_em: int) -> None:
        super().__init__(
            f"Metabase truncou a resposta em {truncado_em} linhas; a seleção pedida não coube"
        )
        self.linhas = linhas
        self.truncado_em = truncado_em


class _RemoteModel(BaseModel):
    """Integration DTOs ignore unrelated Metabase response fields by design."""

    model_config = ConfigDict(extra="ignore")


class _Column(_RemoteModel):
    name: str


class _Data(_RemoteModel):
    cols: list[_Column]
    rows: list[list[Any]]
    # O Metabase marca aqui quando o resultado encostou no `constraints` da
    # requisição (o default, sem constraints, era 2000 -- nunca um limite da
    # fonte). Ignorar a marca apresentou um setor de milhares de pastas como
    # "2000, total exato".
    rows_truncated: int | None = None


class _DatasetResponse(_RemoteModel):
    data: _Data


class _SessionResponse(_RemoteModel):
    id: str


class _Database(_RemoteModel):
    id: int
    name: str


class _Databases(_RemoteModel):
    data: list[_Database] = Field(default_factory=list)


def _card_parameter(name: str, value: Any) -> dict[str, Any]:
    """Metabase template-tag parameter inferred from the value's scalar type."""
    number = isinstance(value, (int, float)) and not isinstance(value, bool)
    return {
        "type": "number" if number else "text",
        "target": ["variable", ["template-tag", name]],
        "value": value if number else str(value),
    }


class CardProvisionamento(PinkModel):
    """One validated outcome of explicit Card provisioning."""

    query: str = Field(min_length=1, description="Nome da consulta registrada")
    estado: Literal["existente", "criada", "dry_run"] = Field(
        description="Resultado observado do provisionamento"
    )
    card_id: int | None = Field(
        default=None, gt=0, description="ID da Card observada; ausente apenas em dry_run"
    )

    @model_validator(mode="after")
    def identity_matches_state(self) -> CardProvisionamento:
        if (self.estado == "dry_run") != (self.card_id is None):
            raise ValueError("dry_run não tem Card; criada/existente exigem um ID observado")
        return self


class RelatorioProvisionamentoCards(PinkModel):
    """Public administrative report consumable by the sector's automation."""

    collection_id: int = Field(gt=0, description="Coleção escolhida pelo consumidor")
    dry_run: bool = Field(description="True quando a chamada apenas observa o que falta")
    cards: list[CardProvisionamento] = Field(
        min_length=1, description="Resultado de cada consulta selecionada"
    )
    pronto: bool = Field(description="Todas as Cards selecionadas existem e foram conferidas")

    @model_validator(mode="after")
    def estado_coerente(self) -> RelatorioProvisionamentoCards:
        if self.pronto != all(card.estado != "dry_run" for card in self.cards):
            raise ValueError("prontidão diverge dos resultados observados")
        return self


def validate_api_path(path: str) -> str:
    """Validate the relative raw path before any authentication or dispatch."""
    url = httpx.URL(path)
    if url.is_absolute_url or url.host:
        raise ValueError("path deve ser relativo à API /api/ do Metabase configurado")
    url = httpx.URL("https://metabase.invalid").join(url)
    if not url.path.startswith("/api/"):
        raise ValueError("path deve ser relativo à API /api/ do Metabase configurado")
    if url.query or url.fragment or "\\" in path:
        raise ValueError("use query para parâmetros e um path sem fragmento ou barra invertida")
    if any(segment in {".", ".."} for segment in url.path.split("/")) or "\\" in url.path:
        raise ValueError("path decodificado contém segmentos de navegação inválidos")
    return url.raw_path.decode("ascii")


class MetabaseHttp:
    """Expression-first async adapter with native-SQL and saved-Card read paths."""

    def __init__(
        self,
        config: MetabaseConfig,
        *,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._client = client or httpx.AsyncClient(
            base_url=config.base_url.rstrip("/"),
            timeout=60.0,
        )
        self._owns_client = client is None
        self._token: str | None = None
        self._skip_cached_token = False
        self._card_ids: dict[tuple[int, str], int] = {}
        self.database_id: int | None = config.database_id

    # Quem fecha é o `close_runtime`, uma vez por invocação da CLI.
    async def aclose(self) -> None:
        """Close the adapter-owned HTTP client exactly when the runtime owns it."""
        if self._owns_client:
            await self._client.aclose()

    async def probe(self) -> IntegracaoStatus:
        if not self._config.email or self._config.password is None:
            return IntegracaoStatus(
                estado=Disponibilidade.INDISPONIVEL,
                detalhe="credenciais do Metabase não configuradas",
            )
        try:
            await self._ensure_token()
            await self._ensure_database()
        except (MetabaseError, httpx.HTTPError) as exc:
            return IntegracaoStatus(
                estado=Disponibilidade.INDISPONIVEL,
                detalhe=str(exc),
            )
        return IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)

    async def probe_api(self) -> IntegracaoStatus:
        """Check the session without requiring permission to list databases."""
        try:
            await self._ensure_token()
        except (MetabaseError, httpx.HTTPError) as exc:
            return IntegracaoStatus(estado=Disponibilidade.INDISPONIVEL, detalhe=str(exc))
        return IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)

    async def _request(
        self, method: str, path: str, *, retry_read: bool = False, **kwargs: Any
    ) -> httpx.Response:
        """Refresh a stale session; replay only GET or an explicitly observational query."""
        token = await self._ensure_token()
        headers = dict(kwargs.pop("headers", {}))
        headers["X-Metabase-Session"] = token
        response = await self._client.request(method, path, headers=headers, **kwargs)
        if response.status_code != 401:
            return response
        self._token = None
        self._skip_cached_token = True
        if self._config.email:
            delete_metabase_session(self._config.base_url, self._config.email)
        if method != "GET" and not retry_read:
            return response
        token = await self._ensure_token()
        headers["X-Metabase-Session"] = token
        return await self._client.request(method, path, headers=headers, **kwargs)

    async def _ensure_database(self) -> int:
        """The Caipora database id: configured, or discovered once by name in `/api/database`."""
        if self.database_id is not None:
            return self.database_id
        response = await self._request("GET", "/api/database")
        if response.is_error:
            message = (
                f"listagem de bancos do Metabase falhou ({response.status_code}): {response.text}"
            )
            raise MetabaseError(message)
        try:
            bancos = _Databases.model_validate(response.json()).data
        except (ValueError, ValidationError) as exc:
            message = "Metabase respondeu a listagem de bancos num formato inesperado"
            raise MetabaseResponseError(message) from exc
        for banco in bancos:
            if banco.name == self._config.database:
                self.database_id = banco.id
                return banco.id
        nomes = ", ".join(sorted(b.name for b in bancos))
        message = (
            f"banco {self._config.database!r} não encontrado no Metabase (há: {nomes}); "
            "configure PINK_METABASE_DATABASE_ID ou PINK_METABASE_DATABASE"
        )
        raise MetabaseError(message)

    async def rows(self, expression: ir.Table) -> list[dict[str, Any]]:
        """Compile one Ibis expression to MySQL and execute it through Metabase.

        Native SQL is the fast path. On an authenticated 403 the boundary may
        execute a pre-provisioned saved Card, but only when the compiled SQL
        matches one registered shape exactly (`pink.metabase_cards`); the
        domain never sees Card ids, hashes or template tags.

        Compilation stays outside the translation: an expression that does not
        compile is a programming error, not an observation that failed. What
        happens after -- transport, HTTP status, session, malformed dataset --
        is the Metabase boundary failing to observe, and reaches the domain as
        `RemoteObservationFailure` so a read that depends on it can say
        "inconclusive" instead of breaking. The boundary-level cause stays
        attached for diagnosis.
        """
        sql = ibis.to_sql(expression, dialect="mysql")
        try:
            response = await self._post_dataset(sql, limite=_limite_do_ir(expression))
        except MetabasePermissionError as native_error:
            if match_sql(sql) is None:
                raise ConsultaSemCard(
                    "esta shape Ibis ainda não possui contrato de Card"
                ) from native_error
            try:
                response = await self._post_matching_card(sql)
            except (MetabaseError, ValueError, httpx.HTTPError) as card_error:
                raise RemoteObservationFailure(
                    "conta Metabase autenticada sem Native SQL e a consulta não pôde "
                    f"usar uma Card provisionada equivalente: {card_error}"
                ) from native_error
        except (MetabaseError, httpx.HTTPError) as exc:
            raise RemoteObservationFailure(
                f"consulta ao Metabase não pôde ser observada: {exc}"
            ) from exc

        try:
            linhas, truncado_em = _decode_rows(response)
        except MetabaseError as exc:
            raise RemoteObservationFailure(
                f"consulta ao Metabase não pôde ser observada: {exc}"
            ) from exc
        if truncado_em is not None:
            raise ObservacaoTruncada(linhas=linhas, truncado_em=truncado_em)
        return linhas

    async def agent_request(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: JsonValue | MISSING = MISSING,
    ) -> tuple[int, JsonValue]:
        """Call the configured Metabase REST API with the user's permissions.

        Raw mutations are dispatched once. HTTP responses are returned unchanged;
        a lost mutation response carries explicit possible-effect information.
        """
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"}:
            raise ValueError("método HTTP não suportado")
        normalized = validate_api_path(path)
        try:
            await self._ensure_token()
        except (MetabaseError, httpx.HTTPError) as exc:
            raise RemoteObservationFailure(f"autenticação Metabase indisponível: {exc}") from exc
        content = (
            None
            if body is MISSING
            else json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
        )
        body_headers = {} if body is MISSING else {"content-type": "application/json"}
        try:
            response = await self._request(
                method,
                normalized,
                params=query or None,
                follow_redirects=False,
                content=content,
                headers=body_headers,
            )
        except MetabaseError as exc:
            raise RemoteObservationFailure(f"sessão Metabase indisponível: {exc}") from exc
        except httpx.HTTPError as exc:
            if method != "GET":
                raise RemoteWriteFailure(
                    f"resposta da operação Metabase perdida; reobserve antes de repetir: {exc}",
                    effect_may_have_occurred=not isinstance(
                        exc, (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout)
                    ),
                ) from exc
            raise RemoteObservationFailure(f"API Metabase não pôde ser observada: {exc}") from exc
        try:
            payload = response.json()
        except ValueError:
            payload = response.text
        return response.status_code, payload

    async def provision_cards(
        self, collection_id: int, *, dry_run: bool = False, queries: tuple[str, ...] | None = None
    ) -> list[CardProvisionamento]:
        """Idempotently provision every registered stable Card into one collection."""
        if collection_id <= 0:
            raise ValueError("collection_id deve ser positivo")
        names = tuple(CARD_SPECS) if queries is None else tuple(dict.fromkeys(queries))
        if not names or any(name not in CARD_SPECS for name in names):
            raise ValueError(f"selecione consultas registradas: {', '.join(CARD_SPECS)}")
        database_id = await self._ensure_database()
        results: list[CardProvisionamento] = []
        for name in names:
            spec = CARD_SPECS[name]
            digest = spec.digest()
            existing = await self._find_card_by_hash(
                digest, collection_id=collection_id, spec=spec, fresh=True
            )
            if existing is not None:
                results.append(
                    CardProvisionamento(query=spec.name, estado="existente", card_id=existing)
                )
                continue
            if dry_run:
                results.append(CardProvisionamento(query=spec.name, estado="dry_run"))
                continue
            sql, tags = spec.template()
            response = await self._request(
                "POST",
                "/api/card",
                json={
                    "name": provisioned_card_name(spec),
                    "collection_id": collection_id,
                    "dataset_query": {
                        "database": database_id,
                        "type": "native",
                        "native": {"query": sql, "template-tags": tags},
                    },
                    "display": "table",
                    "visualization_settings": {},
                },
            )
            if response.status_code == 403:
                raise MetabasePermissionError(
                    f"conta sem permissão para criar Cards na collection {collection_id}"
                )
            if response.is_error:
                raise MetabaseError(
                    f"criação da Card {spec.name} falhou ({response.status_code}): {response.text}"
                )
            try:
                card_id = int(response.json()["id"])
            except (KeyError, TypeError, ValueError) as exc:
                raise MetabaseResponseError(
                    f"criação da Card {spec.name} respondeu sem id válido"
                ) from exc
            await self._validate_card(card_id, collection_id, spec)
            self._card_ids[(collection_id, digest)] = card_id
            results.append(CardProvisionamento(query=spec.name, estado="criada", card_id=card_id))
        return results

    async def _find_card_by_hash(
        self, digest: str, *, collection_id: int, spec: CardSpec, fresh: bool = False
    ) -> int | None:
        key = (collection_id, digest)
        name = provisioned_card_name(spec)
        if not fresh and key in self._card_ids:
            card_id = self._card_ids.pop(key)
            await self._validate_card(card_id, collection_id, spec)
            self._card_ids[key] = card_id
            return card_id
        response = await self._request("GET", "/api/search", params={"q": digest, "models": "card"})
        if response.status_code == 403:
            raise MetabasePermissionError("conta sem acesso à busca de Cards do Metabase")
        if response.is_error:
            raise MetabaseError(f"busca de Card falhou ({response.status_code}): {response.text}")
        try:
            payload = response.json()
        except ValueError as exc:
            raise MetabaseResponseError("busca de Card respondeu JSON inválido") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
            raise MetabaseResponseError("busca de Cards respondeu sem lista data")
        data = payload["data"]
        total = payload.get("total")
        if type(total) is not int or total < len(data):
            raise MetabaseResponseError("busca de Cards respondeu total inválido")
        if total > len(data):
            raise MetabaseResponseError(
                "busca de Cards incompleta; não é possível afirmar ausência"
            )
        matches = [
            item
            for item in data
            if isinstance(item, dict)
            and item.get("model") == "card"
            and isinstance(item.get("id"), int)
            and (
                item.get("collection_id") == collection_id
                or (
                    isinstance(item.get("collection"), dict)
                    and item["collection"].get("id") == collection_id
                )
            )
            and item.get("name") == name
            and not item.get("archived", False)
        ]
        if len(matches) > 1:
            matches.sort(key=lambda it: it.get("id", 0), reverse=True)
        card_id = int(matches[0]["id"]) if matches else None
        if card_id is not None:
            await self._validate_card(card_id, collection_id, spec)
            self._card_ids[key] = card_id
        return card_id

    async def _validate_card(self, card_id: int, collection_id: int, spec: CardSpec) -> None:
        """Reobserve mutable server content, even when the Card ID is cached."""
        response = await self._request("GET", f"/api/card/{card_id}")
        if response.is_error:
            raise MetabaseResponseError(
                f"definição da Card {card_id} indisponível ({response.status_code})"
            )
        try:
            card = response.json()
        except ValueError as exc:
            raise MetabaseResponseError(f"definição da Card {card_id} não é JSON") from exc
        sql, tags = spec.template()
        database_id = await self._ensure_database()
        expected_query = {
            "database": database_id,
            "type": "native",
            "native": {"query": sql, "template-tags": tags},
        }

        dq = card.get("dataset_query") if isinstance(card, dict) else None
        query_valida = dq == expected_query
        if not query_valida and isinstance(dq, dict):
            stages = dq.get("stages")
            if isinstance(stages, list) and len(stages) == 1 and dq.get("database") == database_id:
                st = stages[0]
                stage_tags = st.get("template-tags")
                tags_dict = (
                    {t["name"]: t for t in stage_tags if isinstance(t, dict) and "name" in t}
                    if isinstance(stage_tags, list)
                    else (stage_tags if isinstance(stage_tags, dict) else {})
                )
                if st.get("native") == sql and tags_dict == tags:
                    query_valida = True

        observed_collection_id = (
            card.get("collection_id")
            if isinstance(card, dict) and card.get("collection_id") is not None
            else (
                card.get("collection", {}).get("id")
                if isinstance(card, dict) and isinstance(card.get("collection"), dict)
                else None
            )
        )

        if (
            not isinstance(card, dict)
            or card.get("id") != card_id
            or observed_collection_id != collection_id
            or card.get("name") != provisioned_card_name(spec)
            or card.get("archived") is not False
            or not query_valida
        ):
            raise MetabaseResponseError(
                f"Card {card_id} diverge do contrato registrado; confira banco, SQL, parâmetros e coleção"
            )

    async def _post_matching_card(self, sql: str) -> httpx.Response:
        invocation = match_sql(sql)
        if invocation is None:
            raise MetabasePermissionError("esta shape Ibis ainda não possui contrato de Card")
        collection_id = self._config.collection_id
        if collection_id is None:
            raise MetabasePermissionError(
                "configure metabase_collection_id para o fallback de Cards"
            )
        card_id = await self._find_card_by_hash(
            invocation.digest,
            collection_id=collection_id,
            spec=CARD_SPECS[invocation.name],
        )
        if card_id is None:
            raise MetabasePermissionError(
                f"Card {invocation.name} ({invocation.digest}) não está provisionada"
            )
        response = await self._request(
            "POST",
            f"/api/card/{card_id}/query",
            retry_read=True,
            json={
                "parameters": [
                    _card_parameter(name, value) for name, value in invocation.params.items()
                ]
            },
        )
        if response.status_code == 403:
            raise MetabasePermissionError(
                f"conta não pode executar a Card {invocation.name} ({card_id})"
            )
        if response.is_error:
            raise MetabaseError(
                f"execução da Card {invocation.name} falhou ({response.status_code}): {response.text}"
            )
        return response

    async def _ensure_token(self) -> str:
        if self._token is not None:
            return self._token
        if not self._config.email or self._config.password is None:
            message = "credenciais do Metabase não configuradas"
            raise MetabaseAuthenticationError(message)

        if not self._skip_cached_token:
            cached_token = get_metabase_session(self._config.base_url, self._config.email)
            if cached_token:
                self._token = cached_token
                return cached_token

        response = await self._client.post(
            "/api/session",
            json={
                "username": self._config.email,
                "password": self._config.password.get_secret_value(),
            },
        )
        if response.status_code in {401, 403}:
            message = "credenciais do Metabase rejeitadas"
            raise MetabaseAuthenticationError(message)
        if response.is_error:
            message = f"login Metabase falhou ({response.status_code}): {response.text}"
            raise MetabaseError(message)
        try:
            session = _SessionResponse.model_validate(response.json())
        except (ValueError, ValidationError) as exc:
            message = "Metabase respondeu login sem token de sessão válido"
            raise MetabaseResponseError(message) from exc
        self._token = session.id
        self._skip_cached_token = False
        save_metabase_session(self._config.base_url, self._config.email, session.id)
        return session.id

    async def _post_dataset(self, sql: str, *, limite: int | None) -> httpx.Response:
        body: dict[str, Any] = {
            "database": await self._ensure_database(),
            "type": "native",
            "native": {"query": sql},
            "parameters": [],
        }
        if limite is not None:
            body["constraints"] = {
                "max-results": limite + 1,
                "max-results-bare-rows": limite + 1,
            }
        response = await self._request("POST", "/api/dataset", retry_read=True, json=body)
        if response.status_code == 401:
            message = "sessão Metabase rejeitada após uma reautenticação"
            raise MetabaseAuthenticationError(message)
        if response.status_code == 403:
            message = "conta Metabase autenticada sem permissão para executar Native SQL"
            raise MetabasePermissionError(message)
        if response.is_error:
            message = f"consulta Metabase falhou ({response.status_code}): {response.text}"
            raise MetabaseError(message)
        return response


def _limite_do_ir(expression: ir.Table) -> int | None:
    """The bound a collection already carries: the `Limit` node at the root of the IR."""
    raiz = expression.op()
    if isinstance(raiz, ops.Limit) and isinstance(raiz.n, int):
        return raiz.n
    return None


def _decode_rows(response: httpx.Response) -> tuple[list[dict[str, Any]], int | None]:
    """Validate Metabase's column/row matrix; return rows and the truncation mark, if any."""
    try:
        payload = _DatasetResponse.model_validate(response.json())
    except (ValueError, ValidationError) as exc:
        message = "resposta de dataset do Metabase não tem data.cols/data.rows válidos"
        raise MetabaseResponseError(message) from exc

    names = [column.name for column in payload.data.cols]
    decoded: list[dict[str, Any]] = []
    for row in payload.data.rows:
        if len(row) != len(names):
            message = "resposta de dataset do Metabase tem linha com número incorreto de colunas"
            raise MetabaseResponseError(message)
        decoded.append(dict(zip(names, row, strict=True)))
    return decoded, payload.data.rows_truncated
