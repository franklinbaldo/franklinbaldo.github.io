"""Opt-in escape hatches that deliberately stay outside the normal Pink catalog."""

from __future__ import annotations

from typing import Annotated, Literal, cast

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import GoogleDocId, Limite, RevisionId, SetorSigla
from pink.google_docs import GoogleBatchResult, RawGoogleDocs
from pink.integrations import Metabase
from pink.models import (
    Fonte,
    Indisponivel,
    JsonObject,
    PinkModel,
    ResultadoColecao,
)
from pink.queries_reference import funcionalidades_listar
from pink.write_safety import RemoteObservationFailure
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)
DESTRUCTIVE = Efeito(
    leitura=False,
    destrutivo=True,
    idempotente=False,
    mundo_aberto=True,
)
RawRequests = Annotated[
    list[JsonObject],
    Field(min_length=1, description="Requests Google Docs batchUpdate no formato REST nativo"),
]


def build_raw_google_catalogo(runtime: Runtime) -> Catalogo:
    """Build raw Google tools; the parent app controls their visibility."""
    catalogo = Catalogo()

    def get_google() -> RawGoogleDocs:
        return cast(RawGoogleDocs, runtime.google)

    @catalogo.operacao(
        nome="google_document_get",
        tags={"raw", "google", "read"},
        efeito=READ,
    )
    async def google_document_get(
        google_doc_id: GoogleDocId,
    ) -> JsonObject:
        """Lê o JSON nativo de um Google Doc para investigação de casos não cobertos."""
        google = get_google()
        return await google.document_json(google_doc_id)

    @catalogo.operacao(
        nome="google_batch_update",
        tags={"raw", "google", "write", "destructive"},
        efeito=DESTRUCTIVE,
    )
    async def google_batch_update(
        google_doc_id: GoogleDocId,
        requests: RawRequests,
        revisao_base: RevisionId,
    ) -> GoogleBatchResult:
        """Executa batchUpdate bruto preservando optimistic concurrency obrigatória."""
        google = get_google()
        return await google.batch_update(
            google_doc_id,
            requests=requests,
            required_revision_id=revisao_base,
        )

    return catalogo


class FuncionalidadeFiltro(PinkModel):
    """Filtros da visão raw do modelo de permissão HTTP do Kanoê."""

    setor: SetorSigla = Field(description="Setor da lotação em que a permissão é avaliada")
    termo: str | None = Field(default=None, description="Substring da URL, sigla ou descrição")
    metodo: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] | None = Field(
        default=None, description="Método HTTP da rota raw"
    )
    somente_permitidas: bool = Field(
        default=True,
        description="Quando true mostra apenas rotas concedidas pelo perfil da lotação",
    )
    usuario_id: int | None = Field(
        default=None,
        description="Usuário avaliado; omitido, usa a identidade Kanoê em vigor",
    )


class FuncionalidadeResumo(PinkModel):
    """Uma linha raw do catálogo de método/URL usado pelo verificador de permissões Kanoê."""

    metodo: str
    url: str
    sigla: str
    descricao: str | None = None
    permitida: bool


class FuncionalidadeListagem(ResultadoColecao[FuncionalidadeResumo]):
    """Seleção raw de rotas Kanoê e o veredito do modelo institucional de permissão."""


def build_raw_kanoe_catalogo(runtime: Runtime) -> Catalogo:
    """Build opt-in Kanoê transport exploration, outside the normal domain catalog."""
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    async def usuario_em_vigor(explicito: int | None) -> int | None:
        if explicito is not None:
            return explicito
        identidade = getattr(runtime.kanoe, "identidade", None)
        if callable(identidade):
            user_id, _ = await identidade()
            return int(user_id)
        return runtime.contexto.kanoe_user_id

    @catalogo.operacao(
        nome="funcionalidade_listar",
        tags={"raw", "kanoe", "permissao", "read", "parquet"},
        efeito=READ,
    )
    async def funcionalidade_listar(
        limite: Limite,
        filtro: Annotated[
            FuncionalidadeFiltro,
            Field(description="Filtros explícitos do catálogo HTTP raw do Kanoê"),
        ],
    ) -> FuncionalidadeListagem:
        """Inspeciona método/URL do Kanoê para diagnóstico, fora do catálogo normal."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        try:
            usuario_id = await usuario_em_vigor(filtro.usuario_id)
        except RemoteObservationFailure as exc:
            return FuncionalidadeListagem(dados=Indisponivel(fonte=Fonte.KANOE, motivo=str(exc)))
        if usuario_id is None:
            return FuncionalidadeListagem(
                dados=Indisponivel(
                    fonte=Fonte.KANOE,
                    motivo="identidade Kanoê não configurada nem descoberta; informe filtro.usuario_id",
                )
            )
        expression = funcionalidades_listar(
            usuario_id=usuario_id,
            setor=filtro.setor,
            termo=filtro.termo,
            metodo=filtro.metodo,
            somente_permitidas=filtro.somente_permitidas,
        )
        result = await materializar_colecao(
            metabase, artifacts, expression, FuncionalidadeResumo, limite=limite
        )
        return FuncionalidadeListagem(dados=result.dados)

    return catalogo
