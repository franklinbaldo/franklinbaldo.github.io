"""Public Pydantic contracts for Pink 0.8."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime
from enum import IntEnum, StrEnum
from types import MappingProxyType
from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, model_validator
from rich import box
from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from pink.domain_types import DatasetArtifactUri, FileArtifactUri

AMOSTRA_INLINE_MAX = 100


# Cores dos estados de conhecimento (observação e efeito), para o terminal.
_COR_DO_ESTADO = {
    "observado": "green",
    "disponivel": "green",
    "confirmada": "green",
    "parcial": "yellow",
    "submetida": "yellow",
    "ambigua": "yellow",
    "ausente": "magenta",
    "indisponivel": "red",
    "desconhecido": "red",
    "recusada": "red",
}


def _celula(valor: Any) -> str:
    if valor is None:
        return "—"
    if isinstance(valor, bool):
        return "sim" if valor else "não"
    if isinstance(valor, (StrEnum, IntEnum)):
        return str(valor.value)
    if isinstance(valor, BaseModel):
        return valor.model_dump_json()
    if isinstance(valor, (list, tuple, dict)):
        return TypeAdapter(type(valor)).dump_json(valor).decode()
    return str(valor)


def _tabela_de_itens(itens: Sequence[Any]) -> Table:
    """Uma linha por item, uma coluna por campo; nenhum valor é cortado.

    Medido ao vivo: com reticências, o CNJ saía como `7001730-62.2024.…` e uma
    tabela de dez campos perdia colunas -- para um agente isso é dado perdido.
    Um valor que não cabe dobra a linha; texto longo cede largura antes das
    identidades.
    """
    colunas = list(type(itens[0]).model_fields)
    tabela = Table(box=box.SIMPLE_HEAD, pad_edge=False, header_style="bold cyan")
    for nome in colunas:
        longo = nome in {"titulo", "nome", "descricao", "observacao", "teor", "detalhe"}
        tabela.add_column(
            nome,
            overflow="fold",
            max_width=40 if longo else None,
            min_width=min(len(nome), 12),
        )
    for item in itens:
        tabela.add_row(*(_celula(getattr(item, nome)) for nome in colunas))
    return tabela


def _tabela_de_campos(modelo: BaseModel, campos: Iterable[str]) -> Table:
    tabela = Table(box=None, pad_edge=False, show_header=False)
    tabela.add_column("campo", style="cyan", no_wrap=True)
    tabela.add_column("valor", overflow="fold")
    for nome in campos:
        tabela.add_row(nome, _celula(getattr(modelo, nome)))
    return tabela


def _secao(nome: str, conteudo: RenderableType) -> Panel:
    """Um campo composto (um modelo aninhado, uma lista) é um painel com o nome do campo."""
    return Panel(conteudo, title=nome, title_align="left", border_style="dim", box=box.ROUNDED)


def _painel_do_estado(modelo: BaseModel, conteudo: RenderableType, *detalhes: str | None) -> Panel:
    """O estado de conhecimento emoldura o valor: o título é o estado, a cor é a dele."""
    estado = str(getattr(modelo, "estado"))
    cor = _COR_DO_ESTADO.get(estado, "white")
    titulo = Text(estado, style=f"bold {cor}")
    for detalhe in detalhes:
        if detalhe:
            titulo.append("  ")
            titulo.append(detalhe, style="dim")
    return Panel(conteudo, title=titulo, title_align="left", border_style=cor, box=box.ROUNDED)


def _cabecalho_do_estado(modelo: BaseModel, *detalhes: str | None) -> Text:
    estado = str(getattr(modelo, "estado"))
    texto = Text(estado, style=f"bold {_COR_DO_ESTADO.get(estado, 'white')}")
    for detalhe in detalhes:
        if detalhe:
            texto.append("  ")
            texto.append(detalhe, style="dim")
    return texto


class PinkModel(BaseModel):
    """Strict immutable base for public Pink 0.8 contracts."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    def __rich__(self) -> RenderableType:
        """How this contract shows itself in a terminal -- by type, never by tool.

        Scalar fields become a key/value table; a nested model renders itself; a
        list of models becomes one table. Subclasses whose meaning is a state
        (`Observado`, `Confirmada`...) or a selection (`Colecao`) override this.
        """
        campos = type(self).model_fields
        escalares = [
            n for n in campos if not isinstance(getattr(self, n), (BaseModel, list, tuple))
        ]
        compostos = [n for n in campos if n not in escalares]
        if compostos == ["dados"] and not escalares:
            return getattr(self, "dados")  # o envelope não acrescenta nada ao terminal
        partes: list[RenderableType] = []
        if escalares:
            partes.append(_tabela_de_campos(self, escalares))
        for nome in compostos:
            valor = getattr(self, nome)
            if isinstance(valor, BaseModel):
                partes.append(_secao(nome, valor))
            elif valor and all(isinstance(item, BaseModel) for item in valor):
                partes.append(_secao(nome, _tabela_de_itens(valor)))
            else:
                partes.append(
                    _secao(
                        nome,
                        Text(_celula(valor) if valor else "(vazio)", style="" if valor else "dim"),
                    )
                )
        return Group(*partes)


class Fonte(StrEnum):
    """Material source of one observation."""

    METABASE = "metabase"
    KANOE = "kanoe"
    GOOGLE = "google"
    CACHE = "cache"


class Completude(StrEnum):
    """How completely a source observed the requested fact."""

    COMPLETA = "completa"
    PARCIAL = "parcial"


class Proveniencia(PinkModel):
    """Material provenance that can change how an agent interprets data."""

    fonte: Fonte = Field(description="Fonte material usada para observar o dado")
    observado_em: datetime = Field(description="Instante em que a fonte foi observada")
    completude: Completude = Field(
        default=Completude.COMPLETA,
        description="Completude da observação produzida pela fonte",
    )


class Observado[T](PinkModel):
    """A value that was actually observed, including legitimate empty values."""

    estado: Literal["observado"] = Field(
        default="observado",
        description="A fonte foi observada com sucesso e produziu um valor confiável",
    )
    valor: T = Field(description="Valor efetivamente observado na fonte")
    proveniencia: Proveniencia | None = Field(
        default=None,
        description="Proveniência material da observação quando conhecida",
    )

    def __rich__(self) -> RenderableType:
        return _painel_do_estado(self, _renderavel(self.valor))


class Parcial[T](PinkModel):
    """A value observed only partially; missing data must stay explicit."""

    estado: Literal["parcial"] = Field(
        default="parcial",
        description="A fonte produziu somente parte material do valor solicitado",
    )
    valor: T = Field(description="Parte do valor que foi possível observar")
    ausente: tuple[str, ...] = Field(
        min_length=1,
        description="Campos ou parcelas materiais que a fonte não conseguiu observar",
    )
    proveniencia: Proveniencia | None = Field(
        default=None,
        description="Proveniência material da observação parcial quando conhecida",
    )

    def __rich__(self) -> RenderableType:
        faltas = [Text(f"ausente: {falta}", style="yellow") for falta in self.ausente]
        return _painel_do_estado(self, Group(*faltas, _renderavel(self.valor)))


class Ausente(PinkModel):
    """The source was observed successfully and proved the requested entity absent."""

    estado: Literal["ausente"] = Field(
        default="ausente",
        description="A fonte foi observada com sucesso e comprovou a ausência solicitada",
    )
    fonte: Fonte = Field(description="Fonte em que a ausência foi efetivamente observada")
    motivo: str | None = Field(
        default=None,
        description="Contexto material sobre a ausência quando útil",
    )

    def __rich__(self) -> RenderableType:
        return _cabecalho_do_estado(self, f"fonte: {self.fonte.value}", self.motivo)


class Indisponivel(PinkModel):
    """The requested fact could not be observed from the intended source."""

    estado: Literal["indisponivel"] = Field(
        default="indisponivel",
        description="A fonte pretendida não pôde ser observada nesta chamada",
    )
    fonte: Fonte = Field(description="Fonte que não estava disponível para a observação")
    motivo: str = Field(min_length=1, description="Motivo material da indisponibilidade")

    def __rich__(self) -> RenderableType:
        return _cabecalho_do_estado(self, f"fonte: {self.fonte.value}", self.motivo)


class Desconhecido(PinkModel):
    """Pink has no trustworthy observation for the requested fact."""

    estado: Literal["desconhecido"] = Field(
        default="desconhecido",
        description="Não existe observação confiável suficiente para afirmar o valor",
    )
    motivo: str = Field(min_length=1, description="Por que o fato permanece desconhecido")

    def __rich__(self) -> RenderableType:
        return _cabecalho_do_estado(self, self.motivo)


type Observacao[T] = Annotated[
    Observado[T] | Parcial[T] | Ausente | Indisponivel | Desconhecido,
    Field(discriminator="estado"),
]


def _renderavel(valor: Any) -> RenderableType:
    """The observed value: a model renders itself; anything else is text."""
    if isinstance(valor, BaseModel):
        return valor
    if isinstance(valor, (list, tuple)) and valor and all(isinstance(i, BaseModel) for i in valor):
        return _tabela_de_itens(valor)
    return Text(_celula(valor))


class DatasetArtifact(PinkModel):
    """The rows actually observed for one limited selection, as a read-only Parquet resource."""

    uri: DatasetArtifactUri
    formato: Literal["parquet"] = Field(
        default="parquet",
        description="Formato tabular canônico das linhas efetivamente observadas desta seleção",
    )
    mime_type: Literal["application/vnd.apache.parquet"] = Field(
        default="application/vnd.apache.parquet",
        description="MIME type do recurso Parquet desta seleção",
    )
    linhas: int = Field(
        ge=0,
        description="Número exato de linhas materializadas -- as efetivamente observadas, que numa seleção parcial são menos do que o limite pedido",
    )
    colunas: tuple[str, ...] = Field(description="Colunas preservadas no artifact")
    tamanho_bytes: int = Field(ge=0, description="Tamanho do Parquet materializado")
    modelo: str = Field(
        description="Modelo Pydantic usado para validar cada linha antes da publicação"
    )


class FileArtifact(PinkModel):
    """Immutable binary artifact already owned by the Pink runtime."""

    uri: FileArtifactUri
    nome: str = Field(
        min_length=1, description="Nome do arquivo a apresentar a integrações externas"
    )
    mime_type: str = Field(min_length=1, description="MIME type declarado do conteúdo")
    tamanho_bytes: int = Field(ge=0, description="Tamanho exato do conteúdo")
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$", description="SHA-256 do conteúdo imutável")


class Colecao[T](PinkModel):
    """Agent-facing view: complete inline through 100 rows, then an explicit preview plus Parquet."""

    total: int = Field(
        ge=0,
        description=(
            "Quantidade exata de itens nesta seleção limitada. "
            "Não é o total global de matches: listar nunca conta o universo"
        ),
    )
    amostra: list[T] = Field(
        max_length=AMOSTRA_INLINE_MAX,
        description=(
            "Linhas inline desta seleção: íntegras até 100 itens; acima disso, "
            "as primeiras 100 ficam inline e o conjunto integral permanece no recurso Parquet"
        ),
    )
    dataset: DatasetArtifact = Field(
        description="Artifact Parquet com as linhas efetivamente observadas desta seleção, validadas antes da publicação; numa `Parcial`, contém só o que a fonte entregou"
    )
    amostra_completa: bool = Field(
        default=True,
        title="amostra_integral",
        description="Verdadeiro quando todas as linhas materializadas desta seleção estão presentes inline",
    )

    @model_validator(mode="before")
    @classmethod
    def _calcular_amostra_completa(cls, data: Any) -> Any:
        if isinstance(data, dict):
            data = dict(data)
            amostra = data.get("amostra")
            total = data.get("total")
            if isinstance(amostra, (list, tuple)) and isinstance(total, int):
                data["amostra_completa"] = len(amostra) == total
        return data

    @model_validator(mode="after")
    def validate_materialization_counts(self) -> Self:
        """Keep summary counts consistent with the one Parquet materialization they describe."""
        if self.dataset.linhas != self.total:
            raise ValueError(
                f"dataset.linhas ({self.dataset.linhas}) deve ser igual a total ({self.total})"
            )
        if len(self.amostra) > self.total:
            raise ValueError(
                f"amostra ({len(self.amostra)}) não pode conter mais itens que total ({self.total})"
            )
        return self

    def __rich__(self) -> RenderableType:
        legenda = Text()
        legenda.append(f"total={self.total}", style="bold")
        legenda.append(
            f"  ·  {self.dataset.uri}  ({self.dataset.linhas} linhas, {self.dataset.tamanho_bytes} bytes)",
            style="dim",
        )
        if not self.amostra:
            return Group(legenda, Text("(seleção vazia)", style="dim"))
        tabela = _tabela_de_itens(self.amostra)
        if self.amostra_completa:
            return Group(legenda, tabela)
        rodape = Text(
            f"mostrando {len(self.amostra)} de {self.total} — o restante em {self.dataset.uri}",
            style="yellow",
        )
        return Group(legenda, tabela, rodape)


class ResultadoColecao[T](PinkModel):
    """Stable object-root envelope for a collection observation."""

    dados: Observacao[Colecao[T]] = Field(
        description="Seleção limitada observada, parcial (a fonte entregou menos do que o limite), ausente, indisponível ou desconhecida"
    )


OperationHandle = Annotated[
    str,
    Field(
        min_length=1,
        pattern=r"^[a-z][a-z0-9+.-]*:",
        description=(
            "URI de recurso que pode ser lido para reobservar uma operação remota; "
            "não é instrução de retry"
        ),
        examples=["kanoe://tarefa/123/documentos"],
    ),
]


class Confirmada(PinkModel):
    """The desired state is known to hold, whether or not a write was dispatched.

    A declarative write that finds the target state already true does not need a
    fifth epistemic state. What the consumer knows is the same thing it knows
    after a confirmed mutation -- the desired state holds -- and so is the next
    safe action. Whether a dispatch was necessary is provenance, and it belongs
    in ``detalhe``.
    """

    estado: Literal["confirmada"] = Field(
        default="confirmada",
        description="O estado desejado é conhecido como verdadeiro, tenha havido mutação ou não",
    )
    operacao: str = Field(min_length=1, description="Operação de domínio executada")
    recurso_id: int | str | None = Field(
        default=None,
        description="Identidade remota do recurso afetado quando aplicável",
    )
    detalhe: str | None = Field(
        default=None,
        description=(
            "Detalhe material da confirmação, incluindo o caso em que o estado desejado "
            "já estava observado e nenhuma mutação foi despachada"
        ),
    )

    def __rich__(self) -> RenderableType:
        recurso = f"recurso {self.recurso_id}" if self.recurso_id is not None else None
        return _cabecalho_do_estado(self, self.operacao, recurso, self.detalhe)


class Submetida(PinkModel):
    """A write accepted for processing but whose final postcondition is pending."""

    estado: Literal["submetida"] = Field(
        default="submetida",
        description="A mutação foi aceita para processamento, mas a postcondition final ainda não foi observada",
    )
    operacao: str = Field(min_length=1, description="Operação de domínio submetida")
    handle: OperationHandle
    detalhe: str | None = Field(default=None, description="Detalhe material do processamento")

    def __rich__(self) -> RenderableType:
        return _cabecalho_do_estado(self, self.operacao, f"reobservar: {self.handle}", self.detalhe)


class Ambigua(PinkModel):
    """A remote write failed in a way that does not prove whether it took effect."""

    estado: Literal["ambigua"] = Field(
        default="ambigua",
        description="O efeito remoto não pôde ser determinado com segurança; retry cego é inseguro",
    )
    operacao: str = Field(min_length=1, description="Operação cujo efeito remoto é incerto")
    handle: OperationHandle | None = Field(
        default=None,
        description=(
            "Recurso (`pink recurso <uri>`) para reconciliar o efeito antes de decidir qualquer retry, quando a identity necessária é conhecida"
        ),
    )
    efeito_pode_ter_ocorrido: Literal[True] = Field(
        default=True,
        description="Confirma que a mutação pode já ter produzido efeito remoto e não deve ser repetida cegamente",
    )
    detalhe: str = Field(
        min_length=1,
        description="Evidência disponível sobre a ambiguidade; retry cego é inseguro",
    )

    def __rich__(self) -> RenderableType:
        handle = f"reobservar: {self.handle}" if self.handle else "sem handle: não repita às cegas"
        return _cabecalho_do_estado(self, self.operacao, handle, self.detalhe)


class Recusada(PinkModel):
    """A write that definitely did not occur because a domain precondition refused it."""

    estado: Literal["recusada"] = Field(
        default="recusada",
        description="Uma precondition conhecida impediu a mutação antes de qualquer efeito remoto possível",
    )
    operacao: str = Field(min_length=1, description="Operação recusada")
    motivo: str = Field(min_length=1, description="Precondição de domínio que recusou a escrita")

    def __rich__(self) -> RenderableType:
        return _cabecalho_do_estado(self, self.operacao, self.motivo)


type EfeitoEscrita = Annotated[
    Confirmada | Submetida | Ambigua | Recusada,
    Field(discriminator="estado", title="EfeitoEscrita"),
]


class EfeitosEmLote(PinkModel):
    """One effect per item of a batch write, in the order the items were given."""

    efeitos: list[EfeitoEscrita] = Field(
        description="Um efeito por pasta do lote, na ordem dos itens; o lote não é atômico na fonte, então cada um tem o seu estado"
    )

    def __rich__(self) -> RenderableType:
        return Group(*(_renderavel(efeito) for efeito in self.efeitos))


class EspecieTarefa(IntEnum):
    """Espécies de tarefa que o Kanoê mantém ativas hoje.

    `ratio.especies_tarefas` é tabela viva, mas o conjunto ativo é vocabulário
    institucional: mudança material aqui muda o que o setor consegue fazer, não
    é configuração de rotina. Pink modela as sete que existem para poder ensinar
    os nomes ao agente e para perceber quando o vocabulário mudar -- em vez de
    aceitar de olhos fechados o que o banco devolver.

    Os ids são o identificador estrutural: é `especies_tarefas_id` que a tarefa
    carrega e `especieTarefa.id` que a criação envia.

    Isto vale só para o catálogo ativo. Tarefa histórica aponta para espécie já
    desativada -- são 169 delas, em 240.510 tarefas --, então leitura de tarefa
    continua com o id solto, sem vocabulário fechado.
    """

    PETICIONAR = 183
    EFETUAR_CALCULO = 379
    AGRAVO_DE_INSTRUMENTO = 391
    JUSTIFICATIVA = 435
    SIMPLES = 503
    PROTOCOLAR_NO_SEI = 504
    AGENDAMENTO_DE_AUDIENCIA_SESSAO_OU_REUNIAO = 505


class EspecieTarefaConhecida(PinkModel):
    """O que Pink sabe de uma espécie ativa além do id."""

    especie_id: EspecieTarefa = Field(description="Id estrutural da espécie no Kanoê")
    nome: str = Field(description="Nome cadastrado da espécie")
    genero: str = Field(description="Gênero de tarefa a que a espécie pertence")


# Observado em `ratio.especies_tarefas` (ativo=1) e `ratio.generos_tarefas`.
# `descricao` não entra: nas sete ativas ela repete `nome` literalmente, e
# guardar a repetição fingiria uma informação que o cadastro não tem.
ESPECIES_TAREFA_CONHECIDAS: Mapping[EspecieTarefa, EspecieTarefaConhecida] = MappingProxyType(
    {
        item.especie_id: item
        for item in (
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.PETICIONAR, nome="Peticionar", genero="JUDICIAL"
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.EFETUAR_CALCULO,
                nome="Efetuar Cálculo",
                genero="ADMINISTRATIVO",
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.AGRAVO_DE_INSTRUMENTO,
                nome="Agravo de Instrumento",
                genero="JUDICIAL",
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.JUSTIFICATIVA, nome="Justificativa", genero="JUDICIAL"
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.SIMPLES, nome="Simples", genero="JUDICIAL"
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.PROTOCOLAR_NO_SEI,
                nome="Protocolar no SEI",
                genero="JUDICIAL",
            ),
            EspecieTarefaConhecida(
                especie_id=EspecieTarefa.AGENDAMENTO_DE_AUDIENCIA_SESSAO_OU_REUNIAO,
                nome="Agendamento de Audiência, Sessão ou Reunião",
                genero="ADMINISTRATIVO",
            ),
        )
    }
)

_FONTE_ESPECIES = "ratio.especies_tarefas"


class EspecieTarefaNaoPrevista(RuntimeError):
    """O Kanoê ativou uma espécie que o vocabulário do Pink não prevê.

    Não é erro de leitura: a observação chegou inteira. É o modelo do Pink que
    ficou velho, e engolir a espécie nova -- ou traduzi-la para "outros" --
    esconderia do agente uma mudança que pode alterar o que o setor consegue
    fazer.
    """

    def __init__(
        self,
        *,
        especie_id: object,
        nome: object = None,
        descricao: object = None,
        genero_id: object = None,
        ativo: object = None,
    ) -> None:
        observado = ", ".join(
            f"{campo}={valor!r}"
            for campo, valor in (
                ("id", especie_id),
                ("nome", nome),
                ("descricao", descricao),
                ("generos_tarefas_id", genero_id),
                ("ativo", ativo),
            )
            if valor is not None
        )
        super().__init__(
            f"Espécie de tarefa não prevista pelo Pink: {observado}. "
            f"O vocabulário institucional mudou. Consulte {_FONTE_ESPECIES} para ver as "
            f"espécies ativas hoje e atualizar `EspecieTarefa` no Pink. "
            f"Previstas: {descrever_especies_previstas()}."
        )
        self.especie_id = especie_id


class EspecieTarefaDesaparecida(RuntimeError):
    """Uma espécie que o Pink modela como ativa sumiu do catálogo do Kanoê.

    O drift inverso: o modelo continua afirmando que a espécie existe, e
    qualquer coisa que dependa dela passa a estar errada em silêncio.
    """

    def __init__(self, ausentes: Iterable[EspecieTarefa]) -> None:
        # Um só percurso: `ausentes` pode ser generator, e a mensagem e o
        # atributo têm de sair do mesmo conjunto.
        faltantes = tuple(sorted(ausentes))
        faltando = ", ".join(
            f"id={especie.value} nome={ESPECIES_TAREFA_CONHECIDAS[especie].nome!r}"
            for especie in faltantes
        )
        super().__init__(
            f"Espécie(s) de tarefa que o Pink prevê e o Kanoê não ativa mais: {faltando}. "
            f"O vocabulário institucional mudou. Consulte {_FONTE_ESPECIES} para ver as "
            f"espécies ativas hoje e atualizar `EspecieTarefa` no Pink."
        )
        self.ausentes = faltantes


def descrever_especies_previstas() -> str:
    """Rotula o vocabulário previsto para o agente ler no schema e no erro."""
    return ", ".join(
        f"{item.especie_id.value}={item.nome!r}" for item in ESPECIES_TAREFA_CONHECIDAS.values()
    )


def especie_tarefa_prevista(bruto: Mapping[str, Any]) -> EspecieTarefa:
    """Resolve uma linha observada do catálogo, ou acusa o drift com detalhe."""
    try:
        return EspecieTarefa(bruto.get("especie_id"))
    except ValueError as exc:
        raise EspecieTarefaNaoPrevista(
            especie_id=bruto.get("especie_id"),
            nome=bruto.get("nome"),
            descricao=bruto.get("descricao"),
            genero_id=bruto.get("generos_tarefas_id"),
            ativo=bruto.get("ativo"),
        ) from exc


def reconciliar_catalogo_de_especies(observadas: Iterable[EspecieTarefa]) -> None:
    """Acusa a espécie prevista que sumiu do catálogo ativo observado."""
    ausentes = set(ESPECIES_TAREFA_CONHECIDAS) - set(observadas)
    if ausentes:
        raise EspecieTarefaDesaparecida(ausentes)


class StatusTramitacao(StrEnum):
    """Estado de uma tramitação no Kanoê.

    São os quatro códigos que o Kanoê grava e devolve. Ficavam como strings
    soltas na boundary, o que escondia duas coisas do agente: que o vocabulário
    é fechado, e o que cada código significa. `PENDENTE` é o único que sustenta
    uma reobservação positiva -- os outros três dizem que a tramitação saiu da
    fila, cada um por um motivo diferente.
    """

    PENDENTE = "PE"
    RECEBIDO = "RE"
    CIENTE = "CI"
    RECUSADO = "RC"


class Disponibilidade(StrEnum):
    """Observed availability of one runtime integration."""

    DISPONIVEL = "disponivel"
    INDISPONIVEL = "indisponivel"


class IntegracaoStatus(PinkModel):
    """Material status of one external integration."""

    estado: Disponibilidade = Field(description="Disponibilidade observada da integração")
    detalhe: str | None = Field(
        default=None,
        description="Explicação material quando a integração não está disponível",
    )


class RuntimeContext(PinkModel):
    """Effective non-secret runtime identity relevant to an agent or operator."""

    metabase_url: str | None = Field(
        default=None,
        description="Endpoint Metabase efetivamente configurado, quando o runtime veio de Settings",
    )
    metabase_database_id: int | None = Field(
        default=None,
        gt=0,
        description="Database ID Metabase em vigor: configurado, ou descoberto pelo nome do banco",
    )
    kanoe_base_url: str | None = Field(
        default=None,
        description="Endpoint Kanoê efetivamente configurado, quando o runtime veio de Settings",
    )
    kanoe_user_id: int | None = Field(
        default=None,
        gt=0,
        description="ID da identidade Kanoê em vigor: configurada, ou descoberta pelo CPF do token",
    )
    kanoe_user_name: str | None = Field(
        default=None,
        description="Nome da identidade Kanoê em vigor: configurada, ou descoberta pelo CPF do token",
    )
    setor_implicito: Literal[False] = Field(
        default=False,
        description="Pink 0.8 nunca escolhe setor global implicitamente; operações que dependem de setor exigem input explícito",
    )


class SystemStatus(PinkModel):
    """Agent-facing operational status for the Pink runtime."""

    contexto: RuntimeContext = Field(
        default_factory=RuntimeContext,
        description="Configuração não secreta e identidade efetiva deste runtime",
    )
    metabase: IntegracaoStatus = Field(description="Disponibilidade da leitura via Metabase")
    kanoe: IntegracaoStatus = Field(description="Disponibilidade da integração Kanoê/Caipora")
    google: IntegracaoStatus = Field(description="Disponibilidade da integração Google Docs/Drive")

    def __rich__(self) -> RenderableType:
        """Health first, effective non-secret context second."""
        tabela = Table(box=box.SIMPLE_HEAD, pad_edge=False, header_style="bold cyan")
        tabela.add_column("integração", no_wrap=True)
        tabela.add_column("estado", no_wrap=True)
        tabela.add_column("detalhe", overflow="fold")
        for campo, label in (
            ("metabase", "Metabase"),
            ("kanoe", "Kanoê"),
            ("google", "Google"),
        ):
            status = getattr(self, campo)
            estado = status.estado.value
            tabela.add_row(
                label,
                Text(estado, style=f"bold {_COR_DO_ESTADO.get(estado, 'white')}"),
                status.detalhe or "—",
            )
        return Group(tabela, _secao("contexto", self.contexto))


type JsonObject = Annotated[dict[str, Any], Field(title="JsonObject")]
