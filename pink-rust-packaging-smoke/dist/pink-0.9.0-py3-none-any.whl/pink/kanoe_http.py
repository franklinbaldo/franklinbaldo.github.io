"""Async HTTP adapter for the Pink 0.8 semantic Kanoê boundary.

The adapter implements only the remote behavior required by Pink 0.8 domain
capabilities. Domain Providers never see URLs, authentication headers,
pagination or Kanoê response envelopes. Historical Pink behavior is not part
of this module's contract.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
from collections.abc import AsyncGenerator, Awaitable, Callable
from datetime import UTC, datetime, timedelta
import json
from collections.abc import Mapping
from typing import Any, Final

import httpx
from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from pink.caipora import CaiporaAuthFailure
from pink.pasta_models import PastaResponsabilidade
from pink.setores import Setor
from pink.domain_types import PastaId
from pink.integrations import (
    BoxRef,
    ExpedienteRemoto,
    FonteTimeline,
    Kanoe,
    PastaOrganization,
    ResumoRemoto,
    TarefaRemota,
)
from pink.models import Disponibilidade, IntegracaoStatus, StatusTramitacao
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure

DEFAULT_BASE_URL: Final = "https://api-kanoe.sistemas.pge.ro.gov.br"
_PAGE_SIZE: Final = 100
_TAREFA_COMMENT_LIMIT: Final = 190
_TAREFA_PREFIX_RESERVE: Final = len("[99/99] ")
_BMP_MAX: Final = 0xFFFF
_SURROGATE_MIN: Final = 0xD800
_SURROGATE_MAX: Final = 0xDFFF


class _RemoteModel(BaseModel):
    """Permissive-at-edge model for Kanoê payloads; domain outputs stay strict."""

    model_config = ConfigDict(extra="ignore")


class _Sector(_RemoteModel):
    id: int
    sigla: str


class _PastaSetorPayload(_RemoteModel):
    id: PastaId
    setorResponsavelEtiqueta: Setor | None


class _PastaSetorEnvelope(_RemoteModel):
    resultados: list[_PastaSetorPayload]


class _PastaEnvelope(_RemoteModel):
    resultados: list[dict[str, Any]] = Field(default_factory=list)


class _WorkAreaPage(_RemoteModel):
    resultados: list[dict[str, Any]] = Field(default_factory=list)
    totalPaginas: int | None = None
    pagina: int | None = None


class _CorrenteIdentity(_RemoteModel):
    id: int = Field(strict=True, gt=0)


class _CorrentesEnvelope(_RemoteModel):
    resultados: list[_CorrenteIdentity]


class _Tramitacao(_RemoteModel):
    id: int
    # Obrigatório e fechado no vocabulário: campo ausente, nulo ou com código
    # que Pink não conhece não prova que a tramitação saiu da fila. Um default
    # aqui transformaria silêncio em "não pendente", que depois de um dispatch
    # vira `Confirmada`.
    statusTramitacao: StatusTramitacao


class _BoxPayload(_RemoteModel):
    id: int
    nome: str


class _TaskPending(_RemoteModel):
    id: int


class _TaskLabel(_RemoteModel):
    id: int


class _ExpedientePayload(_RemoteModel):
    id: int
    fechado: bool


_BOXES = TypeAdapter(list[_BoxPayload])
_SECTORS = TypeAdapter(list[_Sector])
_TASKS = TypeAdapter(list[_TaskPending])
_LABELS = TypeAdapter(list[_TaskLabel])


class _Usuario(_RemoteModel):
    id: int
    nome: str


class _PaginaDeUsuarios(_RemoteModel):
    resultados: list[_Usuario] = Field(default_factory=list)


_PAGINAS_DE_USUARIOS = TypeAdapter(list[_PaginaDeUsuarios])


_MARGEM_DE_EXPIRACAO: Final = timedelta(seconds=60)


def claims_do_token(authorization: str) -> dict[str, Any] | None:
    """The claims of the Bearer JWT, unverified.

    No signature check -- the claims only name who the source will hold
    accountable and when it will stop; the source itself validates the token
    on every call.
    """
    partes = authorization.split(" ", 1)[-1].split(".")
    if len(partes) != 3:
        return None
    corpo = partes[1] + "=" * (-len(partes[1]) % 4)
    try:
        claims = json.loads(base64.urlsafe_b64decode(corpo))
    except (ValueError, binascii.Error):
        return None
    return claims if isinstance(claims, dict) else None


def cpf_do_token(authorization: str) -> str | None:
    """The `sub` claim: the CPF Kanoê logs the user in with."""
    claims = claims_do_token(authorization)
    sub = claims.get("sub") if claims else None
    return str(sub) if sub else None


def token_expirado(authorization: str, agora: datetime | None = None) -> bool:
    """Whether the JWT's `exp` is past, or within a minute of it; a token without `exp` never is."""
    claims = claims_do_token(authorization)
    exp = claims.get("exp") if claims else None
    if not isinstance(exp, (int, float)):
        return False
    return datetime.fromtimestamp(exp, UTC) - _MARGEM_DE_EXPIRACAO <= (agora or datetime.now(UTC))


class KanoeAuth(httpx.Auth):
    """The Bearer token, renewed by itself when the source says it expired.

    Measured: a Kanoê token lives six hours, so a pasted `pink auth kanoe`
    stops working in the middle of a working day. With Caipora credentials
    configured (`pink auth caipora`) the boundary renews before sending a token
    it knows to be expired, and once more on a 401 that arrives anyway, then
    replays the request unchanged (the body is buffered for that). A second
    401 surfaces: that is rejected credentials, not an expired session.
    Concurrent requests renew once -- whoever finds a token newer than the
    one it sent reuses it.
    """

    requires_request_body = True

    def __init__(
        self,
        authorization: str | None,
        *,
        renovar: Callable[[], Awaitable[str]] | None = None,
        guardar: Callable[[str], None] | None = None,
    ) -> None:
        if authorization is None and renovar is None:
            raise ValueError("sem authorization nem credenciais Caipora para obtê-lo")
        self.authorization = authorization
        self._renovar = renovar
        self._guardar = guardar
        self._lock = asyncio.Lock()

    @property
    def renovavel(self) -> bool:
        return self._renovar is not None

    async def garantir(self) -> str:
        """A token believed valid: the current one, or a renewed one when missing or expired."""
        atual = self.authorization
        if atual is None or token_expirado(atual):
            # Um token que se sabe vencido não é enviado: ou se renova, ou se
            # diz desde já como obter outro, em vez de um 401 sem explicação.
            atual = await self._trocar(atual)
        return atual

    async def _trocar(self, usado: str | None) -> str:
        if self._renovar is None:
            raise CaiporaAuthFailure(
                "token Kanoê expirado ou recusado, e sem credenciais Caipora para renová-lo "
                "(`pink auth caipora --usuario <cpf>`; ou cole outro com `pink auth kanoe`)"
            )
        async with self._lock:
            if self.authorization is not None and self.authorization != usado:
                return self.authorization
            novo = await self._renovar()
            self.authorization = novo
            if self._guardar is not None:
                self._guardar(novo)
            return novo

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        usado = await self.garantir()
        request.headers["authorization"] = usado
        response = yield request
        if response.status_code != 401 or self._renovar is None:
            return
        request.headers["authorization"] = await self._trocar(usado)
        yield request

    def sync_auth_flow(self, request: httpx.Request) -> Any:
        raise RuntimeError("KanoeAuth só serve a um httpx.AsyncClient")


def _resumo_remoto(payload: Any) -> ResumoRemoto | None:
    """The summary object the Kanoê returns, or None when the shape carries no id."""
    if not isinstance(payload, dict) or not isinstance(payload.get("id"), int):
        return None
    autor = payload.get("criadoPor")
    return ResumoRemoto(
        resumo_id=payload["id"],
        resumo=str(payload.get("resumo") or ""),
        versao=int(payload.get("versao") or 0),
        avaliacao_media=payload.get("avaliacaoMedia"),
        avaliacoes=int(payload.get("total") or 0),
        criado_em=payload.get("criadoEm"),
        atualizado_em=payload.get("atualizadoEm"),
        autor=autor.get("nome") if isinstance(autor, dict) else None,
        tipo_documento=payload.get("tipoDocumento"),
    )


def _expediente_remoto(payload: Any) -> ExpedienteRemoto:
    if not isinstance(payload, dict) or not isinstance(payload.get("id"), int):
        raise RemoteObservationFailure("resposta de expediente sem id")
    pasta = payload.get("pasta") if isinstance(payload.get("pasta"), dict) else {}
    return ExpedienteRemoto(
        expediente_id=payload["id"],
        pasta_id=int(pasta.get("id") or 0),
        tipo=payload.get("tipo"),
        teor=payload.get("teor"),
        prazo=str(payload["prazo"])[:10] if payload.get("prazo") else None,
        comentario=payload.get("comentario"),
        fechado=bool(payload.get("fechado")),
    )


def _id_criado(response: Any, chave_alternativa: str) -> int | None:
    """The id of the object a Kanoê write created, wherever the envelope put it.

    Kanoê answers writes with `{"resultados": [<objeto>], ...}`; a bare list or
    a bare object are accepted too so a fake or an older shape still resolve.
    """
    if isinstance(response, dict) and isinstance(response.get("resultados"), list):
        response = response["resultados"]
    if isinstance(response, list):
        response = response[0] if response else None
    if isinstance(response, dict):
        raw_id = response.get("id") or response.get(chave_alternativa)
        if isinstance(raw_id, int):
            return raw_id
    return None


class KanoeHttp(Kanoe):
    """Concrete Kanoê adapter with no hidden current sector.

    The identity the source will hold accountable (`user_id`, `user_name`) is
    discovered from the token itself -- the JWT's `sub` is the CPF, and
    `/api/usuarios/cpf/{cpf}` names the user -- unless configured explicitly.
    """

    def __init__(
        self,
        *,
        authorization: str | None = None,
        user_id: int | None = None,
        user_name: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        client: httpx.AsyncClient | None = None,
        renovar: Callable[[], Awaitable[str]] | None = None,
        guardar: Callable[[str], None] | None = None,
    ) -> None:
        if authorization is not None and not authorization.strip():
            raise ValueError("authorization não pode ser vazio")
        # A identidade é um par atômico: ou os dois vêm do override, ou os dois
        # são descobertos do token. Metade configurada + metade descoberta seria
        # afirmar um `criadoPor` que nenhuma fonte observou.
        if (user_id is None) != (user_name is None):
            raise ValueError(
                "identidade Kanoê parcial: configure user_id e user_name juntos, ou nenhum"
            )
        if user_id is not None and user_id <= 0:
            raise ValueError("user_id deve ser positivo")
        if user_name is not None and not user_name.strip():
            raise ValueError("user_name não pode ser vazio")

        self.auth = KanoeAuth(authorization, renovar=renovar, guardar=guardar)
        self.user_id = user_id
        self.user_name = user_name
        self._headers = {
            "accept": "application/json, text/plain, */*",
            "user-agent": "pink/0.8",
        }
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=60.0,
        )
        # O token entra por `httpx.Auth`, não por header fixo: é ele que renova e
        # repete a requisição, para toda chamada deste adapter e das subclasses.
        self.client.auth = self.auth

    @property
    def authorization(self) -> str | None:
        """The Bearer token in use right now; it changes when the boundary renews it."""
        return self.auth.authorization

    async def aclose(self) -> None:
        """Close the internally-owned HTTP client."""
        if self._owns_client:
            await self.client.aclose()

    async def probe(self) -> IntegracaoStatus:
        """Probe an authenticated Kanoê read before reporting availability."""
        try:
            await self._user_sectors()
        except RemoteObservationFailure as exc:
            return IntegracaoStatus(estado=Disponibilidade.INDISPONIVEL, detalhe=str(exc))
        return IntegracaoStatus(estado=Disponibilidade.DISPONIVEL)

    async def identidade(self) -> tuple[int, str]:
        """Who the source holds accountable: configured, or discovered once from the token."""
        if self.user_id is not None and self.user_name is not None:
            return self.user_id, self.user_name
        try:
            cpf = cpf_do_token(await self.auth.garantir())
        except CaiporaAuthFailure as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        if cpf is None:
            raise RemoteObservationFailure(
                "identidade Kanoê não configurada e o token não é um JWT com `sub`; "
                "configure PINK_KANOE_USER_ID e PINK_KANOE_USER_NAME"
            )
        payload = await self._read_json("GET", f"/api/usuarios/cpf/{cpf}")
        try:
            paginas = _PAGINAS_DE_USUARIOS.validate_python(
                payload if isinstance(payload, list) else [payload]
            )
        except ValidationError as exc:
            raise RemoteObservationFailure(f"resposta inválida de usuário por CPF: {exc}") from exc
        usuarios = [u for pagina in paginas for u in pagina.resultados]
        if not usuarios:
            raise RemoteObservationFailure(
                f"o Kanoê não conhece usuário com o CPF do token ({cpf})"
            )
        self.user_id, self.user_name = usuarios[0].id, usuarios[0].nome
        return self.user_id, self.user_name

    @staticmethod
    def _sanitize_scalar(value: Any) -> Any:
        """Torna o texto gravável no Kanoê sem perder o que o autor escreveu.

        O banco do Kanoê não guarda ponto de código fora do BMP, então um emoji
        precisa atravessar de outra forma. Referência numérica de caractere
        (`&#x1F7E2;`) é ASCII puro, cabe na coluna e é reversível por quem lê --
        e o comentário do Kanoê é permanente e lido por toda a PGE, então
        descartar o caractere apagaria conteúdo de alguém, em silêncio e para
        sempre. Surrogate solto é a exceção: não representa caractere nenhum,
        não tem o que preservar, e sai.
        """
        if not isinstance(value, str):
            return value

        def codificar(char: str) -> str:
            ponto = ord(char)
            if _SURROGATE_MIN <= ponto <= _SURROGATE_MAX:
                return ""
            return char if ponto <= _BMP_MAX else f"&#x{ponto:X};"

        return "".join(codificar(char) for char in value)

    @classmethod
    def _sanitize_payload(cls, value: Any) -> Any:
        if isinstance(value, dict):
            return {key: cls._sanitize_payload(item) for key, item in value.items()}
        if isinstance(value, list):
            return [cls._sanitize_payload(item) for item in value]
        if isinstance(value, tuple):
            return [cls._sanitize_payload(item) for item in value]
        return cls._sanitize_scalar(value)

    @staticmethod
    def _composite_failure(
        exc: RemoteWriteFailure,
        *,
        wrote_any: bool,
        operation: str,
    ) -> RemoteWriteFailure:
        """Promote a later definite failure once an earlier sub-write already succeeded."""
        if not wrote_any or exc.effect_may_have_occurred:
            return exc
        return RemoteWriteFailure(
            f"{operation} parcialmente aplicada antes da falha: {exc}",
            effect_may_have_occurred=True,
        )

    async def _read_json(self, method: str, path: str, **kwargs: Any) -> Any:
        try:
            response = await self.client.request(method, path, headers=self._headers, **kwargs)
            response.raise_for_status()
        except (httpx.HTTPError, CaiporaAuthFailure) as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        try:
            return response.json()
        except ValueError as exc:
            raise RemoteObservationFailure(f"Kanoê retornou JSON inválido em {path}") from exc

    async def _read_json_ou_ausente(self, method: str, path: str, **kwargs: Any) -> Any | None:
        """Like `_read_json`, but the Kanoê's 404 (`Nenhum '…' encontrado`) is an observed absence."""
        try:
            response = await self.client.request(method, path, headers=self._headers, **kwargs)
        except (httpx.HTTPError, CaiporaAuthFailure) as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        if response.status_code == 404:
            return None
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        try:
            return response.json()
        except ValueError as exc:
            raise RemoteObservationFailure(f"Kanoê retornou JSON inválido em {path}") from exc

    async def pasta_resumo(self, pasta_id: int) -> ResumoRemoto | None:
        return _resumo_remoto(
            await self._read_json_ou_ausente("GET", f"/api/pasta-resumo/{pasta_id}/pasta")
        )

    async def componente_resumo(self, componente_id: int) -> ResumoRemoto | None:
        return _resumo_remoto(
            await self._read_json_ou_ausente(
                "GET", f"/api/componente-digital-resumo/{componente_id}/documento-digital"
            )
        )

    async def timeline_fontes(self, pasta_id: int) -> tuple[FonteTimeline, ...]:
        payload = await self._read_json(
            "GET", "/api/timeline-pje/movimentacoes/fonte-dados", params={"pastaId": pasta_id}
        )
        itens = payload.get("resultados", []) if isinstance(payload, dict) else []
        fontes = []
        for item in itens:
            dados = item.get("fonteDados") if isinstance(item, dict) else None
            if isinstance(dados, dict) and dados.get("codigo"):
                fontes.append(
                    FonteTimeline(codigo=str(dados["codigo"]), nome=str(dados.get("nome") or ""))
                )
        return tuple(fontes)

    async def timeline_movimentacoes(
        self, pasta_id: int, fonte_codigo: str
    ) -> list[dict[str, Any]]:
        # Medido ao vivo: os parâmetros vão na query string; no corpo JSON o
        # validador responde "'pastaId' ou 'numeroProcesso' é obrigatório".
        payload = await self._read_json(
            "POST",
            "/api/timeline-pje/movimentacoes",
            params={"pastaId": pasta_id, "fonteDadosCodigo": fonte_codigo},
        )
        return (
            [item for item in payload if isinstance(item, dict)]
            if isinstance(payload, list)
            else []
        )

    async def expediente_detail(self, expediente_id: int) -> ExpedienteRemoto:
        return _expediente_remoto(await self._read_json("GET", f"/api/expedientes/{expediente_id}"))

    async def alterar_expediente(
        self,
        expediente_id: int,
        *,
        prazo: str | None,
        teor: str | None,
        tipo: int | None,
    ) -> None:
        # O app envia o objeto inteiro como o carregou; um corpo enxuto passa no
        # validador e cai em 500 no controller (medido em 2026-09-10). Lê-se o
        # objeto, alteram-se só os campos pedidos, devolve-se o resto intacto.
        atual = await self._read_json("GET", f"/api/expedientes/{expediente_id}")
        if not isinstance(atual, dict):
            raise RemoteWriteFailure(
                "expediente não pôde ser lido antes da alteração", effect_may_have_occurred=False
            )
        desejado = dict(atual)
        if prazo is not None:
            desejado["prazo"] = _prazo_para_instante(prazo)
        if teor is not None:
            desejado["teor"] = teor
        if tipo is not None:
            desejado["tipo"] = tipo
        await self._write_json("PUT", "/api/expedientes/alterar", json=desejado)

    async def update_tarefa(
        self,
        *,
        tarefa_id: int,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> TarefaRemota | None:
        # Mesmo corpo do `create_tarefa` mais o id, numa lista (medido ao vivo:
        # o validador pede `pasta.id`, `setorResponsavel.id` e `urgente` inteiro).
        item: dict[str, Any] = {
            "id": tarefa_id,
            "pasta": {"id": pasta_id},
            "especieTarefa": {"id": especie_id},
            "setorResponsavel": {"id": setor_responsavel_id},
            "setorOrigem": {"id": setor_responsavel_id},
            "urgente": 1 if urgente else 0,
            "dataHoraInicioPrazo": prazo_inicio,
            "dataHoraFinalPrazo": prazo,
            "postIt": post_it,
            "solicitacaoAprovacaoResponsavel": 0,
            "statusTarefa": {"id": 3},
        }
        if expediente_id is not None:
            item["expediente"] = {"id": expediente_id}
        response = await self._write_json("PUT", "/api/tarefas/alterar", json=[item])
        resultados = response.get("resultados") if isinstance(response, dict) else None
        eco = resultados[0] if isinstance(resultados, list) and resultados else None
        if not isinstance(eco, dict) or not isinstance(eco.get("id"), int):
            return None
        urgente_eco = eco.get("urgente")
        return TarefaRemota(
            tarefa_id=eco["id"],
            post_it=eco.get("postIt"),
            prazo=str(eco["dataHoraFinalPrazo"])[:10] if eco.get("dataHoraFinalPrazo") else None,
            urgente=None if urgente_eco is None else bool(urgente_eco),
        )

    async def set_pasta_annotations(self, anotacoes: Mapping[int, str]) -> None:
        # `POST /api/pasta/anotacao` é o lote (o app: `[{id: pastaId, anotacao}]`);
        # responde 204. Caracteres fora do plano básico (emoji) dão 500 -- o
        # domínio recusa antes.
        await self._write_json(
            "POST",
            "/api/pasta/anotacao",
            json=[{"id": pasta_id, "anotacao": texto} for pasta_id, texto in anotacoes.items()],
        )

    async def _write_json(
        self, method: str, path: str, *, json: Any | None = None, **kwargs: Any
    ) -> Any:
        payload = self._sanitize_payload(json) if json is not None else None
        try:
            response = await self.client.request(
                method,
                path,
                headers=self._headers,
                json=payload,
                **kwargs,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout, CaiporaAuthFailure) as exc:
            # Sem token válido a requisição nunca sai: nenhum efeito possível.
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=False) from exc
        except httpx.HTTPError as exc:
            raise RemoteWriteFailure(str(exc), effect_may_have_occurred=True) from exc
        if 400 <= response.status_code < 500:
            raise RemoteWriteFailure(
                f"Kanoê rejeitou {method} {path} com HTTP {response.status_code}",
                effect_may_have_occurred=False,
            )
        if response.status_code >= 500:
            raise RemoteWriteFailure(
                f"Kanoê respondeu HTTP {response.status_code} após {method} {path}",
                effect_may_have_occurred=True,
            )
        if not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    async def _user_sectors(self) -> tuple[_Sector, ...]:
        user_id, _ = await self.identidade()
        payload = await self._read_json("GET", f"/api/usuarios/{user_id}/setor")
        raw = payload.get("resultados", payload) if isinstance(payload, dict) else payload
        try:
            return tuple(_SECTORS.validate_python(raw))
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida de setores do usuário: {exc}"
            ) from exc

    async def set_pasta_annotation(self, pasta_id: int, texto: str) -> None:
        await self._write_json(
            "PATCH", "/api/pasta/anotacao", json={"id": pasta_id, "anotacao": texto}
        )

    async def pasta_setor_responsavel(self, pasta_id: int) -> PastaResponsabilidade | None:
        payload = await self._read_json_ou_ausente("GET", f"/api/pasta/{pasta_id}")
        if payload is None:
            return None
        try:
            envelope = _PastaSetorEnvelope.model_validate(payload)
        except ValidationError as exc:
            msg = "Kanoê retornou uma estrutura de setor inválida"
            raise RemoteObservationFailure(msg) from exc
        if not envelope.resultados:
            return None
        if len(envelope.resultados) != 1 or envelope.resultados[0].id != pasta_id:
            msg = "Kanoê retornou identidade de pasta divergente"
            raise RemoteObservationFailure(msg)
        setor = envelope.resultados[0].setorResponsavelEtiqueta
        return PastaResponsabilidade(pasta_id=pasta_id, setor_responsavel_etiqueta=setor)

    async def pasta_annotation(self, pasta_id: int) -> str | None:
        payload = await self._read_json("GET", f"/api/pasta/{pasta_id}")
        # Reobservação que não valida é falha de observação, não prova de que a
        # escrita não aconteceu. Deixar o `ValidationError` subir cru faria a
        # capability perder o conhecimento do dispatch e devolver erro ao agente
        # em vez de `Submetida`.
        try:
            rows = _PastaEnvelope.model_validate(payload).resultados
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida ao observar a pasta {pasta_id}: {exc}"
            ) from exc
        if not rows:
            raise RemoteObservationFailure(f"pasta {pasta_id} não encontrada")
        value = rows[0].get("anotacao")
        return value if isinstance(value, str) else None

    async def set_pasta_box(self, pasta_id: int, caixa_id: int) -> None:
        user_id, _ = await self.identidade()
        await self._write_json(
            "POST",
            "/api/caixa-pasta",
            json=[
                {
                    "caixa": {"id": caixa_id},
                    "pasta": {"id": pasta_id},
                    "usuario": {"id": user_id},
                }
            ],
        )

    async def update_pasta_correntes(
        self,
        pasta_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        wrote_any = False
        if adicionar:
            try:
                await self._write_json(
                    "PUT",
                    "/api/pasta-corrente-tematica",
                    json={"idPasta": pasta_id, "ids": list(adicionar)},
                )
            except RemoteWriteFailure as exc:
                raise self._composite_failure(
                    exc,
                    wrote_any=False,
                    operation="atualização de correntes da pasta",
                ) from exc
            wrote_any = True
        for corrente_id in remover:
            try:
                await self._write_json(
                    "DELETE",
                    f"/api/pasta-corrente-tematica/pasta/{pasta_id}/corrente-tematica/{corrente_id}",
                )
            except RemoteWriteFailure as exc:
                raise self._composite_failure(
                    exc,
                    wrote_any=wrote_any,
                    operation="atualização de correntes da pasta",
                ) from exc
            wrote_any = True

    async def pasta_correntes(self, pasta_id: int) -> tuple[int, ...]:
        payload_correntes = await self._read_json(
            "GET", f"/api/pasta-corrente-tematica/pasta/{pasta_id}/corrente-tematica"
        )
        try:
            correntes = _CorrentesEnvelope.model_validate(payload_correntes)
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"corrente sem identidade observável na pasta {pasta_id}: {exc}"
            ) from exc
        return tuple(sorted({item.id for item in correntes.resultados}))

    async def pasta_organization(self, pasta_id: int, setor: str) -> PastaOrganization:
        sectors = await self._user_sectors()
        sector_id = next((item.id for item in sectors if item.sigla == setor), None)
        if sector_id is None:
            raise RemoteObservationFailure(f"setor {setor!r} não pertence ao usuário configurado")

        pagina = 0
        while True:
            payload = await self._read_json(
                "POST",
                "/api/area-trabalho/processo-judicial/recebidos",
                params={
                    "page": pagina,
                    "size": _PAGE_SIZE,
                    "sortBy": "prazoExpediente",
                    "sortDir": "ASC",
                    "setorId": sector_id,
                    "hideCaixas": "0",
                },
                json={},
            )
            try:
                page = _WorkAreaPage.model_validate(payload)
            except ValidationError as exc:
                raise RemoteObservationFailure(
                    f"resposta inválida da área de trabalho do setor {setor!r} "
                    f"na página {pagina}: {exc}"
                ) from exc
            for row in page.resultados:
                raw_id = row.get("id") or row.get("pastaId")
                if raw_id != pasta_id:
                    continue
                box = row.get("caixaId")
                corrente_ids = await self.pasta_correntes(pasta_id)
                return PastaOrganization(
                    caixa_id=int(box) if isinstance(box, int) else None,
                    corrente_ids=corrente_ids,
                )
            total_pages = page.totalPaginas
            if total_pages is not None and pagina + 1 >= total_pages:
                break
            if total_pages is None and len(page.resultados) < _PAGE_SIZE:
                break
            pagina += 1
        raise RemoteObservationFailure(
            f"pasta {pasta_id} não apareceu na área de trabalho do setor {setor!r}"
        )

    async def receive_tramitacao(self, pasta_id: int, tramitacao_id: int) -> None:
        del pasta_id
        user_id, _ = await self.identidade()
        await self._write_json(
            "POST",
            "/api/tramitacoes/receber",
            json=[
                {
                    "id": tramitacao_id,
                    "usuarioRecebimento": {"id": user_id},
                    "atualizadoPor": {"id": user_id},
                }
            ],
        )

    async def tramitacao_pending(self, pasta_id: int, tramitacao_id: int) -> bool:
        try:
            response = await self.client.get(
                f"/api/tramitacoes/pasta/{pasta_id}", headers=self._headers
            )
        except (httpx.HTTPError, CaiporaAuthFailure) as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        try:
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise RemoteObservationFailure(str(exc)) from exc
        try:
            payload = response.json()
        except ValueError as exc:
            raise RemoteObservationFailure(
                "Kanoê retornou JSON inválido ao observar tramitação"
            ) from exc
        # `False` aqui é uma afirmação forte: a tramitação não está mais pendente,
        # e depois de um dispatch isso satisfaz a postcondition e vira `Confirmada`.
        # Só uma observação que Pink leu inteira pode produzi-lo. Envelope, item
        # ou shape que não se deixam interpretar são falha de observação -- o
        # efeito fica `Submetida`/`Ambigua`, para ser reobservado.
        if not isinstance(payload, dict):
            raise RemoteObservationFailure(
                f"envelope inesperado ao observar tramitação da pasta {pasta_id}: "
                f"{type(payload).__name__}"
            )
        raw = payload.get("resultado") or payload.get("resultados") or payload
        candidates = raw if isinstance(raw, list) else [raw]
        # A pergunta é sobre uma tramitação só. Uma linha irmã malformada não
        # torna a linha alvo ilegível, então a triagem é pelo id -- o mínimo
        # necessário para saber de quem é a linha. O fail-closed continua
        # inteiro para o alvo: é ele que decide a resposta, e é ele que é
        # validado por completo.
        for item in candidates:
            if not isinstance(item, dict) or item.get("id") != tramitacao_id:
                continue
            try:
                parsed = _Tramitacao.model_validate(item)
            except ValidationError as exc:
                raise RemoteObservationFailure(
                    f"tramitação {tramitacao_id} com shape inesperado na pasta {pasta_id}: {exc}"
                ) from exc
            return parsed.statusTramitacao is StatusTramitacao.PENDENTE
        # A tramitação procurada não apareceu. A rota devolve "a tramitação atual
        # da pasta", e o Kanoê não documenta se essa resposta é completa, então
        # não dá para concluir ausência a partir dela -- e depois de um dispatch
        # concluir ausência é afirmar que a escrita surtiu efeito.
        raise RemoteObservationFailure(
            f"tramitação {tramitacao_id} não apareceu na observação da pasta {pasta_id}"
        )

    async def create_box(self, nome: str, setor_id: int) -> None:
        # `criadoPor` é obrigatório. O Kanoê já inferiu o autor do Bearer token,
        # e deixou de inferir em algum ponto antes de 2026-08-12: sem o campo a
        # API responde 400 "O campo 'id' do objeto 'criadoPor' é obrigatório", e
        # toda criação de caixa falhou até o 0.7 devolver o campo. Não retirar de
        # novo com o argumento de que o token já carrega o autor -- foi essa
        # exata premissa que quebrou, e quebrou em silêncio.
        user_id, user_name = await self.identidade()
        await self._write_json(
            "POST",
            "/api/caixas",
            json={
                "nome": nome.upper(),
                "setor": {"id": setor_id},
                "criadoPor": {"id": user_id, "nome": user_name},
            },
        )

    async def find_boxes(self, nome: str, setor_id: int) -> tuple[BoxRef, ...]:
        payload = await self._read_json(
            "GET",
            f"/api/caixas/setor/{setor_id}/search",
            params={"nome": nome},
        )
        raw = payload.get("resultados", payload) if isinstance(payload, dict) else payload
        try:
            boxes = _BOXES.validate_python(raw)
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida ao buscar caixa {nome!r} no setor {setor_id}: {exc}"
            ) from exc
        return tuple(BoxRef(id=item.id, nome=item.nome) for item in boxes)

    async def create_tarefa(
        self,
        *,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> int | None:
        item: dict[str, Any] = {
            "pasta": {"id": pasta_id},
            "especieTarefa": {"id": especie_id},
            "setorResponsavel": {"id": setor_responsavel_id},
            "setorOrigem": {"id": setor_responsavel_id},
            "urgente": 1 if urgente else 0,
            "dataHoraInicioPrazo": prazo_inicio,
            "dataHoraFinalPrazo": prazo,
            "postIt": post_it,
            "solicitacaoAprovacaoResponsavel": 0,
            "statusTarefa": {"id": 3},
        }
        if expediente_id is not None:
            item["expediente"] = {"id": expediente_id}
        # A API recebe um array de um objeto; mandar o objeto solto não cria nada.
        response = await self._write_json("POST", "/api/tarefas", json=[item])
        # Medido ao vivo em 2026-09-10: a resposta é o envelope padrão do Kanoê,
        # `{"resultados": [<tarefa completa, com id>], "successMessages": [...]}`,
        # não o array espelhado da requisição. Sem o id a escrita fica `Ambigua`
        # -- o estado que manda o agente não repetir e não deixa resolver -- e foi
        # exatamente isso que aconteceu na primeira criação real da 0.8, com a
        # tarefa criada e a resposta descartada.
        return _id_criado(response, "tarefaId")

    async def tarefa_pending(self, tarefa_id: int) -> bool:
        payload = await self._read_json(
            # A postcondition é por usuário e a criação é por setor, mas as duas
            # se encontram: `create_tarefa` omite `usuarioResponsavel`, e o Kanoê
            # atribui a tarefa ao portador do token quando o campo falta
            # (confirmado ao vivo em 2026-07-02, Pink 0.7 `kanoe/api.py`). A
            # tarefa criada aparece na fila do próprio criador.
            "GET",
            "/api/tarefas/naoConcluidas",
            params={"usuarioId": (await self.identidade())[0]},
        )
        raw = payload.get("resultados", payload) if isinstance(payload, dict) else payload
        try:
            tarefas = _TASKS.validate_python(raw)
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida de tarefas pendentes: {exc}"
            ) from exc
        return any(item.id == tarefa_id for item in tarefas)

    async def add_tarefa_comment(self, tarefa_id: int, texto: str) -> None:
        # Recortar antes de codificar mediria o comprimento errado: um emoji
        # conta 1 aqui e 9 depois de virar `&#x1F7E2;`, então um pedaço que
        # cabia passaria do limite da coluna já a caminho do banco. A
        # codificação é idempotente, então aplicá-la aqui e de novo no envio
        # não muda o texto -- só torna o limite verdadeiro.
        chunks = _comment_chunks(self._sanitize_scalar(texto))
        total = len(chunks)
        wrote_any = False
        for index, chunk in enumerate(chunks, start=1):
            prefix = f"[{index}/{total}] " if total > 1 else ""
            try:
                await self._write_json(
                    "POST",
                    "/api/comentarios-tarefa",
                    json={"tarefa": {"id": tarefa_id}, "comentario": prefix + chunk},
                )
            except RemoteWriteFailure as exc:
                raise self._composite_failure(
                    exc,
                    wrote_any=wrote_any,
                    operation="comentário multipartes da tarefa",
                ) from exc
            wrote_any = True

    async def update_tarefa_etiquetas(
        self,
        tarefa_id: int,
        adicionar: tuple[int, ...],
        remover: tuple[int, ...],
    ) -> None:
        if remover:
            raise RemoteWriteFailure(
                "a integração não possui operação de remoção de etiqueta declarada",
                effect_may_have_occurred=False,
            )
        wrote_any = False
        for etiqueta_id in adicionar:
            try:
                await self._write_json(
                    "POST",
                    "/api/tarefas-etiqueta",
                    json={"tarefa": {"id": tarefa_id}, "etiqueta": {"id": etiqueta_id}},
                )
            except RemoteWriteFailure as exc:
                raise self._composite_failure(
                    exc,
                    wrote_any=wrote_any,
                    operation="atualização de etiquetas da tarefa",
                ) from exc
            wrote_any = True

    async def tarefa_etiquetas(self, tarefa_id: int) -> tuple[int, ...]:
        payload = await self._read_json(
            "GET", "/api/tarefas-etiqueta", params={"tarefaId": tarefa_id}
        )
        raw = payload.get("resultados", payload) if isinstance(payload, dict) else payload
        try:
            labels = _LABELS.validate_python(raw)
        except ValidationError as exc:
            raise RemoteObservationFailure(f"resposta inválida de etiquetas: {exc}") from exc
        return tuple(sorted(item.id for item in labels))

    async def delete_tarefa(self, tarefa_id: int) -> None:
        await self._write_json("POST", "/api/tarefas/excluir", json=[{"id": tarefa_id}])

    async def create_expediente(self, pasta_id: int, prazo: str, teor: str) -> int | None:
        response = await self._write_json(
            "POST",
            "/api/expedientes/cadastrar",
            json={
                "tipo": 0,
                "fechado": 0,
                "prazo": _prazo_para_instante(prazo),
                "teor": teor,
                "pasta": {"id": pasta_id},
            },
        )
        # Mesmo envelope `resultados` do POST /api/tarefas (ver create_tarefa).
        return _id_criado(response, "expedienteId")

    async def expediente_closed(self, expediente_id: int) -> bool:
        payload = await self._read_json("GET", f"/api/expedientes/{expediente_id}")
        raw = payload.get("resultado", payload) if isinstance(payload, dict) else payload
        try:
            return _ExpedientePayload.model_validate(raw).fechado
        except ValidationError as exc:
            raise RemoteObservationFailure(
                f"resposta inválida de expediente {expediente_id}: {exc}"
            ) from exc

    async def set_expediente_closed(self, expediente_id: int, closed: bool) -> None:
        acao = "fechar" if closed else "abrir"
        await self._write_json(
            "POST",
            f"/api/expedientes/{acao}",
            json=[{"id": expediente_id}],
        )

    async def add_expediente_comment(self, expediente_id: int, conteudo: str) -> None:
        await self._write_json(
            "POST",
            "/api/expedientes-comentario/salvar",
            json={"expedientesId": expediente_id, "comentario": conteudo},
        )


def _prazo_para_instante(prazo: str) -> str:
    """Converte a data do domínio no instante que o Kanoê grava.

    A API guarda prazo como instante UTC e o expediente do Kanoê nasce às
    04:00Z. Mandar só a data faz a API assumir outro horário, e o expediente
    aparece no dia errado para quem lê a fila.
    """
    return f"{prazo}T04:00:00.000Z" if len(prazo) == 10 else prazo


def _comment_chunks(text: str) -> list[str]:
    """Split a task comment only when the remote field limit requires it."""
    clean = text.strip()
    if not clean:
        raise ValueError("comentário não pode ser vazio")
    if len(clean) <= _TAREFA_COMMENT_LIMIT:
        return [clean]

    payload_limit = _TAREFA_COMMENT_LIMIT - _TAREFA_PREFIX_RESERVE
    chunks: list[str] = []
    remaining = clean
    while remaining:
        if len(remaining) <= payload_limit:
            chunks.append(remaining)
            break
        split = remaining.rfind(" ", 0, payload_limit + 1)
        if split <= 0:
            split = payload_limit
        chunks.append(remaining[:split].rstrip())
        remaining = remaining[split:].lstrip()
    return chunks
