"""Parquet-first queue and reference capabilities."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Any

from pydantic import Field, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import (
    Limite,
    CaixaId,
    Cnj,
    CorrenteTematicaId,
    EtiquetaId,
    PastaId,
    SetorSigla,
    TramitacaoId,
)
from pink.integrations import Metabase
from pink.models import (
    EspecieTarefa,
    Observado,
    PinkModel,
    ResultadoColecao,
    descrever_especies_previstas,
    especie_tarefa_prevista,
    reconciliar_catalogo_de_especies,
)
from pink.queries_reference import (
    caixas_listar,
    correntes_listar,
    especies_listar,
    etiquetas_listar,
    tramitacoes_pendentes,
)
from pink.setores import Setor, ids_do_setor, setores_ativos
from pink.queries_setoriais import tramitacoes_setor
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class SetorListagem(ResultadoColecao[Setor]):
    """Setores ativos observados pela sigla exata, sem presumir unicidade."""


class TramitacaoFiltro(PinkModel):
    setor: SetorSigla = Field(description="Setor de destino explícito da fila")
    origem: SetorSigla | None = Field(default=None, description="Filtra pelo setor de origem")
    prazo_ate: date | None = Field(
        default=None, description="Filtra por prazo até a data informada"
    )


class TramitacaoResumo(PinkModel):
    tramitacao_id: TramitacaoId
    pasta_id: PastaId
    numero: Cnj | None = Field(default=None, description="Número CNJ canônico do processo da pasta")
    setor_origem: SetorSigla | None = Field(
        default=None, description="Setor de origem observado da tramitação"
    )
    setor_destino: SetorSigla = Field(description="Setor de destino observado da tramitação")
    prazo: date | None = Field(default=None, description="Prazo associado à fila quando observado")
    classe: str | None = Field(
        default=None, description="Classe processual observada para contexto"
    )
    valor_causa: Decimal | None = Field(
        default=None, description="Valor da causa observado para contexto"
    )
    criado_em: datetime = Field(description="Instante de criação observado da tramitação")
    pasta_da_autarquia: bool | None = Field(
        default=None,
        description="Indica quando a pasta foi observada como pertencente à autarquia",
    )


class CaixaFiltro(PinkModel):
    setor: SetorSigla = Field(description="Setor dono das caixas")
    termo: str | None = Field(default=None, description="Substring do nome")
    incluir_inativas: bool = Field(
        default=False,
        description="Quando true inclui também caixas inativas; false retorna somente caixas ativas",
    )


class CaixaResumo(PinkModel):
    caixa_id: CaixaId
    nome: str = Field(description="Nome observado da caixa")
    sigla: str | None = Field(
        default=None, description="Sigla observada da caixa quando disponível"
    )
    ativa: bool = Field(description="Indica se a caixa está ativa na observação")
    setor: SetorSigla = Field(description="Setor dono da caixa")


class CorrenteFiltro(PinkModel):
    termo: str | None = Field(default=None, description="Substring do nome")
    setor: SetorSigla | None = Field(
        default=None, description="Restringe ao setor quando aplicável"
    )


class CorrenteResumo(PinkModel):
    corrente_id: CorrenteTematicaId
    nome: str = Field(description="Nome observado da corrente temática")
    descricao: str | None = Field(
        default=None, description="Descrição observada da corrente temática"
    )
    setor: SetorSigla | None = Field(
        default=None, description="Setor associado quando a corrente é setorial"
    )


class EtiquetaFiltro(PinkModel):
    setor: SetorSigla = Field(description="Setor em cujas tarefas a etiqueta é usada")
    termo: str | None = Field(default=None, description="Substring do nome")


class EtiquetaResumo(PinkModel):
    etiqueta_id: EtiquetaId
    nome: str = Field(description="Nome observado da etiqueta")


class EspecieFiltro(PinkModel):
    termo: str | None = Field(default=None, description="Substring do nome")


class EspecieResumo(PinkModel):
    # O tipo é o enum, não o id solto: assim o schema publicado enumera as sete
    # espécies previstas. A descrição carrega os nomes junto, porque o JSON
    # Schema de um enum publica só os valores, e id sem nome não ensina nada.
    especie_id: EspecieTarefa = Field(
        description=(
            "Espécie de tarefa prevista pelo Pink. "
            f"Vocabulário atual: {descrever_especies_previstas()}"
        ),
        examples=[EspecieTarefa.PETICIONAR.value],
    )
    nome: str = Field(description="Nome observado da espécie de tarefa")
    descricao: str | None = Field(
        default=None, description="Descrição observada da espécie de tarefa"
    )

    @model_validator(mode="before")
    @classmethod
    def _acusar_especie_nao_prevista(cls, bruto: Any) -> Any:
        # Antes do Pydantic, para o agente receber o drift nomeado com o que foi
        # observado em vez de um ValidationError genérico de enum.
        if isinstance(bruto, Mapping):
            especie_tarefa_prevista(bruto)
        return bruto


class TramitacaoListagem(ResultadoColecao[TramitacaoResumo]):
    """Resultado Pydantic concreto da fila de tramitações."""


class CaixaListagem(ResultadoColecao[CaixaResumo]):
    """Resultado Pydantic concreto da coleção de caixas."""


class CorrenteListagem(ResultadoColecao[CorrenteResumo]):
    """Resultado Pydantic concreto da coleção de correntes."""


class EtiquetaListagem(ResultadoColecao[EtiquetaResumo]):
    """Resultado Pydantic concreto da coleção de etiquetas."""


class EspecieListagem(ResultadoColecao[EspecieResumo]):
    """Resultado Pydantic concreto da coleção de espécies."""


def build_referencia_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="setor_listar",
        tags={"setor", "read", "parquet"},
        efeito=READ,
    )
    async def setor_listar(
        limite: Limite,
        sigla: SetorSigla,
    ) -> SetorListagem:
        """Observa setores ativos pela sigla exata; vazio confirma ausência na fonte."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        result = await materializar_colecao(
            metabase, artifacts, setores_ativos(sigla), Setor, limite=limite
        )
        return SetorListagem(dados=result.dados)

    @catalogo.operacao(
        nome="tramitacao_listar",
        tags={"tramitacao", "read", "parquet"},
        efeito=READ,
    )
    async def tramitacao_listar(
        limite: Limite,
        filtro: Annotated[
            TramitacaoFiltro,
            Field(description="Filtros explícitos da fila de tramitações pendentes"),
        ],
    ) -> TramitacaoListagem:
        """Lista uma seleção limitada da fila de tramitações pendentes de um setor explícito."""
        metabase = get_metabase()
        artifacts = get_artifacts()

        async def selecao():
            return tramitacoes_pendentes(
                setor_ids=await ids_do_setor(metabase, filtro.setor),
                origem=filtro.origem,
                prazo_ate=filtro.prazo_ate,
            )

        result = await materializar_colecao(
            metabase,
            artifacts,
            selecao,
            TramitacaoResumo,
            limite=limite,
            alternativa=tramitacoes_setor(filtro.setor)
            if filtro.origem is None and filtro.prazo_ate is None
            else None,
        )
        return TramitacaoListagem(dados=result.dados)

    @catalogo.operacao(
        nome="caixa_listar",
        tags={"referencia", "caixa", "read", "parquet"},
        efeito=READ,
    )
    async def caixa_listar(
        limite: Limite,
        filtro: Annotated[
            CaixaFiltro, Field(description="Filtros explícitos da coleção de caixas do setor")
        ],
    ) -> CaixaListagem:
        """Lista caixas do setor; filtros não geram capabilities paralelas."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        expr = caixas_listar(
            setor=filtro.setor,
            termo=filtro.termo,
            incluir_inativas=filtro.incluir_inativas,
        )
        result = await materializar_colecao(metabase, artifacts, expr, CaixaResumo, limite=limite)
        return CaixaListagem(dados=result.dados)

    @catalogo.operacao(
        nome="corrente_listar",
        tags={"referencia", "corrente", "read", "parquet"},
        efeito=READ,
    )
    async def corrente_listar(
        limite: Limite,
        filtro: Annotated[
            CorrenteFiltro,
            Field(description="Filtros combináveis da coleção de correntes temáticas"),
        ] = CorrenteFiltro(),
    ) -> CorrenteListagem:
        """Lista correntes temáticas ativas por texto e, quando útil, setor."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        expr = correntes_listar(termo=filtro.termo, setor=filtro.setor)
        result = await materializar_colecao(
            metabase, artifacts, expr, CorrenteResumo, limite=limite
        )
        return CorrenteListagem(dados=result.dados)

    @catalogo.operacao(
        nome="etiqueta_listar",
        tags={"referencia", "etiqueta", "read", "parquet"},
        efeito=READ,
    )
    async def etiqueta_listar(
        limite: Limite,
        filtro: Annotated[
            EtiquetaFiltro,
            Field(description="Filtros explícitos da coleção de etiquetas usadas no setor"),
        ],
    ) -> EtiquetaListagem:
        """Lista etiquetas efetivamente usadas nas tarefas de um setor."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        expr = etiquetas_listar(setor=filtro.setor, termo=filtro.termo)
        result = await materializar_colecao(
            metabase, artifacts, expr, EtiquetaResumo, limite=limite
        )
        return EtiquetaListagem(dados=result.dados)

    @catalogo.operacao(
        nome="especie_listar",
        tags={"referencia", "especie", "read", "parquet"},
        efeito=READ,
    )
    async def especie_listar(
        limite: Limite,
        filtro: Annotated[
            EspecieFiltro, Field(description="Filtros combináveis da coleção de espécies de tarefa")
        ] = EspecieFiltro(),
    ) -> EspecieListagem:
        """Lista espécies de tarefa ativas."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        expr = especies_listar(termo=filtro.termo)
        result = await materializar_colecao(metabase, artifacts, expr, EspecieResumo, limite=limite)
        # Sem termo e com a coleção inteira na amostra, o observado é o catálogo
        # ativo completo -- só aí a ausência de uma espécie prevista é drift, e
        # não recorte do filtro. Termo vazio é ausência de filtro tanto quanto
        # `None`: é assim que a query trata (`if termo:`).
        # Só um catálogo inteiro prova ausência: sem termo e com o limite
        # folgado -- se `total == limite`, a seleção pode ter sido cortada.
        if not filtro.termo and isinstance(result.dados, Observado):
            catalogo = result.dados.valor
            if catalogo.total < limite and catalogo.total == len(catalogo.amostra):
                reconciliar_catalogo_de_especies(item.especie_id for item in catalogo.amostra)
        return EspecieListagem(dados=result.dados)

    return catalogo
