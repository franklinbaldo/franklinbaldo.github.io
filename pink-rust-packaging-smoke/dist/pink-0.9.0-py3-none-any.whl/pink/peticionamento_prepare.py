"""Recoverable petition staging for Pink 0.8.

Preparation means creating the Kanoê task that owns the future filing and
attaching one runtime-owned file artifact. It does not file anything at the
court.
"""

from __future__ import annotations

from datetime import date
from typing import Annotated, Literal, Protocol, cast

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore
from pink.documento_write import KanoeDocumentoRef
from pink.domain_types import (
    DocumentoId,
    ExpedienteId,
    FileArtifactUri,
    PastaId,
    SetorId,
    TarefaId,
)
from pink.integrations import Probe
from pink.models import (
    Disponibilidade,
    EspecieTarefa,
    OperationHandle,
    PinkModel,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure

WRITE = Efeito(
    leitura=False,
    destrutivo=False,
    idempotente=False,
    mundo_aberto=True,
)
PETICIONAR_ESPECIE_ID = EspecieTarefa.PETICIONAR


class PeticionamentoKanoe(Probe, Protocol):
    async def create_tarefa(
        self,
        *,
        pasta_id: int,
        especie_id: int,
        prazo: str,
        prazo_inicio: str | None,
        post_it: str,
        expediente_id: int | None,
        setor_responsavel_id: int | None,
        urgente: bool,
    ) -> int | None: ...
    async def tarefa_pending(self, tarefa_id: int) -> bool: ...
    async def task_documents(self, tarefa_id: int) -> tuple[KanoeDocumentoRef, ...]: ...
    async def upload_document(
        self,
        *,
        pasta_id: int,
        tarefa_id: int,
        nome: str,
        mime_type: str,
        data: bytes,
    ) -> None: ...


class PeticionamentoPreparado(PinkModel):
    estado: Literal["preparado"] = Field(
        default="preparado",
        description="Tarefa Peticionar e documento foram ambos confirmados; não há recuperação pendente",
    )
    pasta_id: PastaId
    tarefa_id: TarefaId
    documento_id: DocumentoId


class PeticionamentoPreparacaoParcial(PinkModel):
    estado: Literal["parcial"] = Field(
        default="parcial",
        description="A tarefa já existe com identidade conhecida, mas o staging ainda não terminou",
    )
    etapa: Literal["tarefa_aguardando_observacao", "upload_pendente"] = Field(
        description=(
            "Ponto seguro de recuperação sobre a tarefa já criada; não repita `peticionamento_preparar`, "
            "pois isso criaria outra tarefa"
        )
    )
    pasta_id: PastaId
    tarefa_id: TarefaId
    arquivo_uri: FileArtifactUri = Field(
        description=(
            "Artifact ainda necessário para completar a tarefa existente com `documento_enviar`; "
            "preserve `tarefa_id` e `pasta_id` em vez de recriar o staging"
        )
    )
    handle: OperationHandle = Field(
        description="Recurso (`pink recurso <uri>`) que reobserva exatamente o ponto de recuperação desta etapa"
    )
    detalhe: str = Field(min_length=1, description="Estado material que permite recuperação segura")


class PeticionamentoPreparacaoSubmetida(PinkModel):
    estado: Literal["submetida"] = Field(
        default="submetida",
        description=(
            "O upload foi aceito, mas sua postcondition ainda não foi observada; não envie o artifact novamente"
        ),
    )
    etapa: Literal["upload"] = Field(
        default="upload",
        description="Upload já despachado e aceito cuja materialização documental ainda precisa ser reobservada",
    )
    pasta_id: PastaId
    tarefa_id: TarefaId
    arquivo_uri: FileArtifactUri = Field(
        description="Artifact já submetido; preserve apenas para identidade/auditoria, não para retry automático"
    )
    handle: OperationHandle = Field(
        description="Recurso (`pink recurso <uri>`) com a coleção live de documentos da tarefa para acompanhar a postcondition"
    )
    detalhe: str = Field(
        min_length=1,
        description="Evidência de que o upload foi aceito e a observação final ainda está pendente",
    )


class PeticionamentoPreparacaoAmbigua(PinkModel):
    estado: Literal["ambigua"] = Field(
        default="ambigua",
        description="Alguma write pode ter produzido efeito remoto e não é seguro repetir a operação cegamente",
    )
    etapa: Literal["criacao_tarefa", "upload"] = Field(
        description="Write cujo efeito remoto não pôde ser determinado com segurança"
    )
    pasta_id: PastaId
    tarefa_id: TarefaId | None = Field(
        default=None,
        description="Tarefa conhecida quando a ambiguidade ocorreu depois da criação confirmada",
    )
    arquivo_uri: FileArtifactUri
    handle: OperationHandle | None = Field(
        default=None,
        description=(
            "Recurso (`pink recurso <uri>`) para reconciliar o efeito quando a identidade necessária é conhecida; "
            "None quando a própria criação da tarefa ficou sem identidade observável"
        ),
    )
    efeito_pode_ter_ocorrido: Literal[True] = Field(
        default=True,
        description="Efeito remoto possível: retry cego pode duplicar tarefa ou documento",
    )
    detalhe: str = Field(
        min_length=1, description="Evidência disponível sobre o efeito remoto incerto"
    )


class PeticionamentoPreparacaoRecusada(PinkModel):
    estado: Literal["recusada"] = Field(
        default="recusada",
        description="Nenhuma write remota ocorreu porque uma precondition recusou o staging",
    )
    motivo: str = Field(min_length=1, description="Precondition que impediu qualquer avanço seguro")


type ResultadoPreparacaoPeticionamento = Annotated[
    PeticionamentoPreparado
    | PeticionamentoPreparacaoParcial
    | PeticionamentoPreparacaoSubmetida
    | PeticionamentoPreparacaoAmbigua
    | PeticionamentoPreparacaoRecusada,
    Field(discriminator="estado", title="ResultadoPreparacaoPeticionamento"),
]


def build_peticionamento_prepare_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_kanoe() -> PeticionamentoKanoe:
        return cast(PeticionamentoKanoe, runtime.kanoe)

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="peticionamento_preparar",
        tags={"peticionamento", "write"},
        efeito=WRITE,
    )
    async def peticionamento_preparar(
        pasta_id: PastaId,
        expediente_id: ExpedienteId,
        prazo_inicio: Annotated[date, Field(description="Data inicial inclusiva do prazo")],
        prazo: Annotated[date, Field(description="Data final inclusiva do prazo")],
        setor_responsavel_id: SetorId,
        arquivo_uri: FileArtifactUri,
        comentario_inicial: Annotated[
            str | None,
            Field(description="Comentário que acompanha a tarefa Peticionar desde a criação"),
        ] = None,
        urgente: Annotated[
            bool, Field(description="Marca a tarefa Peticionar como urgente")
        ] = False,
    ) -> ResultadoPreparacaoPeticionamento:
        """Cria uma única tarefa Peticionar e anexa um artifact publicado por `arquivo_publicar`.

        Prepara, não protocola. A tarefa Peticionar é trabalho humano; o protocolo
        no PJe é `POST /api/mni/protocolar`, operação separada sobre documento.
        Um resultado `preparado` significa tarefa criada e peça anexada -- nunca
        que a petição foi protocolada.


        Se o resultado for `parcial`, preserve a `tarefa_id`: não repita esta capability.
        Leia `handle` para reobservar a etapa e complete o arquivo na tarefa existente com
        `documento_enviar` quando `etapa=upload_pendente`. Se for `submetida`, o upload já foi
        aceito: apenas reobserve `handle`, sem reenviar o artifact. Se o resultado for `ambigua`,
        não faça retry cego da etapa indicada; use `handle` quando ele estiver disponível.
        """
        kanoe = get_kanoe()
        artifacts = get_artifacts()
        if prazo < prazo_inicio:
            return PeticionamentoPreparacaoRecusada(
                motivo="prazo final não pode ser anterior ao início do prazo"
            )

        status = await kanoe.probe()
        if status.estado is Disponibilidade.INDISPONIVEL:
            return PeticionamentoPreparacaoRecusada(motivo=status.detalhe or "Kanoê indisponível")

        try:
            artifact, data = artifacts.file_from_uri(arquivo_uri)
        except (ValueError, FileNotFoundError) as exc:
            return PeticionamentoPreparacaoRecusada(motivo=str(exc))

        try:
            tarefa_id = await kanoe.create_tarefa(
                pasta_id=pasta_id,
                especie_id=PETICIONAR_ESPECIE_ID,
                prazo=prazo.isoformat(),
                prazo_inicio=prazo_inicio.isoformat(),
                post_it=comentario_inicial or "",
                expediente_id=expediente_id,
                setor_responsavel_id=setor_responsavel_id,
                urgente=urgente,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return PeticionamentoPreparacaoAmbigua(
                    etapa="criacao_tarefa",
                    pasta_id=pasta_id,
                    arquivo_uri=arquivo_uri,
                    detalhe=f"efeito da criação da tarefa é incerto: {exc}",
                )
            return PeticionamentoPreparacaoRecusada(motivo=str(exc))

        if tarefa_id is None:
            return PeticionamentoPreparacaoAmbigua(
                etapa="criacao_tarefa",
                pasta_id=pasta_id,
                arquivo_uri=arquivo_uri,
                detalhe="Kanoê aceitou a criação, mas não devolveu identidade da tarefa",
            )

        try:
            pending = await kanoe.tarefa_pending(tarefa_id)
        except RemoteObservationFailure as exc:
            return PeticionamentoPreparacaoParcial(
                etapa="tarefa_aguardando_observacao",
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/estado",
                detalhe=f"tarefa criada, mas não pôde ser reobservada: {exc}",
            )
        if not pending:
            return PeticionamentoPreparacaoParcial(
                etapa="tarefa_aguardando_observacao",
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/estado",
                detalhe="tarefa criada, mas ainda não aparece entre as tarefas pendentes",
            )

        try:
            before = {item.documento_id for item in await kanoe.task_documents(tarefa_id)}
        except RemoteObservationFailure as exc:
            return PeticionamentoPreparacaoParcial(
                etapa="upload_pendente",
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/documentos",
                detalhe=f"tarefa confirmada; base de documentos não pôde ser observada: {exc}",
            )

        try:
            await kanoe.upload_document(
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                nome=artifact.nome,
                mime_type=artifact.mime_type,
                data=data,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return PeticionamentoPreparacaoAmbigua(
                    etapa="upload",
                    pasta_id=pasta_id,
                    tarefa_id=tarefa_id,
                    arquivo_uri=arquivo_uri,
                    handle=f"kanoe://tarefa/{tarefa_id}/documentos",
                    detalhe=f"tarefa confirmada; efeito do upload é incerto: {exc}",
                )
            return PeticionamentoPreparacaoParcial(
                etapa="upload_pendente",
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/documentos",
                detalhe=f"tarefa confirmada; upload não ocorreu: {exc}",
            )

        try:
            after = {item.documento_id for item in await kanoe.task_documents(tarefa_id)}
        except RemoteObservationFailure as exc:
            return PeticionamentoPreparacaoSubmetida(
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/documentos",
                detalhe=f"upload foi aceito, mas a coleção não pôde ser reobservada: {exc}",
            )

        created = sorted(after - before)
        if len(created) == 1:
            return PeticionamentoPreparado(
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                documento_id=created[0],
            )
        if not created:
            return PeticionamentoPreparacaoSubmetida(
                pasta_id=pasta_id,
                tarefa_id=tarefa_id,
                arquivo_uri=arquivo_uri,
                handle=f"kanoe://tarefa/{tarefa_id}/documentos",
                detalhe=(
                    "upload foi aceito, mas nenhum documento novo apareceu ainda; "
                    "reobserve o handle e não reenvie o artifact"
                ),
            )
        return PeticionamentoPreparacaoAmbigua(
            etapa="upload",
            pasta_id=pasta_id,
            tarefa_id=tarefa_id,
            arquivo_uri=arquivo_uri,
            handle=f"kanoe://tarefa/{tarefa_id}/documentos",
            detalhe=f"mais de um documento novo apareceu após o upload: {created!r}",
        )

    return catalogo
