"""Documento read contracts and catalog operations."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any

from pydantic import Field, TypeAdapter, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import (
    Limite,
    Cnj,
    ComponenteDigitalId,
    DocumentoId,
    PastaId,
    TarefaId,
    cnj_storage_variants,
)
from pink.integrations import Metabase
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
    ResultadoColecao,
)
from pink.queries_case import componentes_for_documento, documento_detail, documentos_filter
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class DocumentoResumo(PinkModel):
    documento_id: DocumentoId
    pasta_id: PastaId | None = Field(
        default=None, description="Pasta destinatária do documento quando vinculada"
    )
    numero: Cnj | None = Field(
        default=None, description="Número CNJ canônico do processo associado"
    )
    tarefa_id: TarefaId | None = Field(
        default=None, description="Tarefa de origem do documento quando vinculada"
    )
    autor: str | None = Field(default=None, description="Autor observado do documento")
    redator: str | None = Field(default=None, description="Redator observado do documento")
    observacao: str | None = Field(
        default=None, description="Observação textual associada ao documento"
    )
    produzido_em: datetime | None = Field(
        default=None, description="Instante de produção observado do documento"
    )
    criado_em: datetime = Field(description="Instante de criação observado do registro")
    minuta: bool = Field(description="Indica se o documento está marcado como minuta")
    tipo: str | None = Field(default=None, description="Nome observado do tipo documental")
    tipo_sigla: str | None = Field(default=None, description="Sigla observada do tipo documental")


class DocumentoFiltro(PinkModel):
    """Seleção de documentos ancorada num processo, numa pasta ou numa tarefa.

    Não existe capability de "documentos de toda a base": são ~32 milhões de
    linhas sem índice pela ordem de criação, e a seleção sem âncora excede o
    orçamento da boundary (medido: 66 s contra 60 s). Termo, tipo e minuta
    refinam uma âncora; não a substituem.
    """

    processo: Cnj | None = Field(default=None, description="Filtra pelo número CNJ")
    pasta_id: PastaId | None = Field(default=None, description="Filtra pela pasta destinatária")
    tarefa_id: TarefaId | None = Field(default=None, description="Filtra pela tarefa de origem")
    minuta: bool | None = Field(
        default=None, description="Filtra documentos marcados ou não como minuta"
    )
    termo: str | None = Field(
        default=None,
        description=(
            "Substring case-insensitive buscada em autor, redator, observação e nome/sigla do tipo documental"
        ),
    )
    tipo: str | None = Field(
        default=None,
        description="Nome ou sigla exatos do tipo documental, comparados sem diferenciar maiúsculas/minúsculas",
    )

    @model_validator(mode="after")
    def exigir_ancora(self) -> DocumentoFiltro:
        if self.processo is None and self.pasta_id is None and self.tarefa_id is None:
            raise ValueError(
                "documento_listar exige uma âncora: processo, pasta_id ou tarefa_id "
                "(não há seleção de documentos de toda a base)"
            )
        return self


class DocumentoListagem(ResultadoColecao[DocumentoResumo]):
    """Resultado Pydantic concreto da coleção de documentos."""


class ComponenteDigital(PinkModel):
    """Metadata plus the native Resource URI for one Kanoê binary component."""

    componente_id: ComponenteDigitalId
    google_doc_id: str | None = Field(
        default=None, description="ID Google quando o componente é um Google Doc"
    )
    file_name: str | None = Field(default=None, description="Nome de arquivo observado no Kanoê")
    hash: str | None = Field(default=None, description="Hash observado do componente")
    tamanho: int | None = Field(default=None, ge=0, description="Tamanho observado em bytes")
    mimetype: str | None = Field(default=None, description="MIME type observado")
    extensao: str | None = Field(default=None, description="Extensão observada")
    criado_em: datetime | None = Field(
        default=None, description="Instante de criação do componente"
    )
    resource_uri: str = Field(
        description="URI de recurso estável para ler o conteúdo binário live no Kanoê"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_resource_uri(cls, value: Any) -> Any:
        """Derive the stable Resource URI and reject a forged conflicting value."""
        if not isinstance(value, dict):
            return value
        componente_id = value.get("componente_id")
        if componente_id is None:
            return value
        expected = f"pink://documento/componente/{componente_id}"
        supplied = value.get("resource_uri")
        if supplied is not None and supplied != expected:
            raise ValueError("resource_uri diverge de componente_id")
        return {**value, "resource_uri": expected}


class DocumentoDetalhe(PinkModel):
    documento: DocumentoResumo = Field(description="Metadados principais do documento observado")
    componentes: list[ComponenteDigital] = Field(
        default_factory=list,
        description="Componentes digitais observados; cada item anuncia seu Resource URI binário",
    )


class DocumentoResultado(PinkModel):
    dados: Observacao[DocumentoDetalhe] = Field(
        description="Documento e componentes observados no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


async def _listar(
    metabase: Metabase,
    artifacts: ArtifactStore,
    filtro: DocumentoFiltro,
    *,
    limite: int,
) -> DocumentoListagem:
    query_args = filtro.model_dump()
    query_args["processo"] = None
    expression = documentos_filter(**query_args)
    if filtro.processo is not None:
        expression = expression.filter(
            expression.numero.isin(cnj_storage_variants(filtro.processo))
        )
    resultado = await materializar_colecao(
        metabase, artifacts, expression, DocumentoResumo, limite=limite
    )
    return DocumentoListagem(dados=resultado.dados)


async def _obter(metabase: Metabase, documento_id: DocumentoId) -> DocumentoResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return DocumentoResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )
    rows = await metabase.rows(documento_detail(documento_id))
    if not rows:
        return DocumentoResultado(
            dados=Ausente(fonte=Fonte.METABASE, motivo=f"documento {documento_id} não encontrado")
        )
    components = await metabase.rows(componentes_for_documento(documento_id))
    detalhe = DocumentoDetalhe(
        documento=DocumentoResumo.model_validate(rows[0]),
        componentes=TypeAdapter(list[ComponenteDigital]).validate_python(components),
    )
    return DocumentoResultado(dados=Observado(valor=detalhe))


def build_documento_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="documento_listar",
        tags={"documento", "read", "parquet"},
        efeito=READ,
    )
    async def documento_listar(
        limite: Limite,
        filtro: Annotated[
            DocumentoFiltro,
            Field(
                description="Filtros da listagem; processo, pasta_id ou tarefa_id é obrigatório -- termo, tipo e minuta refinam"
            ),
        ],
    ) -> DocumentoListagem:
        """Materializa uma seleção de documentos limitada por `limite`, dentro dos filtros."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        return await _listar(metabase, artifacts, filtro, limite=limite)

    @catalogo.operacao(
        nome="documento_obter",
        tags={"documento", "read"},
        efeito=READ,
    )
    async def documento_obter(
        documento_id: DocumentoId,
    ) -> DocumentoResultado:
        """Obtém metadados e devolve cada componente binário como URI de recurso."""
        metabase = get_metabase()
        return await _obter(metabase, documento_id)

    return catalogo
