"""Pure Pink minuta semantics, independent of the catalog and relational backends.

The operations in :mod:`pink.minuta` are adapters over these functions.
Tests of revision control, write outcomes and Markdown compilation exercise this
module directly.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, Protocol

from pydantic import Field, model_validator

from pink.domain_types import GoogleDocId, ModeloMinutaId, PastaId, RevisionId, TarefaId
from pink.markdown_gdocs import compile_markdown
from pink.models import (
    Disponibilidade,
    IntegracaoStatus,
    Observacao,
    OperationHandle,
    PinkModel,
)
from pink.write_safety import RemoteObservationFailure, RemoteWriteFailure


class _GoogleState(Protocol):
    """Read-only view of the immutable Google response consumed by Pink."""

    @property
    def google_doc_id(self) -> str: ...

    @property
    def revision_id(self) -> str: ...

    @property
    def title(self) -> str | None: ...

    @property
    def end_index(self) -> int: ...


class _GoogleBatch(Protocol):
    """Read-only view of the immutable Google response consumed by Pink."""

    @property
    def revision_id(self) -> str: ...

    @property
    def replies(self) -> list[dict[str, Any]]: ...


class MinutaGoogle(Protocol):
    async def probe(self) -> IntegracaoStatus: ...

    async def document_state(self, google_doc_id: str) -> _GoogleState: ...

    async def batch_update(
        self,
        google_doc_id: str,
        *,
        requests: list[dict[str, Any]],
        required_revision_id: str,
    ) -> _GoogleBatch: ...


class MinutaKanoe(Protocol):
    async def probe(self) -> IntegracaoStatus: ...

    async def create_minuta(self, *, modelo_id: int, pasta_id: int, tarefa_id: int) -> str: ...


class MinutaDetalhe(PinkModel):
    google_doc_id: GoogleDocId
    revision_id: RevisionId
    title: str | None = Field(default=None, description="Título atual observado no Google Docs")
    url: str = Field(description="URL humana para abrir a minuta diretamente no Google Docs")
    markdown_resource_uri: str = Field(
        description="Recurso (`pink recurso <uri>`) com a exportação Markdown atual da minuta"
    )
    pdf_resource_uri: str = Field(
        description="Recurso (`pink recurso <uri>`) com a exportação PDF atual da minuta"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_identities(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        google_doc_id = value.get("google_doc_id")
        if google_doc_id is None:
            return value
        derived = {
            "url": f"https://docs.google.com/document/d/{google_doc_id}/edit",
            "markdown_resource_uri": f"pink://minuta/{google_doc_id}/markdown",
            "pdf_resource_uri": f"pink://minuta/{google_doc_id}/pdf",
        }
        for field, expected in derived.items():
            supplied = value.get(field)
            if supplied is not None and supplied != expected:
                raise ValueError(f"{field} diverge de google_doc_id")
        return {**value, **derived}


class MinutaResultado(PinkModel):
    dados: Observacao[MinutaDetalhe] = Field(
        description="Minuta observada no Google, ou estado explícito de indisponibilidade/desconhecimento"
    )


class MinutaCriada(PinkModel):
    estado: Literal["confirmada"] = Field(
        default="confirmada", description="O Kanoê devolveu a identidade da minuta criada"
    )
    google_doc_id: GoogleDocId
    revision_id: RevisionId | None = Field(
        default=None,
        description="Revisão Google observada após a criação, quando disponível",
    )
    url: str = Field(description="URL humana para abrir a minuta criada no Google Docs")

    @model_validator(mode="before")
    @classmethod
    def derive_url(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        google_doc_id = value.get("google_doc_id")
        if google_doc_id is None:
            return value
        expected = f"https://docs.google.com/document/d/{google_doc_id}/edit"
        if value.get("url") not in {None, expected}:
            raise ValueError("url diverge de google_doc_id")
        return {**value, "url": expected}


class MinutaCriacaoRecusada(PinkModel):
    estado: Literal["recusada"] = Field(
        default="recusada",
        description="A criação não foi despachada ou foi definitivamente recusada",
    )
    motivo: str = Field(
        min_length=1, description="Precondition ou falha definitiva que impediu a criação"
    )


class MinutaCriacaoAmbigua(PinkModel):
    estado: Literal["ambigua"] = Field(
        default="ambigua",
        description="A criação pode ter produzido efeito remoto, mas sua identidade não pôde ser confirmada",
    )
    efeito_pode_ter_ocorrido: Literal[True] = Field(
        default=True, description="Confirma que retry cego pode criar uma segunda minuta"
    )
    detalhe: str = Field(
        min_length=1,
        description="Evidência disponível sobre a criação incerta e por que ela não pode ser repetida cegamente",
    )


type ResultadoCriacaoMinuta = Annotated[
    MinutaCriada | MinutaCriacaoRecusada | MinutaCriacaoAmbigua,
    Field(discriminator="estado", title="ResultadoCriacaoMinuta"),
]


class MinutaAlterada(PinkModel):
    estado: Literal["confirmada"] = Field(
        default="confirmada",
        description="O batch Google foi confirmado e produziu uma nova revisão",
    )
    operacao: Literal["minuta_substituir_texto", "minuta_escrever"] = Field(
        description="Capability de edição que produziu a alteração confirmada"
    )
    google_doc_id: GoogleDocId
    revisao_base: RevisionId = Field(description="Revisão exigida como precondition da edição")
    revisao_atual: RevisionId = Field(
        description="Revisão resultante devolvida pelo Google após o batch"
    )
    ocorrencias_alteradas: int | None = Field(
        default=None,
        ge=1,
        description="Quantidade de ocorrências substituídas, somente para minuta_substituir_texto",
    )
    caracteres_escritos: int | None = Field(
        default=None,
        ge=1,
        description="Caracteres compilados/escritos, somente para minuta_escrever",
    )
    paragrafos: int | None = Field(
        default=None, ge=1, description="Parágrafos compilados, somente para minuta_escrever"
    )
    headings: int | None = Field(
        default=None, ge=0, description="Headings compilados, somente para minuta_escrever"
    )


class MinutaSemAlteracao(PinkModel):
    estado: Literal["sem_alteracao"] = Field(
        default="sem_alteracao",
        description="O batch foi processado com segurança, mas nenhuma ocorrência correspondeu à busca",
    )
    operacao: Literal["minuta_substituir_texto"] = Field(
        default="minuta_substituir_texto",
        description="Operação literal de substituição que não encontrou ocorrências",
    )
    google_doc_id: GoogleDocId
    revisao_base: RevisionId = Field(description="Revisão usada como precondition da tentativa")
    revisao_atual: RevisionId = Field(
        description="Revisão devolvida pelo Google após processar o batch"
    )
    motivo: str = Field(
        min_length=1, description="Explicação material de por que nada foi alterado"
    )


class MinutaEdicaoRecusada(PinkModel):
    estado: Literal["recusada"] = Field(
        default="recusada",
        description="A edição não produziu efeito remoto possível e pode ser reformulada com segurança",
    )
    operacao: Literal["minuta_substituir_texto", "minuta_escrever"] = Field(
        description="Capability de edição recusada"
    )
    google_doc_id: GoogleDocId
    revisao_base: RevisionId = Field(
        description="Revisão apresentada pelo caller como precondition"
    )
    revisao_atual: RevisionId | None = Field(
        default=None,
        description="Revisão atual observada quando a recusa decorreu de drift ou validação local",
    )
    motivo: str = Field(min_length=1, description="Precondition ou validação que recusou a edição")


class MinutaEdicaoAmbigua(PinkModel):
    estado: Literal["ambigua"] = Field(
        default="ambigua",
        description="O batch pode ter produzido efeito remoto e retry cego é inseguro",
    )
    operacao: Literal["minuta_substituir_texto", "minuta_escrever"] = Field(
        description="Capability cuja edição ficou incerta"
    )
    google_doc_id: GoogleDocId
    revisao_base: RevisionId = Field(
        description="Revisão usada como precondition do batch potencialmente aplicado"
    )
    handle: OperationHandle = Field(
        description="Recurso (`pink recurso <uri>`) com identity/revision atual para reconciliar o batch antes de qualquer retry"
    )
    efeito_pode_ter_ocorrido: Literal[True] = Field(
        default=True,
        description="Confirma que a edição pode já estar aplicada e deve ser reobservada antes de qualquer retry",
    )
    detalhe: str = Field(
        min_length=1, description="Evidência disponível sobre a ambiguidade da edição"
    )


type EfeitoSubstituicaoMinuta = Annotated[
    MinutaAlterada | MinutaSemAlteracao | MinutaEdicaoRecusada | MinutaEdicaoAmbigua,
    Field(discriminator="estado", title="EfeitoSubstituicaoMinuta"),
]

type EfeitoEscritaMinuta = Annotated[
    MinutaAlterada | MinutaEdicaoRecusada | MinutaEdicaoAmbigua,
    Field(discriminator="estado", title="EfeitoEscritaMinuta"),
]


async def criar_minuta(
    kanoe: MinutaKanoe,
    google: MinutaGoogle,
    *,
    modelo_id: ModeloMinutaId,
    pasta_id: PastaId,
    tarefa_id: TarefaId,
) -> ResultadoCriacaoMinuta:
    status = await kanoe.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return MinutaCriacaoRecusada(motivo=status.detalhe or "Kanoê indisponível")
    try:
        google_doc_id = await kanoe.create_minuta(
            modelo_id=modelo_id,
            pasta_id=pasta_id,
            tarefa_id=tarefa_id,
        )
    except RemoteWriteFailure as exc:
        if exc.effect_may_have_occurred:
            return MinutaCriacaoAmbigua(detalhe=str(exc))
        return MinutaCriacaoRecusada(motivo=str(exc))
    except RemoteObservationFailure as exc:
        return MinutaCriacaoAmbigua(detalhe=str(exc))

    revision: RevisionId | None = None
    try:
        if (await google.probe()).estado is Disponibilidade.DISPONIVEL:
            revision = (await google.document_state(google_doc_id)).revision_id
    except RemoteObservationFailure:
        revision = None
    return MinutaCriada.model_validate({"google_doc_id": google_doc_id, "revision_id": revision})


async def substituir_texto(
    google: MinutaGoogle,
    *,
    google_doc_id: GoogleDocId,
    revisao_base: RevisionId,
    buscar: str,
    substituir: str,
    diferenciar_maiusculas: bool = True,
) -> EfeitoSubstituicaoMinuta:
    try:
        current = await google.document_state(google_doc_id)
    except RemoteObservationFailure as exc:
        return MinutaEdicaoRecusada(
            operacao="minuta_substituir_texto",
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            motivo=f"não foi possível estabelecer a revisão atual antes da escrita: {exc}",
        )
    if current.revision_id != revisao_base:
        return MinutaEdicaoRecusada(
            operacao="minuta_substituir_texto",
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            revisao_atual=current.revision_id,
            motivo="a minuta mudou desde a revisão usada como base",
        )
    request = {
        "replaceAllText": {
            "containsText": {"text": buscar, "matchCase": diferenciar_maiusculas},
            "replaceText": substituir,
        }
    }
    outcome = await _dispatch(
        google,
        google_doc_id=google_doc_id,
        revisao_base=revisao_base,
        operacao="minuta_substituir_texto",
        requests=[request],
    )
    if isinstance(outcome, (MinutaEdicaoRecusada, MinutaEdicaoAmbigua)):
        return outcome
    occurrences = _occurrences_changed(outcome.replies)
    if occurrences == 0:
        return MinutaSemAlteracao(
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            revisao_atual=outcome.revision_id,
            motivo=f"nenhuma ocorrência de {buscar!r} foi encontrada",
        )
    return MinutaAlterada(
        operacao="minuta_substituir_texto",
        google_doc_id=google_doc_id,
        revisao_base=revisao_base,
        revisao_atual=outcome.revision_id,
        ocorrencias_alteradas=occurrences,
    )


async def escrever_minuta(
    google: MinutaGoogle,
    *,
    google_doc_id: GoogleDocId,
    revisao_base: RevisionId,
    markdown: str,
    stylesheet: str | None = None,
) -> EfeitoEscritaMinuta:
    try:
        current = await google.document_state(google_doc_id)
    except RemoteObservationFailure as exc:
        return MinutaEdicaoRecusada(
            operacao="minuta_escrever",
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            motivo=f"não foi possível estabelecer a revisão atual antes da escrita: {exc}",
        )
    if current.revision_id != revisao_base:
        return MinutaEdicaoRecusada(
            operacao="minuta_escrever",
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            revisao_atual=current.revision_id,
            motivo="a minuta mudou desde a revisão usada como base",
        )
    try:
        compiled = compile_markdown(
            markdown,
            stylesheet=stylesheet,
            current_end_index=current.end_index,
        )
    except ValueError as exc:
        return MinutaEdicaoRecusada(
            operacao="minuta_escrever",
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            revisao_atual=current.revision_id,
            motivo=str(exc),
        )
    outcome = await _dispatch(
        google,
        google_doc_id=google_doc_id,
        revisao_base=revisao_base,
        operacao="minuta_escrever",
        requests=compiled.requests,
    )
    if isinstance(outcome, (MinutaEdicaoRecusada, MinutaEdicaoAmbigua)):
        return outcome
    return MinutaAlterada(
        operacao="minuta_escrever",
        google_doc_id=google_doc_id,
        revisao_base=revisao_base,
        revisao_atual=outcome.revision_id,
        caracteres_escritos=compiled.characters,
        paragrafos=compiled.paragraphs,
        headings=compiled.headings,
    )


async def _dispatch(
    google: MinutaGoogle,
    *,
    google_doc_id: GoogleDocId,
    revisao_base: RevisionId,
    operacao: Literal["minuta_substituir_texto", "minuta_escrever"],
    requests: list[dict[str, Any]],
) -> _GoogleBatch | MinutaEdicaoRecusada | MinutaEdicaoAmbigua:
    try:
        return await google.batch_update(
            google_doc_id,
            requests=requests,
            required_revision_id=revisao_base,
        )
    except RemoteWriteFailure as exc:
        if exc.effect_may_have_occurred:
            return MinutaEdicaoAmbigua(
                operacao=operacao,
                google_doc_id=google_doc_id,
                revisao_base=revisao_base,
                handle=f"pink://minuta/{google_doc_id}",
                detalhe=f"efeito remoto incerto após batchUpdate: {exc}",
            )
        return MinutaEdicaoRecusada(
            operacao=operacao,
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            motivo=str(exc),
        )
    except RemoteObservationFailure as exc:
        return MinutaEdicaoAmbigua(
            operacao=operacao,
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            handle=f"pink://minuta/{google_doc_id}",
            detalhe=f"Google aceitou a escrita, mas a resposta não pôde ser validada: {exc}",
        )


def _occurrences_changed(replies: list[dict[str, Any]]) -> int:
    total = 0
    for reply in replies:
        replace = reply.get("replaceAllText")
        if not isinstance(replace, dict):
            continue
        changed = replace.get("occurrencesChanged")
        if isinstance(changed, int):
            total += changed
    return total
