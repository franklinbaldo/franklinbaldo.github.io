"""Materializa os expedientes do setor como conceitos OKF `Expediente`.

O consumidor (o repositório `judicial`) versiona um arquivo por expediente: o
Pink escreve o que é observação do Kanoê, e o setor escreve, no mesmo arquivo,
o que é trabalho interno (estado, próxima ação, notas). O contrato do tipo é
publicado por este pacote (`pink okf specs`), e o consumidor só o consome.

Três regras tornam a escrita segura e idempotente:

1. **Só os campos do Pink.** Num arquivo existente, a escrita troca apenas as
   linhas dos campos de `CAMPOS_DO_PINK` cujo valor mudou; o resto do
   frontmatter e o corpo ficam byte a byte. Rodar duas vezes sem mudança no
   Kanoê não altera arquivo nenhum.
2. **Teor incremental.** O teor de um expediente não muda depois de criado, e
   é gravado uma vez, na criação do arquivo, como seção `## Teor`. Não se
   versiona a história do processo, só a comunicação que chega.
3. **Cobertura comprovada ou nada.** Seleção truncada ou no limite recusa a
   rodada inteira, antes de gravar.

`criado_em` e `title` são imutáveis e só entram quando ausentes. Horários
seguem a convenção já adotada pelo consumidor: o relógio que a fonte devolve,
com o fuso do setor (`-04:00`).
"""

from __future__ import annotations

import asyncio
import html
from dataclasses import dataclass, field
from datetime import datetime
from importlib.resources import files
from pathlib import Path
import re
from typing import Any

from pink.expediente import ExpedienteDetalhe, _obter
from pink.metabase import ObservacaoTruncada
from pink.models import Observado
from pink.queries_case import expedientes_filter
from pink.queries_setoriais import expedientes_abertos_setor
from pink.setores import ids_do_setor
from pink.system import Runtime
from pink.write_safety import ConsultaSemCard, RemoteObservationFailure

FUSO = "-04:00"
LIMITE = 2000
CONCORRENCIA = 4
TIPO = "Expediente"
TIPOS_ANTERIORES = frozenset({"Acompanhamento"})
CAMPOS_DO_PINK = (
    "type",
    "title",
    "pasta_id",
    "expediente_id",
    "cnj",
    "tipo_kanoe",
    "prazo_kanoe",
    "fechado",
    "criado_em",
    "n_comentarios_kanoe",
)
IMUTAVEIS = frozenset({"title", "criado_em", "pasta_id", "expediente_id"})
SPECS = ("expediente.md", "expediente.schema.sql")


class CoberturaNaoComprovada(RuntimeError):
    """A seleção não prova que todos os expedientes abertos foram observados."""


def _instante(valor: datetime, *, milissegundos: bool = False) -> str:
    base = valor.strftime("%Y-%m-%dT%H:%M:%S")
    return f"'{base}{'.000' if milissegundos else ''}{FUSO}'"


def campos(detalhe: ExpedienteDetalhe) -> dict[str, str]:
    """Os campos do Pink já formatados como valor YAML de uma linha."""
    e = detalhe.expediente
    valores: dict[str, str | None] = {
        "type": TIPO,
        "title": f"Expediente {e.expediente_id}",
        "pasta_id": str(e.pasta_id),
        "expediente_id": str(e.expediente_id),
        "cnj": str(e.numero) if e.numero else None,
        "tipo_kanoe": str(e.tipo) if e.tipo is not None else None,
        "prazo_kanoe": _instante(e.prazo) if e.prazo else None,
        "fechado": "true" if e.fechado else "false",
        "criado_em": _instante(e.criado_em, milissegundos=True),
        "n_comentarios_kanoe": str(len(detalhe.comentarios)),
    }
    return {chave: valor for chave, valor in valores.items() if valor is not None}


def caminho(destino: Path, detalhe: ExpedienteDetalhe) -> Path:
    e = detalhe.expediente
    return destino / str(e.pasta_id) / f"{e.criado_em:%Y-%m-%d}-{e.expediente_id}.md"


_QUEBRA_RE = re.compile(r"(?i)<br\s*/?>|</p\s*>|</div\s*>")
_TAG_RE = re.compile(r"<[^>]+>")


def _reparar_linha(linha: str) -> str:
    """Desfaz UTF-8 lido como Latin-1 (`SENTENÃ\\x87A`), só quando é reversível.

    A comunicação do PJe chega ao Kanoê com parte do texto duplamente
    codificada (medido em 2026-09-24: "SENTENÃA" no lugar de "SENTENÇA"). O
    reparo só vale se a linha inteira voltar a UTF-8 válido; qualquer caractere
    fora de Latin-1 ou sequência inválida mantém a linha como veio, para que
    texto correto nunca seja alterado.
    """
    if "Ã" not in linha and "Â" not in linha:
        return linha
    try:
        return linha.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return linha


def teor_legivel(bruto: str | None) -> str:
    """O teor como texto: quebras de HTML viram linha, as demais tags saem."""
    texto = html.unescape(_TAG_RE.sub("", _QUEBRA_RE.sub("\n", bruto or "")))
    linhas = [_reparar_linha(linha.rstrip()) for linha in texto.split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(linhas)).strip()


def novo(detalhe: ExpedienteDetalhe) -> str:
    """Arquivo de um expediente que chega agora: campos do Pink e o teor."""
    linhas = ["---", *(f"{k}: {v}" for k, v in campos(detalhe).items()), "---", ""]
    teor = teor_legivel(detalhe.expediente.teor)
    if teor:
        linhas += ["## Teor", "", teor, ""]
    return "\n".join(linhas)


def mesclar(existente: str, detalhe: ExpedienteDetalhe) -> str:
    """Atualiza só as linhas dos campos do Pink; o resto fica byte a byte."""
    linhas = existente.split("\n")
    if not linhas or linhas[0].strip() != "---":
        raise ValueError("arquivo sem frontmatter")
    fim = next((i for i, linha in enumerate(linhas[1:], 1) if linha.strip() == "---"), None)
    if fim is None:
        raise ValueError("frontmatter não fechado")
    posicao = {
        linha.split(":", 1)[0]: i for i, linha in enumerate(linhas[1:fim], 1) if ":" in linha
    }
    novas: list[str] = []
    for chave, valor in campos(detalhe).items():
        if chave in posicao:
            if chave in IMUTAVEIS:
                continue
            linhas[posicao[chave]] = f"{chave}: {valor}"
        else:
            novas.append(f"{chave}: {valor}")
    return "\n".join([*linhas[:fim], *novas, *linhas[fim:]])


# Aceita comentário YAML no fim da linha: o consumidor anota à mão, e um
# `expediente_id: 1214638  # CONFERIR ...` fez o arquivo passar despercebido.
_ID_RE = re.compile(r"(?m)^expediente_id:\s*(\d+)\s*(?:#.*)?$")
_FECHADO_RE = re.compile(r"(?m)^fechado:\s*true\s*$")
_TIPO_RE = re.compile(r"(?m)^type:\s*(\S+)\s*$")


def _frontmatter(texto: str) -> str:
    partes = texto.split("---", 2)
    return partes[1] if len(partes) == 3 and not partes[0].strip() else ""


def existentes(destino: Path) -> dict[int, Path]:
    """Arquivos do tipo no destino, por `expediente_id` do frontmatter."""
    achados: dict[int, Path] = {}
    for arquivo in sorted(destino.glob("*/*.md")):
        fm = _frontmatter(arquivo.read_text(encoding="utf-8"))
        tipo = _TIPO_RE.search(fm)
        numero = _ID_RE.search(fm)
        if not tipo or not numero or tipo.group(1) not in {TIPO, *TIPOS_ANTERIORES}:
            continue
        achados[int(numero.group(1))] = arquivo
    return achados


@dataclass
class Relatorio:
    criados: list[Path] = field(default_factory=list)
    atualizados: list[Path] = field(default_factory=list)
    iguais: int = 0
    falhas: dict[int, str] = field(default_factory=dict)


async def _abertos(runtime: Runtime, setor: str) -> list[int]:
    metabase = runtime.metabase
    ids = await ids_do_setor(metabase, setor)
    try:
        try:
            linhas = await metabase.rows(
                expedientes_filter(setor_ids=ids, aberto=True).limit(LIMITE)
            )
        except ConsultaSemCard:
            linhas = await metabase.rows(expedientes_abertos_setor(setor).limit(LIMITE))
    except ObservacaoTruncada as exc:
        raise CoberturaNaoComprovada(f"a fonte truncou em {exc.truncado_em} linhas") from exc
    if len(linhas) >= LIMITE:
        raise CoberturaNaoComprovada(f"a seleção atingiu o limite de {LIMITE}")
    return sorted(int(linha["expediente_id"]) for linha in linhas)


async def exportar_expedientes(
    runtime: Runtime, setor: str, destino: Path, *, gravar: bool = True
) -> Relatorio:
    """Cria o arquivo de cada expediente aberto e atualiza os já materializados."""
    abertos = await _abertos(runtime, setor)
    ja = existentes(destino)
    # Os que fecharam desde a última rodada saem da seleção de abertos: sem
    # relê-los, o arquivo ficaria com `fechado: false` para sempre.
    fechando = [
        numero
        for numero, arquivo in ja.items()
        if numero not in abertos
        and not _FECHADO_RE.search(_frontmatter(arquivo.read_text(encoding="utf-8")))
    ]
    relatorio = Relatorio()
    semaforo = asyncio.Semaphore(CONCORRENCIA)

    async def um(numero: int) -> None:
        async with semaforo:
            try:
                resultado = await _obter(runtime.metabase, numero)
            except RemoteObservationFailure as exc:
                relatorio.falhas[numero] = str(exc)
                return
        if not isinstance(resultado.dados, Observado):
            relatorio.falhas[numero] = str(getattr(resultado.dados, "motivo", resultado.dados))
            return
        detalhe = resultado.dados.valor
        arquivo = ja.get(numero)
        if arquivo is None:
            alvo = caminho(destino, detalhe)
            relatorio.criados.append(alvo)
            if gravar:
                alvo.parent.mkdir(parents=True, exist_ok=True)
                alvo.write_text(novo(detalhe), encoding="utf-8", newline="\n")
            return
        atual = arquivo.read_text(encoding="utf-8")
        mesclado = mesclar(atual, detalhe)
        if mesclado == atual:
            relatorio.iguais += 1
            return
        relatorio.atualizados.append(arquivo)
        if gravar:
            arquivo.write_text(mesclado, encoding="utf-8", newline="\n")

    await asyncio.gather(*(um(numero) for numero in [*abertos, *fechando]))
    relatorio.criados.sort()
    relatorio.atualizados.sort()
    return relatorio


def exportar_specs(destino: Path) -> list[Path]:
    """Publica o contrato do tipo `Expediente` para o consumidor."""
    destino.mkdir(parents=True, exist_ok=True)
    origem = files("pink") / "okf_specs"
    escritos: list[Path] = []
    for nome in SPECS:
        alvo = destino / nome
        conteudo = (origem / nome).read_text(encoding="utf-8")
        if not alvo.exists() or alvo.read_text(encoding="utf-8") != conteudo:
            alvo.write_text(conteudo, encoding="utf-8", newline="\n")
            escritos.append(alvo)
    return escritos


def resumo_do_relatorio(relatorio: Relatorio) -> dict[str, Any]:
    return {
        "criados": len(relatorio.criados),
        "atualizados": len(relatorio.atualizados),
        "iguais": relatorio.iguais,
        "falhas": relatorio.falhas,
    }


__all__ = [
    "CAMPOS_DO_PINK",
    "CoberturaNaoComprovada",
    "Relatorio",
    "exportar_expedientes",
    "exportar_specs",
    "mesclar",
    "novo",
    "resumo_do_relatorio",
]
