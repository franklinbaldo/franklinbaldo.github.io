"""Pure state-write semantics for closing and reopening expedientes.

The catalog only publishes these operations.  Their safety contract belongs to
Pink: observe first, never blind-write when observation fails, and confirm the
postcondition after dispatch.  Keeping that logic here lets those invariants be
tested without the catalog, Ibis or DuckDB.
"""

from __future__ import annotations

from typing import Protocol

from pink.models import Confirmada, EfeitoEscrita, IntegracaoStatus, Recusada
from pink.write_safety import observe_precondition, refuse_if_unavailable, write_and_confirm


class ExpedienteStatePort(Protocol):
    async def probe(self) -> IntegracaoStatus: ...

    async def expediente_closed(self, expediente_id: int) -> bool: ...

    async def set_expediente_closed(self, expediente_id: int, closed: bool) -> None: ...


async def fechar_expediente(kanoe: ExpedienteStatePort, expediente_id: int) -> EfeitoEscrita:
    """Close only after the current state is observable."""
    unavailable = await refuse_if_unavailable(kanoe, operacao="expediente_fechar", nome="Kanoê")
    if unavailable is not None:
        return unavailable
    current = await observe_precondition(
        operacao="expediente_fechar",
        observe=lambda: kanoe.expediente_closed(expediente_id),
    )
    if isinstance(current, Recusada):
        return current
    if current:
        return Confirmada(
            operacao="expediente_fechar",
            recurso_id=expediente_id,
            detalhe="o expediente observado já está fechado",
        )
    return await write_and_confirm(
        operacao="expediente_fechar",
        recurso_id=expediente_id,
        write=lambda: kanoe.set_expediente_closed(expediente_id, True),
        observe=lambda: kanoe.expediente_closed(expediente_id),
        expected=True,
        handle=f"kanoe:expediente:{expediente_id}",
    )


async def reabrir_expediente(kanoe: ExpedienteStatePort, expediente_id: int) -> EfeitoEscrita:
    """Reopen only after the current state is observable."""
    unavailable = await refuse_if_unavailable(kanoe, operacao="expediente_reabrir", nome="Kanoê")
    if unavailable is not None:
        return unavailable
    current = await observe_precondition(
        operacao="expediente_reabrir",
        observe=lambda: kanoe.expediente_closed(expediente_id),
    )
    if isinstance(current, Recusada):
        return current
    if not current:
        return Confirmada(
            operacao="expediente_reabrir",
            recurso_id=expediente_id,
            detalhe="o expediente observado já está aberto",
        )
    return await write_and_confirm(
        operacao="expediente_reabrir",
        recurso_id=expediente_id,
        write=lambda: kanoe.set_expediente_closed(expediente_id, False),
        observe=lambda: kanoe.expediente_closed(expediente_id),
        expected=False,
        handle=f"kanoe:expediente:{expediente_id}",
    )
