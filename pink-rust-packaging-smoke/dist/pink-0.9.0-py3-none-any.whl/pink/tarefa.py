"""Task domain read contracts and catalog operations."""

from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Any

from pydantic import Field, TypeAdapter, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import (
    com_url_da_pasta,
    Limite,
    Cnj,
    DocumentoId,
    EspecieTarefaId,
    EtiquetaId,
    ExpedienteId,
    PastaId,
    ProcessoId,
    SetorSigla,
    TarefaId,
    cnj_storage_variants,
)
from pink.integrations import Metabase
from pink.setores import ids_do_setor
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
    ResultadoColecao,
)
from pink.queries import (
    comentarios_for_tarefa,
    etiquetas_for_tarefa,
    historicos_for_tarefa,
    tarefa_detail,
    tarefas_filter,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class TarefaResumo(PinkModel):
    """Operational task projection used in task collections."""

    tarefa_id: TarefaId
    pasta_id: PastaId
    setor: SetorSigla = Field(description="Setor da pasta na observação")
    numero: Cnj | None = Field(default=None, description="Número CNJ associado")
    titulo: str | None = Field(default=None, description="Espécie/título da tarefa")
    urgente: bool = Field(description="Marca de urgência observada")
    prazo: datetime | None = Field(default=None, description="Prazo final da tarefa")
    concluida_em: datetime | None = Field(
        default=None, description="Instante de conclusão, se concluída"
    )
    criado_em: datetime = Field(description="Instante de criação")
    especie_id: EspecieTarefaId | None = Field(default=None, description="Espécie da tarefa")
    usuario_id: int | None = Field(
        default=None, gt=0, description="Usuário responsável quando atribuído"
    )


class TarefaFiltro(PinkModel):
    """Composable task query replacing special-purpose task list views."""

    setor: SetorSigla | None = Field(default=None, description="Filtra pela sigla do setor")
    processo: Cnj | None = Field(default=None, description="Filtra pelo número CNJ")
    pasta_id: PastaId | None = Field(default=None, description="Filtra por pasta")
    usuario_id: int | None = Field(
        default=None,
        gt=0,
        description="Filtra pelo usuário responsável, atravessando setores quando `setor` não é informado",
    )
    aberta: bool | None = Field(
        default=True,
        description="True seleciona abertas, False concluídas e None ambos os estados",
    )
    prazo_de: date | None = Field(default=None, description="Início inclusivo da janela de prazo")
    prazo_ate: date | None = Field(default=None, description="Fim inclusivo da janela de prazo")
    especie_id: EspecieTarefaId | None = Field(
        default=None, description="Filtra pela espécie da tarefa"
    )

    @model_validator(mode="after")
    def validar_janela_prazo(self) -> TarefaFiltro:
        if (
            self.prazo_de is not None
            and self.prazo_ate is not None
            and self.prazo_ate < self.prazo_de
        ):
            raise ValueError("prazo_ate não pode ser anterior a prazo_de")
        return self


class TarefaListagem(ResultadoColecao[TarefaResumo]):
    """Resultado Pydantic concreto da coleção de tarefas."""


class TarefaComentario(PinkModel):
    comentario_id: int = Field(gt=0, description="ID remoto do comentário")
    comentario: str | None = Field(default=None, description="Texto observado do comentário")
    criado_em: datetime | None = Field(default=None, description="Instante de criação")
    criado_por: int | None = Field(default=None, gt=0, description="ID do autor quando disponível")


class TarefaHistorico(PinkModel):
    historico_id: int = Field(gt=0, description="ID remoto do evento histórico")
    descricao: str | None = Field(default=None, description="Descrição do evento")
    acao: str | None = Field(default=None, description="Código/nome da ação")
    criado_em: datetime | None = Field(default=None, description="Instante do evento")
    comentario_tarefa_id: int | None = Field(
        default=None,
        gt=0,
        description="Comentário relacionado quando o histórico decorre de comentário",
    )


class TarefaEtiqueta(PinkModel):
    etiqueta_id: EtiquetaId
    nome: str = Field(description="Nome observado da etiqueta")


class TarefaDados(PinkModel):
    """Main task row with case and linked-resource breadcrumbs."""

    tarefa_id: TarefaId
    titulo: str | None = Field(default=None, description="Título/espécie observado da tarefa")
    descricao: str | None = Field(default=None, description="Descrição textual observada da tarefa")
    status: str | None = Field(default=None, description="Status remoto observado da tarefa")
    urgente: bool = Field(default=False, description="Marca de urgência observada")
    post_it: str | None = Field(default=None, description="Anotação operacional curta da tarefa")
    prazo_inicio: datetime | None = Field(
        default=None, description="Início observado da contagem de prazo"
    )
    prazo: datetime | None = Field(default=None, description="Prazo final observado da tarefa")
    concluida_em: datetime | None = Field(
        default=None, description="Instante de conclusão quando a tarefa está concluída"
    )
    criado_em: datetime | None = Field(
        default=None, description="Instante de criação observado da tarefa"
    )
    pasta_id: PastaId
    pasta_url: str = Field(
        description="Página da pasta vinculada na interface web do Kanoê, para o humano abrir"
    )
    setor_pasta: SetorSigla = Field(description="Setor ao qual a pasta pertence na observação")
    setor_responsavel: SetorSigla | None = Field(
        default=None, description="Setor responsável pela tarefa quando distinto/observável"
    )
    processo_id: ProcessoId | None = Field(
        default=None, description="Registro físico de processo associado à pasta"
    )
    numero: Cnj | None = Field(
        default=None, description="Número CNJ canônico do processo associado"
    )
    expediente_id: ExpedienteId | None = Field(
        default=None, description="Expediente que motivou a tarefa quando vinculado"
    )
    documento_id: DocumentoId | None = Field(
        default=None, description="Documento principal associado à tarefa quando disponível"
    )
    documento_autor: str | None = Field(
        default=None, description="Autor observado do documento principal associado"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_pasta_url(cls, value: Any) -> Any:
        return com_url_da_pasta(value, campo="pasta_url")


class TarefaDetalhe(PinkModel):
    """Complete task read composed from independently typed observations."""

    tarefa: TarefaDados = Field(description="Linha principal da tarefa com breadcrumbs do caso")
    comentarios: list[TarefaComentario] = Field(
        default_factory=list,
        description="Comentários observados da tarefa em ordem da query de domínio",
    )
    historico: list[TarefaHistorico] = Field(
        default_factory=list,
        description="Eventos históricos observados da tarefa em ordem cronológica",
    )
    etiquetas: list[TarefaEtiqueta] = Field(
        default_factory=list,
        description="Etiquetas atualmente vinculadas à tarefa",
    )


class TarefaResultado(PinkModel):
    dados: Observacao[TarefaDetalhe] = Field(
        description="Detalhe da tarefa observado no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


async def _listar(
    metabase: Metabase,
    artifacts: ArtifactStore,
    filtro: TarefaFiltro,
    *,
    limite: int,
) -> TarefaListagem:
    query_args = filtro.model_dump()
    query_args["processo"] = None
    setor = query_args.pop("setor")

    async def selecao():
        ids = await ids_do_setor(metabase, setor) if setor is not None else None
        expression = tarefas_filter(setor_ids=ids, **query_args)
        if filtro.processo is not None:
            expression = expression.filter(
                expression.numero.isin(cnj_storage_variants(filtro.processo))
            )
        return expression

    resultado = await materializar_colecao(
        metabase, artifacts, selecao, TarefaResumo, limite=limite
    )
    return TarefaListagem(dados=resultado.dados)


async def _obter(metabase: Metabase, tarefa_id: TarefaId) -> TarefaResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return TarefaResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )

    # `probe()` disponível não garante a consulta: a boundary pode falhar depois
    # dele. Esse resultado é um handle de reobservação (`pink://tarefa/{id}`),
    # então a falha chega como Indisponivel, não como erro -- e ausência
    # observada continua sendo ausência.
    try:
        main_rows = await metabase.rows(tarefa_detail(tarefa_id))
        if not main_rows:
            return TarefaResultado(
                dados=Ausente(
                    fonte=Fonte.METABASE,
                    motivo=f"tarefa {tarefa_id} não encontrada entre as tarefas ativas",
                )
            )
        tarefa = TarefaDados.model_validate(main_rows[0])
        comment_rows = await metabase.rows(comentarios_for_tarefa(tarefa_id))
        history_rows = await metabase.rows(historicos_for_tarefa(tarefa_id))
        label_rows = await metabase.rows(etiquetas_for_tarefa(tarefa_id))
    except RemoteObservationFailure as exc:
        return TarefaResultado(dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
    detalhe = TarefaDetalhe(
        tarefa=tarefa,
        comentarios=TypeAdapter(list[TarefaComentario]).validate_python(comment_rows),
        historico=TypeAdapter(list[TarefaHistorico]).validate_python(history_rows),
        etiquetas=TypeAdapter(list[TarefaEtiqueta]).validate_python(label_rows),
    )
    return TarefaResultado(dados=Observado(valor=detalhe))


def build_tarefa_catalogo(runtime: Runtime) -> Catalogo:
    """Build task reads over the runtime's Metabase and artifact boundaries."""
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="tarefa_listar",
        tags={"tarefa", "read", "parquet"},
        efeito=READ,
    )
    async def tarefa_listar(
        limite: Limite,
        filtro: Annotated[
            TarefaFiltro,
            Field(
                description="Filtros combináveis da listagem; omita para usar os defaults do filtro"
            ),
        ] = TarefaFiltro(),
    ) -> TarefaListagem:
        """Materializa uma seleção de tarefas limitada por `limite`, dentro dos filtros."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        return await _listar(metabase, artifacts, filtro, limite=limite)

    @catalogo.operacao(
        nome="tarefa_obter",
        tags={"tarefa", "read"},
        efeito=READ,
    )
    async def tarefa_obter(
        tarefa_id: TarefaId,
    ) -> TarefaResultado:
        """Obtém uma tarefa e seu contexto; ausência observada é um estado explícito."""
        metabase = get_metabase()
        return await _obter(metabase, tarefa_id)

    return catalogo
