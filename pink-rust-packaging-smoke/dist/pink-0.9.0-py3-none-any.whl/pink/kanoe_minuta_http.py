"""Kanoê minuta creation for the Pink 0.8 domain boundary."""

from __future__ import annotations

from typing import Any

from pink.kanoe_documento_http import KanoeDocumentoHttp
from pink.write_safety import RemoteWriteFailure


class KanoeMinutaHttp(KanoeDocumentoHttp):
    """Kanoê adapter including the domain write that creates a linked minuta."""

    async def create_minuta(self, *, modelo_id: int, pasta_id: int, tarefa_id: int) -> str:
        payload = await self._write_json(
            "POST",
            f"/api/modelos/{modelo_id}/minutar",
            params={"pastaId": pasta_id, "tarefaId": tarefa_id},
        )
        google_doc_id = _find_google_doc_id(payload)
        if google_doc_id is None:
            raise RemoteWriteFailure(
                "Kanoê aceitou a criação, mas a identidade googleDocId não pôde ser observada",
                effect_may_have_occurred=True,
            )
        return google_doc_id


def _find_google_doc_id(value: Any) -> str | None:
    """Extract the material Google identity while tolerating transport envelopes."""
    if isinstance(value, dict):
        direct = value.get("googleDocId")
        if isinstance(direct, str) and direct.strip():
            return direct.strip()
        for nested in value.values():
            found = _find_google_doc_id(nested)
            if found is not None:
                return found
    elif isinstance(value, list):
        for nested in value:
            found = _find_google_doc_id(nested)
            if found is not None:
                return found
    return None
