"""Pink minuta operations and readable resources."""

from __future__ import annotations

from dataclasses import replace
from typing import Annotated, cast

from pydantic import Field

from pink.catalogo import Catalogo, Conteudo, Efeito
from pink.domain_types import GoogleDocId, ModeloMinutaId, PastaId, RevisionId, TarefaId
from pink.google_docs import GoogleDocs
from pink.minuta_core import (
    EfeitoEscritaMinuta,
    EfeitoSubstituicaoMinuta,
    MinutaAlterada as MinutaAlterada,
    MinutaCriacaoAmbigua as MinutaCriacaoAmbigua,
    MinutaCriacaoRecusada as MinutaCriacaoRecusada,
    MinutaCriada as MinutaCriada,
    MinutaDetalhe as MinutaDetalhe,
    MinutaEdicaoAmbigua as MinutaEdicaoAmbigua,
    MinutaEdicaoRecusada as MinutaEdicaoRecusada,
    MinutaKanoe,
    MinutaResultado,
    MinutaSemAlteracao as MinutaSemAlteracao,
    ResultadoCriacaoMinuta,
    _dispatch as _dispatch,
    criar_minuta,
    escrever_minuta,
    substituir_texto,
)
from pink.minuta_observation import obter_minuta
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)
WRITE = Efeito(leitura=False, destrutivo=False, idempotente=False, mundo_aberto=True)
DESTRUCTIVE = replace(WRITE, destrutivo=True)


async def _obter(google: GoogleDocs, google_doc_id: GoogleDocId) -> MinutaResultado:
    """Compatibility seam used by the minuta state Resource."""
    return await obter_minuta(google, google_doc_id)


def build_minuta_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_google() -> GoogleDocs:
        return cast(GoogleDocs, runtime.google)

    def get_kanoe() -> MinutaKanoe:
        return cast(MinutaKanoe, runtime.kanoe)

    @catalogo.operacao(
        nome="minuta_obter",
        tags={"minuta", "read", "google"},
        efeito=READ,
    )
    async def minuta_obter(
        google_doc_id: GoogleDocId,
    ) -> MinutaResultado:
        """Observa identidade/revisão e anuncia Markdown/PDF como URIs de recurso."""
        google = get_google()
        return await obter_minuta(google, google_doc_id)

    @catalogo.operacao(
        nome="minuta_criar",
        tags={"minuta", "write", "kanoe"},
        efeito=WRITE,
    )
    async def minuta_criar(
        modelo_id: ModeloMinutaId,
        pasta_id: PastaId,
        tarefa_id: TarefaId,
    ) -> ResultadoCriacaoMinuta:
        """Cria a minuta vinculada no Kanoê; não cria documento Google paralelo."""
        kanoe = get_kanoe()
        google = get_google()
        return await criar_minuta(
            kanoe,
            google,
            modelo_id=modelo_id,
            pasta_id=pasta_id,
            tarefa_id=tarefa_id,
        )

    @catalogo.operacao(
        nome="minuta_substituir_texto",
        tags={"minuta", "write", "destructive", "google"},
        efeito=DESTRUCTIVE,
    )
    async def minuta_substituir_texto(
        google_doc_id: GoogleDocId,
        revisao_base: RevisionId,
        buscar: Annotated[str, Field(min_length=1, description="Texto literal a substituir")],
        substituir: Annotated[
            str,
            Field(description="Novo texto literal; string vazia remove cada ocorrência encontrada"),
        ],
        diferenciar_maiusculas: Annotated[
            bool,
            Field(description="Quando true, diferencia maiúsculas/minúsculas na busca literal"),
        ] = True,
    ) -> EfeitoSubstituicaoMinuta:
        """Substitui todas as ocorrências literais sobre a revisão explicitamente observada."""
        google = get_google()
        return await substituir_texto(
            google,
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            buscar=buscar,
            substituir=substituir,
            diferenciar_maiusculas=diferenciar_maiusculas,
        )

    @catalogo.operacao(
        nome="minuta_escrever",
        tags={"minuta", "write", "destructive", "google"},
        efeito=DESTRUCTIVE,
    )
    async def minuta_escrever(
        google_doc_id: GoogleDocId,
        revisao_base: RevisionId,
        markdown: Annotated[
            str,
            Field(
                min_length=1,
                description="Conteúdo integral em CommonMark; HTML cru é recusado",
            ),
        ],
        stylesheet: Annotated[
            str | None,
            Field(
                description=(
                    "CSS opcional em texto para p/h1-h6/li/blockquote/pre. "
                    "Suporta font-family, font-size em pt, font-weight, font-style, text-align, "
                    "margin-top/bottom/left e text-indent; CSS fora desse dialeto é recusado. "
                    "Não é path e não substitui frontmatter semântico."
                )
            ),
        ] = None,
    ) -> EfeitoEscritaMinuta:
        """Substitui integralmente a minuta por Markdown, com revisão obrigatória e CSS opcional."""
        google = get_google()
        return await escrever_minuta(
            google,
            google_doc_id=google_doc_id,
            revisao_base=revisao_base,
            markdown=markdown,
            stylesheet=stylesheet,
        )

    return catalogo


def build_minuta_resource_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()
    google = cast(GoogleDocs, runtime.google)

    @catalogo.recurso(
        "pink://minuta/{google_doc_id}/markdown",
        mime="text/markdown",
        tags={"minuta", "read", "google", "markdown"},
    )
    async def markdown(google_doc_id: str) -> Conteudo:
        conteudo = await google.export(google_doc_id, "text/markdown")
        return Conteudo(conteudo, mime="text/markdown")

    @catalogo.recurso(
        "pink://minuta/{google_doc_id}/pdf",
        mime="application/pdf",
        tags={"minuta", "read", "google", "pdf"},
    )
    async def pdf(google_doc_id: str) -> Conteudo:
        conteudo = await google.export(google_doc_id, "application/pdf")
        return Conteudo(conteudo, mime="application/pdf")

    return catalogo
