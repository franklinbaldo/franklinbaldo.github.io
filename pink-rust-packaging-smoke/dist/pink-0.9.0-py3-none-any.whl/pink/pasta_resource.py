"""Pasta-scoped binary resources over a narrow Kanoê read boundary."""

from __future__ import annotations

from typing import Protocol, cast

from pydantic import TypeAdapter

from pink.catalogo import Catalogo, Conteudo
from pink.domain_types import PastaId
from pink.integrations import Probe
from pink.models import Disponibilidade
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure


class PastaPdfKanoe(Probe, Protocol):
    """Only the Kanoê behavior required to materialize a pasta's full process PDF."""

    async def pasta_pdf(self, pasta_id: int) -> bytes: ...


async def _require_available(kanoe: PastaPdfKanoe) -> None:
    status = await kanoe.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        raise RemoteObservationFailure(status.detalhe or "Kanoê indisponível")


def build_pasta_resource_catalogo(runtime: Runtime) -> Catalogo:
    """Expose the full judicial-process PDF for one concrete Kanoê pasta."""
    catalogo = Catalogo()
    kanoe = cast(PastaPdfKanoe, runtime.kanoe)

    @catalogo.recurso(
        "pink://pasta/{pasta_id}/pdf",
        mime="application/pdf",
        tags={"pasta", "processo", "read", "binary", "pdf"},
    )
    async def pasta_pdf(pasta_id: str) -> Conteudo:
        """Read the complete process PDF represented by one specific Kanoê pasta."""
        parsed_id = TypeAdapter(PastaId).validate_python(pasta_id)
        await _require_available(kanoe)
        conteudo = await kanoe.pasta_pdf(parsed_id)
        return Conteudo(conteudo, mime="application/pdf")

    return catalogo
