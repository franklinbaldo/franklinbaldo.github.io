"""Physical Ibis queries for queue and reference collections."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date

from ibis.expr import types as ir

from pink import schema
from pink.models import StatusTramitacao


def tramitacoes_pendentes(
    *,
    setor_ids: Sequence[int] | ir.IntegerColumn,
    origem: str | None = None,
    prazo_ate: date | None = None,
):
    """Pending transfers addressed to one explicit destination sector."""
    view = schema.vw_processos_nao_recebidos
    p = schema.pastas
    q = (
        # Id literal do destino (`pink.setores`) e `IN` no status: a view é
        # mesclada pelo MySQL, que passa a dirigir por `tramitacoes.setores_destino_id`
        # em vez de varrer `pastas` inteira -- 2,8 s -> 0,9 s, medido.
        view.filter(
            view.setorDestinoId.isin(setor_ids)
            & view.statusTramitacao.isin([StatusTramitacao.PENDENTE])
        )
        .left_join(p, view.pastas_id == p.id)
        .select(
            tramitacao_id=view.ultima_tramitacao_id,
            pasta_id=view.pastas_id,
            numero=view.numero_processo_judicial,
            setor_origem=view.setor_origem_sigla,
            setor_destino=view.setor_destino_sigla,
            prazo=view.prazo_expediente.cast("date"),
            classe=view.classe_nacional,
            valor_causa=view.valor_causa,
            criado_em=view.criado_em,
            pasta_da_autarquia=p.pasta_da_autarquia.cast("boolean"),
        )
    )
    if origem is not None:
        q = q.filter(q.setor_origem == origem)
    if prazo_ate is not None:
        q = q.filter(q.prazo.notnull() & (q.prazo <= prazo_ate))
    return q.order_by(q.criado_em.desc(), q.tramitacao_id)


def caixas_listar(*, setor: str, incluir_inativas: bool = False, termo: str | None = None):
    c = schema.caixas
    s = schema.setores
    q = (
        c.filter(c.apagado_em.isnull())
        .inner_join(s, [c.setores_id == s.id, s.sigla == setor])
        .select(
            caixa_id=c.id, nome=c.nome, sigla=c.sigla, ativa=c.ativo.cast("boolean"), setor=s.sigla
        )
    )
    if not incluir_inativas:
        q = q.filter(q.ativa)
    if termo:
        q = q.filter(q.nome.lower().contains(termo.lower()))
    return q.order_by(q.nome, q.caixa_id)


def correntes_listar(*, termo: str | None = None, setor: str | None = None):
    c = schema.corrente_tematica
    s = schema.setores
    q = (
        c.filter(c.apagado_em.isnull() & (c.ativo == 1))
        .left_join(s, c.setores_id == s.id)
        .select(
            corrente_id=c.id,
            nome=c.nome,
            descricao=c.descricao,
            setor=s.sigla,
        )
    )
    if setor is not None:
        q = q.filter(q.setor == setor)
    if termo:
        q = q.filter(q.nome.lower().contains(termo.lower()))
    return q.order_by(q.nome, q.corrente_id)


def etiquetas_listar(*, setor: str, termo: str | None = None):
    te = schema.tarefas_etiquetas
    e = schema.etiquetas
    t = schema.tarefas
    p = schema.pastas
    s = schema.setores

    ids = (
        te.filter(te.apagado_em.isnull())
        .inner_join(t, [te.tarefas_id == t.id, t.apagado_em.isnull()])
        .inner_join(p, [t.pastas_id == p.id, p.apagado_em.isnull()])
        .inner_join(s, [p.setores_id == s.id, s.sigla == setor])
        .select(etiqueta_id=te.etiquetas_id)
    )
    q = (
        e.filter(e.apagado_em.isnull())
        .semi_join(ids, e.id == ids.etiqueta_id)
        .select(etiqueta_id=e.id, nome=e.nome)
    )
    if termo:
        q = q.filter(q.nome.lower().contains(termo.lower()))
    return q.order_by(q.nome, q.etiqueta_id)


def especies_listar(*, termo: str | None = None):
    e = schema.especies_tarefas
    q = e.filter(e.ativo == 1).select(
        especie_id=e.id,
        nome=e.nome,
        descricao=e.descricao,
    )
    if termo:
        q = q.filter(q.nome.lower().contains(termo.lower()))
    return q.order_by(q.nome, q.especie_id)


def funcionalidades_permitidas(*, usuario_id: int, setor: str):
    """As funcionalidades que a lotação do usuário nesse setor concede, por perfil."""
    u = schema.usuarios
    lot = schema.lotacoes
    s = schema.setores
    lp = schema.lotacao_perfil
    pf = schema.perfil_funcionalidade
    return (
        u.filter(u.id == usuario_id)
        .inner_join(lot, [lot.colaboradores_id == u.colaboradores_id, lot.apagado_em.isnull()])
        .inner_join(s, [lot.setores_id == s.id, s.sigla == setor])
        .inner_join(lp, [lp.lotacao_id == lot.id, lp.apagado_em.isnull()])
        .inner_join(pf, [pf.perfil_id == lp.perfil_id, pf.apagado_em.isnull()])
        .select(funcionalidade_id=pf.funcionalidade_id)
        .distinct()
    )


def funcionalidades_listar(
    *,
    usuario_id: int,
    setor: str,
    termo: str | None = None,
    metodo: str | None = None,
    somente_permitidas: bool = True,
):
    """O catálogo de rotas do Kanoê (método, URL, funcionalidade) e se o usuário pode cada uma.

    `permitida` é o veredito do próprio modelo de permissão do Kanoê para a
    lotação do usuário no setor: é o que `PermissionsVerifier` responde com 403
    antes do roteamento. A URL vem como a fonte a escreve, com `?` no lugar de um
    segmento de caminho.
    """
    fu = schema.funcionalidade_url
    f = schema.funcionalidade
    permitidas = funcionalidades_permitidas(usuario_id=usuario_id, setor=setor)
    base = (
        fu.inner_join(f, [fu.funcionalidade_id == f.id, f.apagado_em.isnull()])
        .left_join(permitidas, fu.funcionalidade_id == permitidas.funcionalidade_id)
        .select(
            metodo=fu.metodo,
            url=fu.url,
            sigla=f.sigla,
            descricao=f.descricao,
            permitida=permitidas.funcionalidade_id.notnull(),
        )
    )
    if somente_permitidas:
        base = base.filter(base.permitida)
    if metodo:
        base = base.filter(base.metodo == metodo.upper())
    if termo:
        t = termo.lower()
        base = base.filter(
            base.url.lower().contains(t)
            | base.sigla.lower().contains(t)
            | base.descricao.lower().contains(t)
        )
    return base.distinct().order_by(base.url, base.metodo, base.sigla)
