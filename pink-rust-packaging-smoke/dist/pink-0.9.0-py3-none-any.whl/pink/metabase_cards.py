"""Saved-Card fallback for stable Pink Ibis query shapes.

The registry lives entirely at the Metabase boundary. Provisioning compiles a
representative Ibis expression with unique sentinels and turns only those
literals into Metabase template tags. Runtime compares the SQL produced by the
real Ibis expression against that exact template and extracts the parameters.
If the static SQL differs, the Card does not match. Domain tools therefore keep
the plain ``Metabase.rows(expression)`` contract: no Card id, hash, MBQL or
transport hint leaks into a query builder or capability.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from copy import deepcopy
from functools import cache
from hashlib import sha256
import json
import re
from typing import Any, Literal

import ibis
from ibis.expr import types as ir

from pink.queries import (
    comentarios_for_tarefa,
    etiquetas_for_tarefa,
    historicos_for_tarefa,
    tarefa_detail,
    tarefas_filter,
)
from pink.queries_case import (
    comentarios_for_expediente,
    componente_mimetype,
    componentes_for_documento,
    documento_detail,
    documentos_filter,
    expediente_detail,
    expedientes_filter,
    tarefas_abertas_for_expediente,
)
from pink.queries_context import (
    correntes_for_pasta,
    pasta_autarquia,
    pasta_detail,
    pasta_resumo_latest,
)
from pink.queries_peticionamento import documento_existe, peticionamentos_for_documento
from pink.queries_setoriais import (
    pastas_setor,
    caixas_setor,
    expedientes_abertos_setor,
    tramitacoes_setor,
)
from pink.setores import setores_ativos, setores_por_sigla

CardKind = Literal["number", "text"]


@dataclass(frozen=True, slots=True)
class CardParameter:
    name: str
    kind: CardKind


@dataclass(frozen=True, slots=True)
class CardSpec:
    """One stable logical Ibis shape that can be provisioned as a saved Card."""

    name: str
    build: Callable[..., ir.Table]
    parameters: tuple[CardParameter, ...]

    def template(self) -> tuple[str, dict[str, dict[str, str]]]:
        """Return an isolated copy of the cached, compiled template."""
        sql, tags = self._template()
        return sql, deepcopy(tags)

    @cache
    def _template(self) -> tuple[str, dict[str, dict[str, str]]]:
        """Compile with unique sentinels and replace only those literals with tags."""
        values: dict[str, Any] = {}
        needles: dict[str, str] = {}
        for index, parameter in enumerate(self.parameters):
            if parameter.kind == "number":
                sentinel: Any = 982_451_653 + index
                needle = str(sentinel)
            else:
                sentinel = f"__PINK_CARD_{self.name.upper()}_{parameter.name.upper()}_{index}__"
                needle = f"'{sentinel}'"
            values[parameter.name] = sentinel
            needles[parameter.name] = needle

        sql = ibis.to_sql(self.build(**values), dialect="mysql")
        tags: dict[str, dict[str, str]] = {}
        for parameter in self.parameters:
            needle = needles[parameter.name]
            if needle not in sql:
                raise ValueError(
                    f"{self.name}: parâmetro {parameter.name!r} não apareceu como literal estável no SQL"
                )
            sql = sql.replace(needle, f"{{{{{parameter.name}}}}}")
            tags[parameter.name] = {
                "id": f"pink-{self.name}-{parameter.name}",
                "name": parameter.name,
                "display-name": parameter.name,
                "type": parameter.kind,
            }
        return sql, tags

    @cache
    def digest(self) -> str:
        sql, tags = self.template()
        payload = json.dumps(
            {"sql": sql, "template_tags": tags}, sort_keys=True, ensure_ascii=False
        )
        return sha256(payload.encode()).hexdigest()[:12]


@dataclass(frozen=True, slots=True)
class CardInvocation:
    name: str
    digest: str
    params: Mapping[str, Any]


def _one_int(name: str, build: Callable[..., ir.Table], parameter: str) -> CardSpec:
    return CardSpec(name, build, (CardParameter(parameter, "number"),))


CARD_SPECS: dict[str, CardSpec] = {
    spec.name: spec
    for spec in (
        CardSpec("setores_por_sigla", setores_por_sigla, (CardParameter("sigla", "text"),)),
        CardSpec(
            "setores_ativos",
            lambda sigla, limite: setores_ativos(sigla).limit(limite),
            (CardParameter("sigla", "text"), CardParameter("limite", "number")),
        ),
        *(
            CardSpec(
                name,
                lambda setor, limite, build=build: build(setor).limit(limite),
                (CardParameter("setor", "text"), CardParameter("limite", "number")),
            )
            for name, build in (
                ("pastas_setor", pastas_setor),
                ("caixas_setor", caixas_setor),
                ("expedientes_abertos_setor", expedientes_abertos_setor),
                ("tramitacoes_setor", tramitacoes_setor),
            )
        ),
        _one_int("pasta_detail", pasta_detail, "pasta_id"),
        _one_int("pasta_autarquia", pasta_autarquia, "pasta_id"),
        _one_int("pasta_resumo_latest", pasta_resumo_latest, "pasta_id"),
        _one_int("correntes_for_pasta", correntes_for_pasta, "pasta_id"),
        _one_int(
            "expedientes_for_pasta",
            lambda pasta_id: expedientes_filter(pasta_id=pasta_id),
            "pasta_id",
        ),
        _one_int(
            "tarefas_for_pasta",
            lambda pasta_id: tarefas_filter(pasta_id=pasta_id, aberta=None),
            "pasta_id",
        ),
        _one_int(
            "documentos_for_pasta",
            lambda pasta_id: documentos_filter(pasta_id=pasta_id),
            "pasta_id",
        ),
        _one_int("tarefa_detail", tarefa_detail, "tarefa_id"),
        _one_int("comentarios_for_tarefa", comentarios_for_tarefa, "tarefa_id"),
        _one_int("historicos_for_tarefa", historicos_for_tarefa, "tarefa_id"),
        _one_int("etiquetas_for_tarefa", etiquetas_for_tarefa, "tarefa_id"),
        _one_int("expediente_detail", expediente_detail, "expediente_id"),
        _one_int("comentarios_for_expediente", comentarios_for_expediente, "expediente_id"),
        _one_int(
            "tarefas_abertas_for_expediente",
            tarefas_abertas_for_expediente,
            "expediente_id",
        ),
        _one_int("documento_detail", documento_detail, "documento_id"),
        _one_int("componentes_for_documento", componentes_for_documento, "documento_id"),
        _one_int("componente_mimetype", componente_mimetype, "componente_id"),
        _one_int("documento_existe", documento_existe, "documento_id"),
        _one_int(
            "peticionamentos_for_documento",
            peticionamentos_for_documento,
            "documento_id",
        ),
    )
}


@cache
def _pattern(spec: CardSpec) -> re.Pattern[str]:
    template, _ = spec.template()
    pattern = re.escape(_espacos_sql(template))
    for parameter in spec.parameters:
        marker = re.escape(f"{{{{{parameter.name}}}}}")
        if parameter.kind == "number":
            capture = rf"(?P<{parameter.name}>-?\d+(?:\.\d+)?)"
        else:
            capture = rf"(?P<{parameter.name}>'(?:''|[^'])*')"
        occurrences = pattern.count(marker)
        if occurrences == 0:
            raise ValueError(
                f"{spec.name}: template perdeu o parâmetro {parameter.name!r} antes do matching"
            )
        pattern = pattern.replace(marker, capture, 1)
        if occurrences > 1:
            pattern = pattern.replace(marker, rf"(?P={parameter.name})")
    return re.compile(rf"^{pattern}$", re.DOTALL)


def _value(parameter: CardParameter, raw: str) -> Any:
    if parameter.kind == "number":
        return float(raw) if "." in raw else int(raw)
    return raw[1:-1].replace("''", "'")


def _espacos_sql(sql: str) -> str:
    """Ignore pretty-printer wrapping, preserving quoted values and identifiers."""
    parts = re.split(r"('(?:\\.|''|[^'\\])*'|`(?:``|[^`])*`|\"(?:\\.|\"\"|[^\"\\])*\")", sql)
    return "".join(
        re.sub(r"\s+", " ", part) if i % 2 == 0 else part for i, part in enumerate(parts)
    ).strip()


def match_sql(compiled_sql: str) -> CardInvocation | None:
    """Return the one provisioned shape that exactly matches this Ibis SQL."""
    compiled_sql = _espacos_sql(compiled_sql)
    matches: list[CardInvocation] = []
    for spec in CARD_SPECS.values():
        match = _pattern(spec).fullmatch(compiled_sql)
        if match is None:
            continue
        params = {
            parameter.name: _value(parameter, match.group(parameter.name))
            for parameter in spec.parameters
        }
        matches.append(CardInvocation(spec.name, spec.digest(), params))
    if len(matches) > 1:
        names = ", ".join(match.name for match in matches)
        raise ValueError(f"SQL Ibis casou com mais de um contrato de Card: {names}")
    return matches[0] if matches else None


def provisioned_card_name(spec: CardSpec) -> str:
    return f"[pink08] {spec.name} ({spec.digest()})"
