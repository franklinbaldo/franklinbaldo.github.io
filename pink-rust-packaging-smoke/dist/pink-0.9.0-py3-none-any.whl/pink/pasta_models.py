"""Typed sector relationships of a physical pasta."""

from typing import Any, Literal

from pydantic import Field, model_validator

from pink.domain_types import PastaId
from pink.models import Observacao, PinkModel
from pink.setores import Setor


class PastaResponsabilidade(PinkModel):
    pasta_id: PastaId
    setor_responsavel_etiqueta: Setor | None = Field(
        description="Setor responsável pela pasta segundo a etiqueta; seu CNPJ identifica a autarquia responsável, mesmo se inválido"
    )

    @model_validator(mode="before")
    @classmethod
    def expandir_setor(cls, value: Any) -> Any:
        """Map the flat relational projection to the same sector object the API carries."""
        fields = {
            "id": "setor_responsavel_etiqueta_id",
            "sigla": "setor_responsavel_etiqueta_sigla",
            "nome": "setor_responsavel_etiqueta_nome",
            "cnpj": "setor_responsavel_etiqueta_cnpj",
        }
        if not isinstance(value, dict) or not all(key in value for key in fields.values()):
            return value
        result = dict(value)
        setor = {name: result.pop(key) for name, key in fields.items()}
        result["setor_responsavel_etiqueta"] = setor if setor["id"] is not None else None
        return result


class SetorResponsavelResultado(PinkModel):
    dados: Observacao[PastaResponsabilidade] = Field(
        description="Relação da pasta com seu setor responsável, observada na fonte escolhida"
    )


FonteSetor = Literal["kanoe", "metabase"]
