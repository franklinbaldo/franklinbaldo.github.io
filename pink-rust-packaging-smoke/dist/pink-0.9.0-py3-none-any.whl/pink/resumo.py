"""Summaries the Kanoê keeps for a pasta or for a componente digital, read from its own API.

The Metabase mirror carries the pasta summary (`pasta_obter` shows it), but a
user without a Metabase account still has the Kanoê session. This capability
reads the summary where the Kanoê serves it -- `GET /api/pasta-resumo/{id}/pasta`
and `GET /api/componente-digital-resumo/{id}/documento-digital`, measured live
on 2026-09-10 -- so the same knowledge is reachable through either source.
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.domain_types import ComponenteDigitalId, PastaId
from pink.integrations import Kanoe, ResumoRemoto
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class AlvoPasta(PinkModel):
    """O resumo geral e estratégico que o Kanoê mantém para uma pasta."""

    tipo: Literal["pasta"]
    pasta_id: PastaId


class AlvoComponente(PinkModel):
    """O resumo que o Kanoê mantém para um componente digital (o arquivo de um documento)."""

    tipo: Literal["componente"]
    componente_id: ComponenteDigitalId


AlvoResumo = Annotated[AlvoPasta | AlvoComponente, Field(discriminator="tipo")]


class Resumo(PinkModel):
    alvo: str = Field(description="O que foi resumido: `pasta <id>` ou `componente <id>`")
    resumo_id: int = Field(gt=0, description="ID físico da versão do resumo no Kanoê")
    resumo: str = Field(description="Texto do resumo como o Kanoê o guarda (HTML)")
    versao: int = Field(ge=0, description="Versão do resumo")
    avaliacao_media: float | None = Field(
        default=None, description="Média das avaliações (estrelas) recebidas pelo resumo"
    )
    avaliacoes: int = Field(ge=0, description="Quantidade de avaliações recebidas")
    criado_em: datetime | None = Field(default=None, description="Quando esta versão foi criada")
    atualizado_em: datetime | None = Field(
        default=None, description="Quando esta versão foi atualizada"
    )
    autor: str | None = Field(default=None, description="Nome de quem criou a versão")
    tipo_documento: str | None = Field(
        default=None, description="Tipo do documento, quando o alvo é um componente digital"
    )


class ResumoResultado(PinkModel):
    """Object-root envelope of one summary observation."""

    dados: Observacao[Resumo] = Field(
        description="Resumo observado, ausente (o Kanoê não tem resumo para o alvo) ou indisponível"
    )


def _resumo(alvo: str, remoto: ResumoRemoto) -> Resumo:
    return Resumo(
        alvo=alvo,
        resumo_id=remoto.resumo_id,
        resumo=remoto.resumo,
        versao=remoto.versao,
        avaliacao_media=remoto.avaliacao_media,
        avaliacoes=remoto.avaliacoes,
        criado_em=remoto.criado_em,
        atualizado_em=remoto.atualizado_em,
        autor=remoto.autor,
        tipo_documento=remoto.tipo_documento,
    )


def build_resumo_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_kanoe() -> Kanoe:
        return runtime.kanoe

    @catalogo.operacao(
        nome="resumo_obter",
        tags={"resumo", "pasta", "documento", "read"},
        efeito=READ,
    )
    async def resumo_obter(
        alvo: Annotated[
            AlvoResumo,
            Field(description="O que ler: o resumo de uma pasta ou o de um componente digital"),
        ],
    ) -> ResumoResultado:
        """Lê o resumo que o Kanoê mantém para uma pasta ou um componente digital, pela própria API.

        Não depende do Metabase: serve quem só tem a sessão do Kanoê. Ausência
        de resumo é um estado observado, não erro.
        """
        kanoe = get_kanoe()
        status = await kanoe.probe()
        if status.estado is Disponibilidade.INDISPONIVEL:
            return ResumoResultado(
                dados=Indisponivel(fonte=Fonte.KANOE, motivo=status.detalhe or "Kanoê indisponível")
            )
        if isinstance(alvo, AlvoPasta):
            rotulo, leitura = f"pasta {alvo.pasta_id}", kanoe.pasta_resumo(alvo.pasta_id)
        else:
            rotulo = f"componente {alvo.componente_id}"
            leitura = kanoe.componente_resumo(alvo.componente_id)
        try:
            remoto = await leitura
        except RemoteObservationFailure as exc:
            return ResumoResultado(dados=Indisponivel(fonte=Fonte.KANOE, motivo=str(exc)))
        if remoto is None:
            return ResumoResultado(
                dados=Ausente(fonte=Fonte.KANOE, motivo=f"{rotulo} sem resumo registrado no Kanoê")
            )
        return ResumoResultado(dados=Observado(valor=_resumo(rotulo, remoto)))

    return catalogo
