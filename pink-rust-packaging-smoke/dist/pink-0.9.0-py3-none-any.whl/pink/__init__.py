"""Pink 0.8: domínio e boundaries do Kanoê, Metabase e Google sobre Pydantic, Cyclopts e Ibis."""

import os
import sys

# No Windows corporativo, o registro frequentemente contém proxies socks4/socks que quebram o httpx.
if sys.platform == "win32" and "NO_PROXY" not in os.environ:
    os.environ["NO_PROXY"] = "*"

__all__: list[str] = []
__version__ = "0.9.0"
