"""The Pink catalog: named operations and `pink://`/`kanoe://` readable resources.

A `Catalogo` is a plain registry of Python callables. The published callable
is authoritative for its own signature and return type: Pydantic validates the
arguments on every call, and the CLI derives one Cyclopts command per
operation from that same signature. There is no transport, schema dialect or
second declaration of the contract.

This registry is transitional scaffolding for the Python implementation, not a
target abstraction: RFC 0058 (docs/rfcs/0058-rust-cli-only.md) calls use cases directly from commands,
and a port does not reproduce it one to one.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
import inspect
import re
from typing import Any

from pydantic import TypeAdapter, ValidationError, validate_call


@dataclass(frozen=True, slots=True)
class Efeito:
    """What calling an operation does to the world, declared next to the operation."""

    leitura: bool = False
    destrutivo: bool = False
    idempotente: bool = False
    mundo_aberto: bool = True


LEITURA = Efeito(leitura=True, idempotente=True)


class SaidaForaDoContrato(TypeError):
    """An operation returned a value its own return annotation does not admit.

    A `TypeError`, not a `ValueError`: this is a bug in the operation, never an
    operational failure, so the CLI keeps its traceback.
    """


@dataclass(frozen=True, slots=True)
class Operacao:
    """One callable capability: its name, the function and the declared effect."""

    nome: str
    fn: Callable[..., Any]
    tags: frozenset[str]
    efeito: Efeito
    descricao: str
    _entrada: Callable[..., Any] = field(init=False, repr=False, compare=False)
    _saida: TypeAdapter[Any] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_entrada", validate_call(self.fn))
        object.__setattr__(self, "_saida", TypeAdapter(self.saida))

    @property
    def saida(self) -> Any:
        """The declared return type, the only output contract."""
        return inspect.signature(self.fn, eval_str=True).return_annotation

    async def chamar(self, argumentos: Mapping[str, Any]) -> Any:
        """Validate `argumentos` against the signature, run, then validate the result.

        Both ends are enforced: ill-typed arguments raise `ValidationError`, and
        a result the return annotation does not admit raises `SaidaForaDoContrato`.
        """
        resultado = self._entrada(**argumentos)
        if inspect.isawaitable(resultado):
            resultado = await resultado
        try:
            return self._saida.validate_python(resultado)
        except ValidationError as exc:
            raise SaidaForaDoContrato(
                f"{self.nome} devolveu {type(resultado).__name__} fora do contrato "
                f"{self.saida!r}: {exc}"
            ) from exc


@dataclass(frozen=True, slots=True)
class Conteudo:
    """Bytes or text read from a resource, with its media type."""

    dados: bytes | str
    mime: str


@dataclass(frozen=True, slots=True)
class Recurso:
    """A URI template (`pink://pasta/{pasta_id}/pdf`) resolved by one reader."""

    modelo: str
    fn: Callable[..., Awaitable[Conteudo] | Conteudo]
    mime: str
    tags: frozenset[str]
    descricao: str
    padrao: re.Pattern[str] = field(init=False)

    def __post_init__(self) -> None:
        partes = re.split(r"\{(\w+)\}", self.modelo)
        regex = "".join(
            f"(?P<{parte}>[^/]+)" if indice % 2 else re.escape(parte)
            for indice, parte in enumerate(partes)
        )
        object.__setattr__(self, "padrao", re.compile(f"^{regex}$"))


class Catalogo:
    """Operations and resources registered by the domain modules."""

    def __init__(self) -> None:
        self.operacoes: dict[str, Operacao] = {}
        self.recursos: dict[str, Recurso] = {}

    def operacao(
        self,
        *,
        nome: str,
        tags: set[str] | frozenset[str],
        efeito: Efeito,
        descricao: str | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register the decorated function as the operation `nome`."""

        def registrar(fn: Callable[..., Any]) -> Callable[..., Any]:
            self._adicionar_operacao(
                Operacao(
                    nome=nome,
                    fn=fn,
                    tags=frozenset(tags),
                    efeito=efeito,
                    descricao=descricao or inspect.getdoc(fn) or "",
                )
            )
            return fn

        return registrar

    def recurso(
        self,
        modelo: str,
        *,
        mime: str,
        tags: set[str] | frozenset[str],
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register the decorated function as the reader of URIs matching `modelo`."""

        def registrar(fn: Callable[..., Any]) -> Callable[..., Any]:
            self._adicionar_recurso(
                Recurso(
                    modelo=modelo,
                    fn=fn,
                    mime=mime,
                    tags=frozenset(tags),
                    descricao=inspect.getdoc(fn) or "",
                )
            )
            return fn

        return registrar

    def incluir(self, *outros: Catalogo) -> Catalogo:
        """Merge other catalogs into this one; a repeated name is an error."""
        for outro in outros:
            for operacao in outro.operacoes.values():
                self._adicionar_operacao(operacao)
            for recurso in outro.recursos.values():
                self._adicionar_recurso(recurso)
        return self

    def _adicionar_operacao(self, operacao: Operacao) -> None:
        if operacao.nome in self.operacoes:
            raise ValueError(f"operação duplicada no catálogo: {operacao.nome}")
        self.operacoes[operacao.nome] = operacao

    def _adicionar_recurso(self, recurso: Recurso) -> None:
        if recurso.modelo in self.recursos:
            raise ValueError(f"recurso duplicado no catálogo: {recurso.modelo}")
        self.recursos[recurso.modelo] = recurso

    async def chamar(self, nome: str, argumentos: Mapping[str, Any] | None = None) -> Any:
        """Call the operation `nome` with validated arguments and return its typed result."""
        operacao = self.operacoes.get(nome)
        if operacao is None:
            raise KeyError(f"operação desconhecida: {nome}")
        return await operacao.chamar(argumentos or {})

    async def ler(self, uri: str) -> Conteudo:
        """Read the resource addressed by `uri`."""
        for recurso in self.recursos.values():
            casamento = recurso.padrao.match(uri)
            if casamento is None:
                continue
            lido = recurso.fn(**casamento.groupdict())
            return lido if isinstance(lido, Conteudo) else await lido
        raise ValueError(f"nenhum recurso do catálogo responde por {uri}")
