"""Credential persistence for the human-facing Pink CLI only."""

from __future__ import annotations

import keyring
import keyring.errors

from pink.settings import CAIPORA_KEYRING, GOOGLE_KEYRING, KANOE_KEYRING, METABASE_KEYRING

_KEYRING_ERRORS = (OSError, RuntimeError, ImportError, keyring.errors.KeyringError)


def _set_and_confirm(service: str, key: str, value: str) -> None:
    # Keyring fora do ar é configuração impossível, não estado de domínio.
    # A exceção do keyring nomeia o backend e a causa; trocá-la por um
    # RuntimeError genérico só apagaria isso.
    keyring.set_password(service, key, value)
    stored = keyring.get_password(service, key)
    if stored != value:
        raise RuntimeError(f"keyring não confirmou {service}/{key}")


def save_metabase(email: str, password: str) -> None:
    """Store one Metabase username/password pair and verify read-back."""
    if not email.strip() or not password:
        raise ValueError("email e senha do Metabase são obrigatórios")
    keyring.set_password(METABASE_KEYRING, email.strip(), password)
    stored = keyring.get_credential(METABASE_KEYRING, None)
    if stored is None or stored.username != email.strip() or stored.password != password:
        raise RuntimeError("keyring não confirmou as credenciais do Metabase")


def save_caipora(usuario: str, senha: str) -> None:
    """Store the Caipora SSO pair; with it the Kanoê token is obtained and renewed by Pink."""
    if not usuario.strip() or not senha:
        raise ValueError("usuário e senha da Caipora são obrigatórios")
    keyring.set_password(CAIPORA_KEYRING, usuario.strip(), senha)
    stored = keyring.get_credential(CAIPORA_KEYRING, None)
    if stored is None or stored.username != usuario.strip() or stored.password != senha:
        raise RuntimeError("keyring não confirmou as credenciais da Caipora")


def save_kanoe(authorization: str) -> None:
    """Store the explicit Kanoê Authorization value; identity stays non-secret config."""
    if not authorization.strip():
        raise ValueError("authorization Kanoê não pode ser vazio")
    _set_and_confirm(KANOE_KEYRING, "authorization", authorization.strip())


def save_google(authorization: str) -> None:
    """Store the explicit Google Authorization value."""
    if not authorization.strip():
        raise ValueError("authorization Google não pode ser vazio")
    _set_and_confirm(GOOGLE_KEYRING, "authorization", authorization.strip())
