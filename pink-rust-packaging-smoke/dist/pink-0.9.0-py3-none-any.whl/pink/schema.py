"""Unbound Ibis schemas for the physical Caipora/ratio tables Pink 0.8 reads.

This is integration knowledge, not a compatibility import from Pink 0.7.  Queries
built here compile to MySQL for Metabase and bind unchanged to DuckDB fixtures in
behavior tests.
"""

from __future__ import annotations

import ibis

pastas = ibis.table(
    name="pastas",
    schema={
        "id": "int64",
        "processos_judiciais_id": "int64",
        "setores_id": "int64",
        "setor_responsavel_etiqueta": "int64",
        "titulo": "string",
        "NUP": "string",
        "outroNumero": "string",
        "anotacao": "string",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
        "data_hora_abertura": "timestamp",
        "status_pasta": "string",
        "pasta_da_autarquia": "int8",
    },
)

setores = ibis.table(
    name="setores",
    schema={"id": "int64", "sigla": "string", "nome": "string", "ativo": "int8", "cnpj": "string"},
)

processos_jud = ibis.table(
    name="processos_jud",
    schema={
        "id": "int64",
        "numero": "string",
        "fonte_dados": "string",
        "competencia": "int64",
        "classes_nacional_id": "int64",
        "orgaos_julgadores_id": "int64",
        "valor_causa": "decimal(15, 2)",
        "data_hora_ajuizamento": "timestamp",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

classes_cnj = ibis.table(
    name="classes_cnj",
    schema={
        "id": "int64",
        "parent_id": "int64",
        "nome": "string",
        "sigla": "string",
        "codigo_nacional": "int64",
    },
)

expedientes = ibis.table(
    name="expedientes",
    schema={
        "id": "int64",
        "pastas_id": "int64",
        "documento_id": "int64",
        "tipo": "int64",
        "teor": "string",
        "prazo": "timestamp",
        "fechado": "int8",
        "fechado_manualmente": "int8",
        "criado_em": "timestamp",
        "criado_por": "int64",
    },
)

expedientes_comentario = ibis.table(
    name="expedientes_comentario",
    schema={
        "id": "int64",
        "expedientes_id": "int64",
        "comentario": "string",
        "criado_em": "timestamp",
        "criado_por": "int64",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

tarefas = ibis.table(
    name="tarefas",
    schema={
        "id": "int64",
        "pastas_id": "int64",
        "especies_tarefas_id": "int64",
        "status_tarefa_id": "int64",
        "setores_responsavel_id": "int64",
        "setores_origem_id": "int64",
        "usuarios_responsavel_id": "int64",
        "documentos_id": "int64",
        "expediente_id": "int64",
        "data_hora_inicio_prazo": "timestamp",
        "data_hora_final_prazo": "timestamp",
        "data_hora_conclusao_prazo": "timestamp",
        "urgente": "int8",
        "post_it": "string",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

especies_tarefas = ibis.table(
    name="especies_tarefas",
    schema={
        "id": "int64",
        "generos_tarefas_id": "int64",
        "nome": "string",
        "descricao": "string",
        "ativo": "int8",
    },
)

status_tarefa = ibis.table(
    name="status_tarefa",
    schema={"id": "int64", "descricao": "string", "ativo": "int8"},
)

comentarios_tarefa = ibis.table(
    name="comentarios_tarefa",
    schema={
        "id": "int64",
        "tarefa_id": "int64",
        "comentario": "string",
        "criado_em": "timestamp",
        "criado_por": "int64",
    },
)

historicos_tarefa = ibis.table(
    name="historicos_tarefa",
    schema={
        "id": "int64",
        "tarefa_id": "int64",
        "criado_em": "timestamp",
        "criado_por": "int64",
        "descricao": "string",
        "acao": "string",
        "comentario_tarefa_id": "int64",
    },
)

pasta_resumo = ibis.table(
    name="pasta_resumo",
    schema={
        "id": "int64",
        "pasta_id": "int64",
        "resumo": "string",
        "versao": "int64",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

documentos = ibis.table(
    name="documentos",
    schema={
        "id": "int64",
        "pastas_destinatario_id": "int64",
        "tipos_documentos_id": "int64",
        "setores_origem_id": "int64",
        "tarefas_origem_id": "int64",
        "data_hora_producao": "timestamp",
        "outroNumero": "string",
        "autor": "string",
        "redator": "string",
        "observacao": "string",
        "minuta": "int8",
        "criado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

tipos_documentos = ibis.table(
    name="tipos_documentos",
    schema={"id": "int64", "sigla": "string", "nome": "string", "ativo": "int8"},
)

componentes_digitais = ibis.table(
    name="componentes_digitais",
    schema={
        "id": "int64",
        "documentos_id": "int64",
        "google_doc_id": "string",
        "file_name": "string",
        "hash": "string",
        "tamanho": "int64",
        "mimetype": "string",
        "extensao": "string",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

caixas = ibis.table(
    name="caixas",
    schema={
        "id": "int64",
        "nome": "string",
        "sigla": "string",
        "ativo": "int8",
        "setores_id": "int64",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

caixas_pastas = ibis.table(
    name="caixas_pastas",
    schema={"caixas_id": "int64", "pastas_id": "int64", "usuarios_id": "int64"},
)

tramitacoes = ibis.table(
    name="tramitacoes",
    schema={
        "id": "int64",
        "pastas_id": "int64",
        "setores_origem_id": "int64",
        "setores_destino_id": "int64",
        "data_hora_recebimento": "timestamp",
        "criado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)

corrente_tematica = ibis.table(
    name="corrente_tematica",
    schema={
        "id": "int64",
        "nome": "string",
        "descricao": "string",
        "ativo": "int8",
        "setores_id": "int64",
        "apagado_em": "timestamp",
    },
)

pastas_corrente_tematica = ibis.table(
    name="pastas_corrente_tematica",
    schema={"pastas_id": "int64", "corrente_tematica_id": "int64", "usuarios_id": "int64"},
)

etiquetas = ibis.table(
    name="etiquetas",
    schema={"id": "int64", "nome": "string", "criado_por": "int64", "apagado_em": "timestamp"},
)

tarefas_etiquetas = ibis.table(
    name="tarefas_etiquetas",
    schema={
        "id": "int64",
        "tarefas_id": "int64",
        "etiquetas_id": "int64",
        "apagado_em": "timestamp",
    },
)

usuarios = ibis.table(
    name="usuarios",
    schema={
        "id": "int64",
        "colaboradores_id": "int64",
        "nome": "string",
        "username": "string",
        "email": "string",
        "apagado_em": "timestamp",
    },
)

# Modelo de permissão do Kanoê, o mesmo que `PermissionsVerifier.isAuthorizedUrl`
# consulta no filtro do JWT: usuário -> lotação (colaborador × setor) -> perfil
# -> funcionalidade -> URLs (método + caminho; `?` é um segmento qualquer).
lotacoes = ibis.table(
    name="lotacoes",
    schema={
        "id": "int64",
        "colaboradores_id": "int64",
        "setores_id": "int64",
        "principal": "int8",
        "apagado_em": "timestamp",
    },
)

lotacao_perfil = ibis.table(
    name="lotacao_perfil",
    schema={"id": "int64", "perfil_id": "int64", "lotacao_id": "int64", "apagado_em": "timestamp"},
)

perfil_acesso = ibis.table(
    name="perfil_acesso",
    schema={"id": "int64", "nome": "string", "descricao": "string", "apagado_em": "timestamp"},
)

perfil_funcionalidade = ibis.table(
    name="perfil_funcionalidade",
    schema={
        "id": "int64",
        "perfil_id": "int64",
        "funcionalidade_id": "int64",
        "apagado_em": "timestamp",
    },
)

funcionalidade = ibis.table(
    name="funcionalidade",
    schema={"id": "int64", "sigla": "string", "descricao": "string", "apagado_em": "timestamp"},
)

funcionalidade_url = ibis.table(
    name="funcionalidade_url",
    schema={"id": "int64", "metodo": "string", "url": "string", "funcionalidade_id": "int64"},
)

vw_processos_nao_recebidos = ibis.table(
    name="vw_processos_nao_recebidos",
    schema={
        "pastas_id": "int64",
        "ultima_tramitacao_id": "int64",
        "numero_processo_judicial": "string",
        "titulo": "string",
        "setor_origem_sigla": "string",
        "setorDestinoId": "int64",
        "setor_destino_sigla": "string",
        "statusTramitacao": "string",
        "criado_em": "timestamp",
        "prazo_expediente": "timestamp",
        "classe_nacional": "string",
        "valor_causa": "decimal(15, 2)",
    },
)

protocolos = ibis.table(
    name="protocolos",
    schema={
        "id": "int64",
        "componentes_digitais_id": "int64",
        "status": "int64",
        "mensagem": "string",
        "destino_dados": "string",
        "recibo_componentes_digitais_id": "int64",
        "sigilo": "int8",
        "etapa_falha": "int64",
        "criado_em": "timestamp",
        "atualizado_em": "timestamp",
        "apagado_em": "timestamp",
    },
)
