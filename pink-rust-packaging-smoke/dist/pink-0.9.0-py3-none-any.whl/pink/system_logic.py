"""Pure system-status semantics, independent of the catalog and Ibis.

The `status` operation passes its runtime boundaries into :func:`observe_status`;
domain tests call the same function with tiny probes.
"""

from __future__ import annotations

from typing import Protocol

from pink.models import IntegracaoStatus, RuntimeContext, SystemStatus


class StatusProbe(Protocol):
    async def probe(self) -> IntegracaoStatus: ...


async def observe_status(
    *,
    metabase: StatusProbe,
    kanoe: StatusProbe,
    google: StatusProbe,
    contexto: RuntimeContext,
) -> SystemStatus:
    metabase_status = await metabase.probe()
    kanoe_status = await kanoe.probe()
    effective = contexto.model_copy(
        update={
            "metabase_database_id": getattr(metabase, "database_id", None)
            or contexto.metabase_database_id,
            "kanoe_user_id": getattr(kanoe, "user_id", None) or contexto.kanoe_user_id,
            "kanoe_user_name": getattr(kanoe, "user_name", None) or contexto.kanoe_user_name,
        }
    )
    return SystemStatus(
        contexto=effective,
        metabase=metabase_status,
        kanoe=kanoe_status,
        google=await google.probe(),
    )
