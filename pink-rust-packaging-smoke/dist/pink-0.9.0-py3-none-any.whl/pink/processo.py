"""Processo context read capability."""

from __future__ import annotations

from typing import Any

from datetime import datetime
from decimal import Decimal

from pydantic import Field, TypeAdapter, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.domain_types import Cnj, PastaId, ProcessoId, SetorSigla, com_url_da_pasta
from pink.integrations import Metabase
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
)
from pink.queries_context import pastas_por_cnj, processos_por_cnj
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class ProcessoRegistro(PinkModel):
    """One physical active processos_jud row; Pink never invents a canonical row."""

    processo_id: ProcessoId
    numero: Cnj
    fonte_dados: str | None = Field(
        default=None, description="Fonte física que originou este registro"
    )
    competencia: int | None = Field(
        default=None, description="Código de competência observado no processo"
    )
    valor_causa: Decimal | None = Field(
        default=None, description="Valor da causa observado neste registro físico"
    )
    ajuizado_em: datetime | None = Field(
        default=None, description="Instante de ajuizamento observado"
    )
    criado_em: datetime | None = Field(
        default=None, description="Instante de criação deste registro no Caipora"
    )
    atualizado_em: datetime | None = Field(
        default=None, description="Última atualização observada deste registro"
    )
    classe: str | None = Field(default=None, description="Nome da classe processual observada")
    classe_codigo: int | None = Field(
        default=None, description="Código nacional da classe processual quando disponível"
    )
    orgao_julgador_id: int | None = Field(
        default=None, gt=0, description="ID físico do órgão julgador"
    )


class ProcessoPasta(PinkModel):
    pasta_id: PastaId
    processo_id: ProcessoId
    anotacao: str | None = Field(
        default=None, description="Anotação operacional atualmente observada na pasta"
    )
    aberto_em: datetime | None = Field(
        default=None, description="Instante de abertura observado da pasta"
    )
    atualizado_em: datetime | None = Field(
        default=None, description="Última atualização observada da pasta"
    )
    status: str | None = Field(default=None, description="Status físico observado da pasta")
    setor: SetorSigla = Field(description="Setor explicitamente responsável pela pasta")
    kanoe_url: str = Field(
        description="Página desta pasta na interface web do Kanoê, para o humano abrir (é o id da pasta, não do processo judicial)"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_kanoe_url(cls, value: Any) -> Any:
        return com_url_da_pasta(value)


class ProcessoContexto(PinkModel):
    """Consolidated case context preserving every physical processo identity."""

    cnj_consultado: Cnj = Field(description="CNJ canônico usado para construir este contexto")
    registros: list[ProcessoRegistro] = Field(
        description="Todos os registros físicos ativos do processo encontrados para o CNJ; nenhum é escolhido como canônico"
    )
    pastas: list[ProcessoPasta] = Field(
        description="Pastas ativas vinculadas aos registros físicos encontrados para o CNJ"
    )


class ProcessoResultado(PinkModel):
    dados: Observacao[ProcessoContexto] = Field(
        description="Contexto consolidado do processo observado no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


async def _obter(metabase: Metabase, cnj: Cnj) -> ProcessoResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return ProcessoResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )
    registros_raw = await metabase.rows(processos_por_cnj(cnj))
    if not registros_raw:
        return ProcessoResultado(
            dados=Ausente(
                fonte=Fonte.METABASE, motivo=f"nenhum processo ativo encontrado para {cnj}"
            )
        )
    pastas_raw = await metabase.rows(pastas_por_cnj(cnj))
    contexto = ProcessoContexto(
        cnj_consultado=cnj,
        registros=TypeAdapter(list[ProcessoRegistro]).validate_python(registros_raw),
        pastas=TypeAdapter(list[ProcessoPasta]).validate_python(pastas_raw),
    )
    return ProcessoResultado(dados=Observado(valor=contexto))


def build_processo_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    @catalogo.operacao(
        nome="processo_obter",
        tags={"processo", "read"},
        efeito=READ,
    )
    async def processo_obter(
        cnj: Cnj,
    ) -> ProcessoResultado:
        """Obtém contexto consolidado do CNJ sem escolher um processo físico canônico."""
        metabase = get_metabase()
        return await _obter(metabase, cnj)

    return catalogo
