"""Stable sector selections share the same filters and row projections as lists."""

from pink.queries import pastas_filter
from pink.queries_case import expedientes_filter
from pink.queries_reference import caixas_listar, tramitacoes_pendentes
from pink.setores import setores_por_sigla


def pastas_setor(setor: str):
    return pastas_filter(setor_ids=setores_por_sigla(setor).setor_id)


def expedientes_abertos_setor(setor: str):
    return expedientes_filter(setor_ids=setores_por_sigla(setor).setor_id, aberto=True)


def tramitacoes_setor(setor: str):
    return tramitacoes_pendentes(setor_ids=setores_por_sigla(setor).setor_id)


def caixas_setor(setor: str):
    return caixas_listar(setor=setor)
