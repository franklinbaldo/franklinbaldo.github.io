"""Composition root: the Pink catalog built from one explicit Runtime."""

from __future__ import annotations

from pink.artifacts import build_artifact_catalogo
from pink.caixa_state_resource import build_caixa_state_resource_catalogo
from pink.catalogo import Catalogo
from pink.documento import build_documento_catalogo
from pink.documento_write import build_documento_resource_catalogo, build_documento_write_catalogo
from pink.expediente import build_expediente_catalogo
from pink.expediente_write import build_expediente_write_catalogo
from pink.metabase_agent import build_metabase_agent_catalogo
from pink.minuta import build_minuta_catalogo, build_minuta_resource_catalogo
from pink.minuta_state_resource import build_minuta_state_resource_catalogo
from pink.pasta import build_pasta_catalogo
from pink.pasta_autarquia import build_pasta_autarquia_catalogo
from pink.pasta_contexto import build_pasta_contexto_catalogo
from pink.pasta_resource import build_pasta_resource_catalogo
from pink.pasta_write import build_pasta_write_catalogo
from pink.peticionamento import build_peticionamento_catalogo
from pink.peticionamento_prepare import build_peticionamento_prepare_catalogo
from pink.processo import build_processo_catalogo
from pink.raw import build_raw_google_catalogo, build_raw_kanoe_catalogo
from pink.referencias import build_referencia_catalogo
from pink.resumo import build_resumo_catalogo
from pink.submitted_resources import build_submitted_resource_catalogo
from pink.system import Runtime, build_system_catalogo
from pink.tarefa import build_tarefa_catalogo
from pink.tarefa_write import build_tarefa_write_catalogo
from pink.timeline import build_timeline_catalogo


def build_app(runtime: Runtime) -> Catalogo:
    """Build the operational catalog over one Runtime; the caller owns closing it."""
    return Catalogo().incluir(
        build_system_catalogo(runtime),
        build_artifact_catalogo(runtime.artifacts),
        build_processo_catalogo(runtime),
        build_pasta_catalogo(runtime),
        build_pasta_contexto_catalogo(runtime),
        build_pasta_autarquia_catalogo(runtime),
        build_pasta_resource_catalogo(runtime),
        build_pasta_write_catalogo(runtime),
        build_tarefa_catalogo(runtime),
        build_tarefa_write_catalogo(runtime),
        build_expediente_catalogo(runtime),
        build_expediente_write_catalogo(runtime),
        build_documento_catalogo(runtime),
        build_documento_resource_catalogo(runtime),
        build_documento_write_catalogo(runtime),
        build_minuta_catalogo(runtime),
        build_minuta_resource_catalogo(runtime),
        build_minuta_state_resource_catalogo(runtime),
        build_peticionamento_catalogo(runtime),
        build_peticionamento_prepare_catalogo(runtime),
        build_referencia_catalogo(runtime),
        build_submitted_resource_catalogo(runtime),
        build_caixa_state_resource_catalogo(runtime),
        build_resumo_catalogo(runtime),
        build_timeline_catalogo(runtime),
    )


def build_raw(runtime: Runtime) -> Catalogo:
    """Escape hatches (RFC 0057 §7): a separate catalog, reached only as `pink raw <operação>`."""
    return Catalogo().incluir(
        build_raw_google_catalogo(runtime),
        build_raw_kanoe_catalogo(runtime),
        build_metabase_agent_catalogo(runtime),
    )
