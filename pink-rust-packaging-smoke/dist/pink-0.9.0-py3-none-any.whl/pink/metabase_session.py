"""Secure persistence for Metabase session tokens."""

from __future__ import annotations

import hashlib
import logging

import keyring
import keyring.errors

_SERVICE = "pink-metabase-session"
_KEYRING_ERRORS = (OSError, RuntimeError, ImportError, keyring.errors.KeyringError)
_logger = logging.getLogger(__name__)


def _account(base_url: str, email: str) -> str:
    identity = f"{base_url.rstrip('/')}\n{email.strip().casefold()}"
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    return f"session:{digest}"


def get_metabase_session(base_url: str, email: str) -> str | None:
    """Read the cached session token, if the OS keyring is available."""
    try:
        return keyring.get_password(_SERVICE, _account(base_url, email))
    except _KEYRING_ERRORS as exc:
        _logger.warning("keyring indisponível para cache de sessão Metabase: %s", exc)
        return None


def save_metabase_session(base_url: str, email: str, token: str) -> None:
    """Cache a session token in the OS keyring when it is available."""
    try:
        keyring.set_password(_SERVICE, _account(base_url, email), token)
    except _KEYRING_ERRORS as exc:
        _logger.warning("não foi possível armazenar a sessão Metabase no keyring: %s", exc)


def delete_metabase_session(base_url: str, email: str) -> None:
    """Remove a rejected session token from the OS keyring."""
    try:
        keyring.delete_password(_SERVICE, _account(base_url, email))
    except keyring.errors.PasswordDeleteError:
        pass
    except _KEYRING_ERRORS as exc:
        _logger.warning("não foi possível remover a sessão Metabase do keyring: %s", exc)
