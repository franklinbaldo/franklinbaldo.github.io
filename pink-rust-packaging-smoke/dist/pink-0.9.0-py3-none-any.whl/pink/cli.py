"""Pink CLI: local commands plus one Cyclopts command per catalog operation.

Each operation keeps its original function, so its signature -- the Pydantic
contracts of its parameters -- becomes a command with nested flags
(`--filtro.setor`). The call validates the arguments against that same
signature and returns the typed result, rendered by Rich or, with `--json`,
dumped as the model's JSON. No schema of its own, no presenter per operation.

Card provisioning is a local administrative mutation and remains an explicit
command; a read never creates Metabase content implicitly.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import date, datetime
from enum import Enum
from getpass import getpass
from importlib.metadata import version
import inspect
import os
from pathlib import Path
import sys
from types import UnionType
from typing import Annotated, Any, Literal, Union, get_args, get_origin, get_type_hints

from cyclopts import App, Group, Parameter
from pydantic import BaseModel, TypeAdapter
from pydantic.fields import FieldInfo
from rich import box
from rich.console import Console, Group as RichGroup
from rich.table import Table
from rich.text import Text

from pink.app import build_app, build_raw
from pink.artifacts import ArtifactStore
from pink.catalogo import Catalogo, Operacao
from pink.credentials import save_caipora, save_google, save_kanoe, save_metabase
from pink.google_docs import UnavailableGoogleDocs
from pink.integrations import UnavailableKanoe, UnavailableMetabase
from pink.metabase import MetabaseHttp, RelatorioProvisionamentoCards
from pink.okf import exportar_expedientes, exportar_specs, resumo_do_relatorio
from pink.models import (
    Colecao,
    Disponibilidade,
    Observado,
    Parcial,
    ResultadoColecao,
)
from pink.runtime import close_runtime, runtime_from_settings
from pink.settings import Settings, update_local_config
from pink.setor_config import ConfiguracaoSetor, ConfiguracaoSetorSalva, TomlSetor, configurar_setor
from pink.system import Runtime


def _console() -> Console:
    """Num terminal, a largura real. Sem terminal (arquivo, agente), o Rich assume
    80 colunas e uma tabela de dez campos perde colunas inteiras -- medido em
    `pasta_obter`: `processo_id` sumiu da tabela de registros. Sem terminal e
    sem `COLUMNS`, 160 colunas."""
    if sys.stdout.isatty() or "COLUMNS" in os.environ:
        return Console()
    return Console(width=160)


console = _console()

_LABELS = {
    "expediente_id": "EXPEDIENTE",
    "pasta_id": "PASTA",
    "processo_id": "PROCESSO ID",
    "numero": "PROCESSO",
    "tarefa_id": "TAREFA",
    "tarefas_ids": "TAREFAS",
    "documento_id": "DOC",
    "prazo": "PRAZO",
    "criado_em": "CRIADO EM",
    "produzido_em": "PRODUZIDO EM",
    "setor": "SETOR",
    "fechado": "FECHADO",
}


def _artifact_root() -> Path:
    return (Path.cwd() / ".pink" / "artifacts").resolve()


def _runtime_cli() -> Runtime:
    return runtime_from_settings(artifacts=ArtifactStore(_artifact_root()))


def _artifact_path(uri: str) -> Path:
    artifact_id = uri.removeprefix("pink://artifact/")
    return _artifact_root() / f"{artifact_id}.parquet"


def _data(valor: date | datetime) -> date:
    return valor.date() if isinstance(valor, datetime) else valor


def _alerta_prazo(valor: date | datetime | None) -> str:
    if valor is None:
        return "—"
    delta = (_data(valor) - datetime.now().astimezone().date()).days
    if delta < 0:
        return f"⚠ vencido {abs(delta)}d"
    if delta == 0:
        return "hoje"
    if delta == 1:
        return "amanhã"
    if delta <= 3:
        return f"em {delta}d"
    return "—"


def _valor(valor: Any, *, campo: str) -> str:
    if valor is None:
        return "—"
    if isinstance(valor, bool):
        return "sim" if valor else "não"
    if isinstance(valor, datetime):
        return valor.strftime("%d/%m/%Y %H:%M")
    if isinstance(valor, date):
        return valor.strftime("%d/%m/%Y")
    if isinstance(valor, Enum):
        return str(valor.value)
    if campo == "tarefas_ids" and isinstance(valor, str):
        valor = [int(item) for item in valor.split(",") if item]
    if isinstance(valor, (list, tuple)):
        return "—" if not valor else "[" + ", ".join(str(item) for item in valor) + "]"
    return str(valor)


def _tabela_colecao(itens: list[BaseModel]) -> Table:
    campos = list(type(itens[0]).model_fields)
    colunas: list[tuple[str, str]] = []
    for campo in campos:
        colunas.append((campo, _LABELS.get(campo, campo.replace("_", " ").upper())))
        if campo == "prazo":
            colunas.append(("__alerta_prazo__", "ALERTA"))

    tabela = Table(box=box.SIMPLE_HEAD, pad_edge=False, header_style="bold cyan")
    for campo, label in colunas:
        longo = campo in {"titulo", "nome", "descricao", "observacao", "teor", "detalhe"}
        tabela.add_column(
            label,
            overflow="fold",
            max_width=40 if longo else None,
            min_width=min(len(label), 12),
        )
    for item in itens:
        row: list[str] = []
        for campo, _ in colunas:
            if campo == "__alerta_prazo__":
                row.append(_alerta_prazo(getattr(item, "prazo", None)))
            else:
                row.append(_valor(getattr(item, campo), campo=campo))
        tabela.add_row(*row)
    return tabela


def _render_colecao(colecao: Colecao[Any], *, estado: str | None = None) -> RichGroup:
    path = _artifact_path(str(colecao.dataset.uri))
    cabecalho = Text()
    if estado:
        cabecalho.append(f"{estado}  ·  ", style="dim")
    cabecalho.append(f"total={colecao.total}", style="bold")
    cabecalho.append(
        f"  ·  {path}  ({colecao.dataset.linhas} linhas, {colecao.dataset.tamanho_bytes} bytes)",
        style="dim",
    )
    if not colecao.amostra:
        return RichGroup(cabecalho, Text("(seleção vazia)", style="dim"))
    tabela = _tabela_colecao(list(colecao.amostra))
    if colecao.amostra_completa:
        return RichGroup(cabecalho, tabela)
    rodape = Text(
        f"mostrando {len(colecao.amostra)} de {colecao.total} — o restante em {path}",
        style="yellow",
    )
    return RichGroup(cabecalho, tabela, rodape)


async def doctor() -> None:
    """Diagnostica o runtime chamando a operação `status`."""
    status = await _executar(build_app, runtime_from_settings, lambda cat: cat.chamar("status"))
    console.print(status)
    if any(
        getattr(status, name).estado is Disponibilidade.INDISPONIVEL
        for name in ("metabase", "kanoe", "google")
    ):
        raise SystemExit(1)


async def setup(
    metabase_database_id: int | None = None,
    metabase_collection_id: int | None = None,
    kanoe_user_id: int | None = None,
    kanoe_user_name: str | None = None,
) -> None:
    """Atualiza somente configuração não secreta em `pink.toml`."""
    path = update_local_config(
        metabase_database_id=metabase_database_id,
        metabase_collection_id=metabase_collection_id,
        kanoe_user_id=kanoe_user_id,
        kanoe_user_name=kanoe_user_name,
    )
    print(path)


async def auth(
    servico: Literal["metabase", "caipora", "kanoe", "google"],
    email: str | None = None,
    usuario: str | None = None,
) -> None:
    """Grava credencial no keyring usando prompt oculto para o segredo.

    `caipora` guarda usuário (CPF) e senha do SSO: com eles o token do Kanoê é
    obtido no primeiro uso e renovado sozinho ao expirar. `kanoe` cola um
    Authorization pronto, que vale seis horas.
    """
    if servico == "metabase":
        if email is None or not email.strip():
            raise ValueError("--email é obrigatório para autenticação Metabase")
        save_metabase(email.strip(), getpass("Senha Metabase: "))
    elif servico == "caipora":
        if usuario is None or not usuario.strip():
            raise ValueError("--usuario (CPF) é obrigatório para autenticação Caipora")
        save_caipora(usuario.strip(), getpass("Senha Caipora: "))
    elif servico == "kanoe":
        save_kanoe(getpass("Authorization Kanoê: "))
    else:
        save_google(getpass("Authorization Google: "))
    setor_local = TomlSetor().ler_para_edicao().setor
    if not isinstance(setor_local, str) or not setor_local.strip():
        aviso = (
            "Olha, não tem uma configuração de setor aqui. Você quer fazer a configuração do setor?"
        )
        if sys.stdin.isatty():
            if _DialogoTerminal().confirmar(aviso):
                setor_configurar()
        else:
            print(f"{aviso} Execute `pink setor configurar`.", file=sys.stderr)


class _DialogoTerminal:
    """Terminal interaction for shared sector setup."""

    def perguntar(self, campo: str, atual: str) -> str:
        return input(f"{campo} [{atual}] (Enter mantém; - remove): ").strip()

    def confirmar(self, mensagem: str) -> bool:
        return input(f"{mensagem} [s/N] ").strip().lower() in {"s", "sim", "y", "yes"}


def setor_configurar(
    *,
    setor: str | None = None,
    metabase_collection_id: int | None = None,
    modelo_id: int | None = None,
    modelo: Path | None = None,
    timbrado: Path | None = None,
    css: Path | None = None,
) -> ConfiguracaoSetorSalva | None:
    """Cria ou altera o setor no pink.toml, preservando as demais configurações.

    Sem opções, abre o assistente. --setor recebe a sigla do Kanoê;
    --metabase-collection-id identifica a coleção existente. --modelo-id é o
    modelo compartilhado do Kanoê; --modelo, --timbrado e --css são caminhos
    relativos ao pink.toml, consumidos pelo fluxo documental do repositório.
    O comando não autentica usuários nem cria Cards ou documentos remotos.
    """
    values = {
        "setor": setor,
        "metabase_collection_id": metabase_collection_id,
        "modelo_id": modelo_id,
        "modelo": modelo,
        "timbrado": timbrado,
        "css": css,
    }
    changes = {key: value for key, value in values.items() if value is not None}
    if not changes and not sys.stdin.isatty():
        raise ValueError("sem terminal interativo, informe --setor e as opções desejadas")
    shared: dict[str, object] = {
        key: value for key, value in changes.items() if key in {"setor", "metabase_collection_id"}
    }
    assets = {key: value for key, value in changes.items() if key not in shared}
    if assets:
        shared["peticao"] = assets
    return configurar_setor(
        TomlSetor(),
        alteracoes=ConfiguracaoSetor.model_validate(shared),
        dialogo=_DialogoTerminal() if not changes else None,
    )


async def metabase_provisionar_cards(
    collection_id: int | None = None, dry_run: bool = False, queries: tuple[str, ...] | None = None
) -> RelatorioProvisionamentoCards:
    """Provisiona as Cards Pink conhecidas na collection do setor; repetir é idempotente.

    A collection é configuração do setor (`metabase_collection_id` no `pink.toml`
    do repositório consumidor, ou `pink setup --metabase-collection-id`); o
    argumento só a sobrepõe. Sem --queries, reconcilia todos os contratos da
    versão instalada. --dry-run apenas observa; --json publica coleção, Cards
    e prontidão para automação do consumidor. Uma versão nova do contrato cria
    uma Card nova e preserva as anteriores.
    """
    settings = Settings()
    alvo = collection_id if collection_id is not None else settings.metabase_collection_id
    if alvo is None:
        raise ValueError(
            "collection do setor não configurada: `pink setup --metabase-collection-id <id>` "
            "ou PINK_METABASE_COLLECTION_ID"
        )
    runtime = runtime_from_settings(settings)
    try:
        if not isinstance(runtime.metabase, MetabaseHttp):
            raise TypeError("Metabase não está configurado; rode `pink auth metabase`")
        resultados = await runtime.metabase.provision_cards(alvo, dry_run=dry_run, queries=queries)
    finally:
        await close_runtime(runtime)
    return RelatorioProvisionamentoCards(
        collection_id=alvo,
        dry_run=dry_run,
        cards=resultados,
        pronto=all(card.estado != "dry_run" for card in resultados),
    )


async def okf_expedientes(
    destino: Path, setor: str | None = None, dry_run: bool = False
) -> dict[str, Any]:
    """Materializa os expedientes abertos do setor como conceitos OKF `Expediente`.

    Cria o arquivo de cada expediente que chegou (com o teor, uma vez só) e, nos
    já materializados, atualiza apenas os campos do Kanoê; o trabalho do setor no
    mesmo arquivo não é tocado. Repetir sem mudança no Kanoê não altera nada.
    Sem --setor, usa o `setor` do `pink.toml`. --dry-run apenas relata.
    """
    alvo = setor or TomlSetor().ler().setor
    if not alvo:
        raise ValueError("setor não configurado: informe --setor ou `pink setor configurar`")
    runtime = runtime_from_settings()
    try:
        relatorio = await exportar_expedientes(runtime, alvo, destino, gravar=not dry_run)
    finally:
        await close_runtime(runtime)
    return {"setor": alvo, "dry_run": dry_run, **resumo_do_relatorio(relatorio)}


def okf_specs(destino: Path) -> list[str]:
    """Publica o contrato OKF do tipo `Expediente` no diretório do consumidor."""
    return [str(caminho) for caminho in exportar_specs(destino)]


def _mostrar(resultado: Any) -> int:
    """Cyclopts' single exit: collections get the common human view; models keep Rich."""
    if resultado is None:
        return 0
    if isinstance(resultado, ResultadoColecao):
        observado = resultado.dados
        if isinstance(observado, (Observado, Parcial)):
            console.print(_render_colecao(observado.valor, estado=str(observado.estado)))
            return 0
    console.print(resultado)
    return 0


def _mostrar_json(resultado: Any) -> int:
    """`--json`: the typed return as the published contract, no presentation at all."""
    if resultado is None:
        return 0
    if isinstance(resultado, BaseModel):
        print(resultado.model_dump_json(indent=2, by_alias=True))
    else:
        print(TypeAdapter(type(resultado)).dump_json(resultado, indent=2).decode())
    return 0


def catalogo() -> Catalogo:
    """The catalog does not need credentials: unavailable adapters expose the same operations."""
    return build_app(_runtime_de_catalogo())


def catalogo_raw() -> Catalogo:
    """The raw escape hatches, derived the same way as the operational catalog."""
    return build_raw(_runtime_de_catalogo())


def _runtime_de_catalogo() -> Runtime:
    return Runtime(
        metabase=UnavailableMetabase("catálogo"),
        kanoe=UnavailableKanoe("catálogo"),
        google=UnavailableGoogleDocs("catálogo"),
    )


def _eh_modelo(tipo: Any) -> bool:
    """A Pydantic model, or a union of them (a discriminated union such as `NovaTarefa`)."""
    if isinstance(tipo, type):
        return issubclass(tipo, BaseModel)
    if get_origin(tipo) in (Union, UnionType):
        return any(_eh_modelo(a) for a in get_args(tipo))
    return False


def _com_ajuda(nome: str, anotacao: Any) -> Any:
    """Cyclopts reads `Parameter(help=...)`, not a Pydantic `Field(description=...)` on a parameter.

    A model parameter is flattened into nested flags, so its own description
    becomes the help of the `Group` that frames those flags.
    """
    if get_origin(anotacao) is not Annotated:
        return anotacao
    base, *metadados = get_args(anotacao)
    if any(isinstance(m, Parameter) for m in metadados):
        return anotacao
    descricao = next(
        (m.description for m in metadados if isinstance(m, FieldInfo) and m.description), None
    )
    if descricao is None:
        return anotacao
    if _eh_modelo(base):
        parametro = Parameter(group=Group(nome, help=descricao))
    else:
        parametro = Parameter(help=descricao)
    return Annotated[(base, *metadados, parametro)]


def assinatura_publica(operacao: Operacao) -> inspect.Signature:
    """The operation's own signature, with each `Field(description=...)` as Cyclopts help."""
    hints = get_type_hints(operacao.fn, include_extras=True)
    assinatura = inspect.signature(operacao.fn)
    parametros = [
        p.replace(annotation=_com_ajuda(p.name, hints.get(p.name, p.annotation)))
        for p in assinatura.parameters.values()
    ]
    return assinatura.replace(parameters=parametros, return_annotation=inspect.Signature.empty)


async def _executar(
    montar: Callable[[Runtime], Catalogo],
    fabrica: Callable[[], Runtime],
    chamada: Callable[[Catalogo], Awaitable[Any]],
) -> Any:
    """One invocation: a fresh Runtime, the call, and the Runtime closed exactly once.

    An expected operational failure becomes one red line and exit status 1;
    anything else is a bug and keeps its traceback.
    """
    runtime = fabrica()
    try:
        return await chamada(montar(runtime))
    except (ValueError, RuntimeError, OSError) as exc:
        console.print(f"[bold red]erro:[/bold red] {exc}")
        raise SystemExit(1) from exc
    finally:
        await close_runtime(runtime)


_CONFIRMAR = inspect.Parameter(
    "confirmar",
    inspect.Parameter.KEYWORD_ONLY,
    default=False,
    annotation=Annotated[
        bool,
        Parameter(
            negative=(),
            help=(
                "Confirma a execução desta operação destrutiva. Sem a flag, um terminal "
                "interativo pergunta; fora dele, a operação é recusada."
            ),
        ),
    ],
)


def _confirmada(operacao: Operacao, confirmar: bool) -> bool:
    """Fail-closed gate for a destructive operation: the CLI itself enforces it."""
    if confirmar:
        return True
    if sys.stdin.isatty():
        return _DialogoTerminal().confirmar(
            f"`{operacao.nome}` é destrutiva ({operacao.descricao.splitlines()[0]}). Executar?"
        )
    return False


def _comando(
    operacao: Operacao,
    montar: Callable[[Runtime], Catalogo],
    fabrica: Callable[[], Runtime],
) -> Callable[..., Any]:
    assinatura = assinatura_publica(operacao)
    destrutiva = operacao.efeito.destrutivo
    assinatura_cli = (
        assinatura.replace(parameters=[*assinatura.parameters.values(), _CONFIRMAR])
        if destrutiva
        else assinatura
    )

    async def executar(*args: Any, **kwargs: Any) -> Any:
        confirmar = kwargs.pop("confirmar", False)
        if destrutiva and not _confirmada(operacao, confirmar):
            console.print(
                f"[bold red]erro:[/bold red] `{operacao.nome}` é destrutiva e não foi "
                "confirmada; repita com --confirmar"
            )
            raise SystemExit(1)
        vinculo = assinatura.bind(*args, **kwargs)
        vinculo.apply_defaults()
        return await _executar(
            montar, fabrica, lambda cat: cat.chamar(operacao.nome, vinculo.arguments)
        )

    executar.__name__ = operacao.nome
    executar.__doc__ = operacao.descricao
    setattr(executar, "__signature__", assinatura_cli)  # noqa: B010
    return executar


def _eh_texto(mime: str) -> bool:
    return mime.startswith("text/") or mime in {"application/json", "application/xml"}


def _comando_recurso(fabrica: Callable[[], Runtime]) -> Callable[..., Any]:
    async def recurso(uri: str, saida: Path | None = None) -> None:
        """Lê um recurso `pink://` ou `kanoe://` anunciado por uma operação.

        Texto e JSON vão para a saída padrão; conteúdo binário exige --saida,
        o arquivo onde gravar os bytes.
        """
        conteudo = await _executar(build_app, fabrica, lambda cat: cat.ler(uri))
        dados = conteudo.dados
        if saida is not None:
            saida.write_bytes(dados.encode() if isinstance(dados, str) else dados)
            print(saida)
        elif isinstance(dados, str):
            print(dados)
        elif _eh_texto(conteudo.mime):
            print(dados.decode("utf-8", errors="replace"))
        else:
            console.print(
                f"[bold red]erro:[/bold red] {uri} é binário ({conteudo.mime}); "
                "informe --saida <arquivo>"
            )
            raise SystemExit(1)

    return recurso


def _registrar(
    app: App,
    cat: Catalogo,
    montar: Callable[[Runtime], Catalogo],
    fabrica: Callable[[], Runtime],
) -> None:
    for operacao in cat.operacoes.values():
        alias = operacao.nome.replace("_", "-")
        nomes = [operacao.nome] if alias == operacao.nome else [operacao.nome, alias]
        app.command(_comando(operacao, montar, fabrica), name=nomes)


def construir_cli(fabrica: Callable[[], Runtime] = _runtime_cli) -> App:
    """Local commands plus one command per catalog operation."""
    versao = version("pink")
    app = App(
        name="pink",
        version=versao,
        help=f"Pink {versao}: configuração, autenticação, diagnóstico e as operações do catálogo.",
        result_action=_mostrar,
    )
    app.command(doctor)
    app.command(setup)
    app.command(auth)
    setor_app = App(name="setor", help="Configuração compartilhada do setor neste repositório.")
    setor_app.command(setor_configurar, name="configurar")
    app.command(setor_app)
    okf_app = App(name="okf", help="Materializa observações do Kanoê como conceitos OKF.")
    okf_app.command(okf_expedientes, name="expedientes")
    okf_app.command(okf_specs, name="specs")
    app.command(okf_app)
    app.command(metabase_provisionar_cards)
    app.command(_comando_recurso(fabrica), name="recurso")
    _registrar(app, catalogo(), build_app, fabrica)
    raw_app = App(
        name="raw",
        help="Escape hatches de diagnóstico, fora do catálogo operacional (RFC 0057 §7).",
    )
    _registrar(raw_app, catalogo_raw(), build_raw, fabrica)
    app.command(raw_app)

    @app.meta.default
    def lancador(
        *tokens: Annotated[str, Parameter(show=False, allow_leading_hyphen=True)],
        json: Annotated[
            bool,
            Parameter(
                help="Imprime o retorno como JSON do contrato publicado, em vez da apresentação Rich.",
                negative=(),
            ),
        ] = False,
    ) -> None:
        app(tokens, result_action=_mostrar_json if json else _mostrar)

    lancador.__doc__ = app.help
    app.meta.version = versao
    return app


app = construir_cli()


def main() -> None:
    """Cyclopts owns parsing, help, completion and async dispatch; `--json` lives in the meta app."""
    app.meta()


if __name__ == "__main__":
    main()
