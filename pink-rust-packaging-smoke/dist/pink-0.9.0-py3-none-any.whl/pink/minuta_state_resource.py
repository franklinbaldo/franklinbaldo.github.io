"""Typed JSON Resource for reobserving a Google-backed minuta."""

from __future__ import annotations

from typing import cast

from pydantic import TypeAdapter

from pink.catalogo import Catalogo, Conteudo
from pink.domain_types import GoogleDocId
from pink.google_docs import GoogleDocs
from pink.minuta import _obter
from pink.system import Runtime

_GOOGLE_DOC_ID = TypeAdapter(GoogleDocId)


def build_minuta_state_resource_catalogo(runtime: Runtime) -> Catalogo:
    """Expose identity/revision state as a Resource suitable for write reconciliation."""
    catalogo = Catalogo()
    google = cast(GoogleDocs, runtime.google)

    @catalogo.recurso(
        "pink://minuta/{google_doc_id}",
        mime="application/json",
        tags={"minuta", "read", "google", "write-state"},
    )
    async def minuta_estado(google_doc_id: str) -> Conteudo:
        identity = _GOOGLE_DOC_ID.validate_python(google_doc_id)
        conteudo = (await _obter(google, identity)).model_dump_json()
        return Conteudo(conteudo, mime="application/json")

    return catalogo
