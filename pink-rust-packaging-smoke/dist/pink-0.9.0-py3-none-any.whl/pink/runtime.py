"""Production runtime construction and lifecycle for Pink 0.8."""

from __future__ import annotations

from functools import partial
import inspect
import logging

import keyring
import keyring.errors

from pink.artifacts import ArtifactStore
from pink.caipora import token_kanoe_por_sso
from pink.credentials import save_kanoe
from pink.google_docs import GoogleDocsHttp, UnavailableGoogleDocs
from pink.integrations import UnavailableKanoe, UnavailableMetabase
from pink.kanoe_minuta_http import KanoeMinutaHttp
from pink.metabase import MetabaseConfig, MetabaseHttp
from pink.models import RuntimeContext
from pink.settings import Settings
from pink.system import Runtime


logger = logging.getLogger(__name__)


def _guardar_token_kanoe(token: str) -> None:
    """Best effort: the token in hand already serves this process; the keyring spares the next one."""
    try:
        save_kanoe(token)
    except (OSError, RuntimeError, ImportError, keyring.errors.KeyringError) as exc:
        logger.warning("token Kanoê renovado, mas não guardado no keyring: %s", exc)


def runtime_from_settings(
    settings: Settings | None = None, *, artifacts: ArtifactStore | None = None
) -> Runtime:
    """Construct adapters without network I/O; incomplete integrations stay unavailable."""
    config = settings or Settings()

    # O que a fonte sabe, a fonte diz: o id do banco é descoberto pelo nome em
    # `/api/database`, e a identidade Kanoê pelo CPF do token em
    # `/api/usuarios/cpf/{cpf}`. Config explícita continua valendo como override.
    if config.metabase_email is None or config.metabase_password is None:
        metabase = UnavailableMetabase(
            "credenciais do Metabase não configuradas (pink auth metabase)"
        )
    else:
        metabase = MetabaseHttp(
            MetabaseConfig(
                base_url=config.metabase_url,
                database=config.metabase_database,
                database_id=config.metabase_database_id,
                collection_id=config.metabase_collection_id,
                email=config.metabase_email,
                password=config.metabase_password,
            )
        )

    renovar = guardar = None
    if config.caipora_usuario and config.caipora_senha is not None:
        renovar = partial(
            token_kanoe_por_sso, config.caipora_usuario, config.caipora_senha.get_secret_value()
        )
        guardar = _guardar_token_kanoe
    if config.kanoe_authorization is None and renovar is None:
        kanoe = UnavailableKanoe(
            "sem token Kanoê nem credenciais Caipora para obtê-lo "
            "(pink auth caipora --usuario <cpf>, ou pink auth kanoe)"
        )
    elif (config.kanoe_user_id is None) != (config.kanoe_user_name is None):
        # Par parcial não é override nem descoberta: falha cedo, com o que falta.
        faltante = (
            "PINK_KANOE_USER_NAME" if config.kanoe_user_name is None else "PINK_KANOE_USER_ID"
        )
        kanoe = UnavailableKanoe(
            f"identidade Kanoê parcial: falta {faltante}; configure os dois ou nenhum "
            "(sem os dois, a identidade é descoberta do token)"
        )
    else:
        kanoe = KanoeMinutaHttp(
            authorization=(
                config.kanoe_authorization.get_secret_value()
                if config.kanoe_authorization is not None
                else None
            ),
            user_id=config.kanoe_user_id,
            user_name=config.kanoe_user_name,
            base_url=config.kanoe_base_url,
            renovar=renovar,
            guardar=guardar,
        )

    if config.google_authorization is None:
        google = UnavailableGoogleDocs("PINK_GOOGLE_AUTHORIZATION não configurado")
    else:
        google = GoogleDocsHttp(
            authorization=config.google_authorization.get_secret_value(),
        )

    return Runtime(
        metabase=metabase,
        kanoe=kanoe,
        google=google,
        artifacts=artifacts or ArtifactStore.temporary(),
        contexto=RuntimeContext(
            metabase_url=config.metabase_url,
            metabase_database_id=config.metabase_database_id,
            kanoe_base_url=config.kanoe_base_url,
            kanoe_user_id=config.kanoe_user_id,
            kanoe_user_name=config.kanoe_user_name,
        ),
    )


async def close_runtime(runtime: Runtime) -> None:
    """Close every runtime-owned resource once, even when one closer fails."""
    seen: set[int] = set()
    failures: list[Exception] = []
    for component in (runtime.metabase, runtime.kanoe, runtime.google, runtime.artifacts):
        if id(component) in seen:
            continue
        seen.add(id(component))
        closer = getattr(component, "aclose", None)
        if closer is None:
            continue
        try:
            result = closer()
            if inspect.isawaitable(result):
                await result
        except Exception as exc:  # noqa: BLE001 - shutdown must attempt every independent closer
            failures.append(exc)

    if failures:
        raise ExceptionGroup("falhas ao fechar recursos do runtime Pink", failures)
