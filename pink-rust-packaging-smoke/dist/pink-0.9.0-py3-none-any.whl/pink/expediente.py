"""Expediente read contracts and catalog operations."""

from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Any

from pydantic import Field, TypeAdapter, field_serializer, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore, materializar_colecao
from pink.domain_types import (
    com_url_da_pasta,
    Limite,
    Cnj,
    DocumentoId,
    ExpedienteId,
    PastaId,
    ProcessoId,
    SetorSigla,
    TarefaId,
    cnj_storage_variants,
)
from pink.integrations import Metabase
from pink.metabase import ObservacaoTruncada
from pink.setores import ids_do_setor
from pink.queries_setoriais import expedientes_abertos_setor
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
    ResultadoColecao,
)
from pink.queries_case import (
    comentarios_for_expediente,
    expediente_detail,
    expedientes_filter,
    tarefas_abertas_for_expediente,
    tarefas_abertas_for_expedientes,
)
from pink.system import Runtime
from pink.write_safety import ConsultaSemCard, RemoteObservationFailure

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


def _tarefas_ids(valor: list[TarefaId] | str | None) -> list[int] | None:
    if valor is None:
        return None
    if isinstance(valor, str):
        return [int(item) for item in valor.split(",") if item]
    return [int(item) for item in valor]


class ExpedienteResumo(PinkModel):
    expediente_id: ExpedienteId
    pasta_id: PastaId
    setor: SetorSigla = Field(description="Setor da pasta na observação")
    numero: Cnj | None = Field(
        default=None, description="Número CNJ canônico do processo associado"
    )
    tipo: int | None = Field(default=None, description="Código do tipo de expediente observado")
    prazo: datetime | None = Field(default=None, description="Prazo final observado do expediente")
    fechado: bool = Field(description="Indica se o expediente estava fechado na observação")
    criado_em: datetime = Field(description="Instante de criação observado do expediente")
    documento_id: DocumentoId | None = Field(
        default=None, description="Documento principal vinculado quando disponível"
    )
    tarefas_ids: list[TarefaId] | str | None = Field(
        default=None,
        description="IDs das tarefas abertas vinculadas ao expediente; null quando não há tarefa aberta",
    )

    @field_serializer("tarefas_ids", when_used="json", return_type=list[int] | None)
    def serialize_tarefas_ids(self, valor: list[TarefaId] | str | None) -> list[int] | None:
        return _tarefas_ids(valor)


class ExpedienteFiltro(PinkModel):
    setor: SetorSigla | None = Field(default=None, description="Filtra pela sigla do setor")
    processo: Cnj | None = Field(default=None, description="Filtra pelo número CNJ")
    pasta_id: PastaId | None = Field(default=None, description="Filtra pela pasta")
    aberto: bool | None = Field(default=None, description="True aberto, False fechado, None ambos")
    prazo_de: date | None = Field(default=None, description="Início inclusivo da janela de prazo")
    prazo_ate: date | None = Field(default=None, description="Fim inclusivo da janela de prazo")
    tipo: int | None = Field(default=None, description="Código de tipo do expediente")
    com_tarefa: bool | None = Field(
        default=None,
        description="True exige tarefa aberta vinculada; False exige nenhuma",
    )

    @model_validator(mode="after")
    def validar_janela_prazo(self) -> ExpedienteFiltro:
        if (
            self.prazo_de is not None
            and self.prazo_ate is not None
            and self.prazo_ate < self.prazo_de
        ):
            raise ValueError("prazo_ate não pode ser anterior a prazo_de")
        return self


class ExpedienteListagem(ResultadoColecao[ExpedienteResumo]):
    """Resultado Pydantic concreto da coleção de expedientes."""


class ExpedienteComentario(PinkModel):
    comentario_id: int = Field(gt=0, description="ID remoto do comentário do expediente")
    comentario: str | None = Field(default=None, description="Texto observado do comentário")
    criado_em: datetime | None = Field(
        default=None, description="Instante de criação do comentário"
    )
    criado_por: int | None = Field(default=None, gt=0, description="ID do autor quando disponível")


class ExpedienteDados(PinkModel):
    expediente_id: ExpedienteId
    pasta_id: PastaId
    pasta_url: str = Field(
        description="Página da pasta vinculada na interface web do Kanoê, para o humano abrir"
    )
    setor: SetorSigla = Field(description="Setor da pasta na observação")
    processo_id: ProcessoId | None = Field(
        default=None, description="Registro físico de processo associado à pasta"
    )
    numero: Cnj | None = Field(
        default=None, description="Número CNJ canônico do processo associado"
    )
    tipo: int | None = Field(default=None, description="Código do tipo de expediente observado")
    teor: str | None = Field(default=None, description="Teor textual observado do expediente")
    prazo: datetime | None = Field(default=None, description="Prazo final observado do expediente")
    fechado: bool = Field(description="Indica se o expediente estava fechado na observação")
    criado_em: datetime = Field(description="Instante de criação observado do expediente")
    documento_id: DocumentoId | None = Field(
        default=None, description="Documento principal vinculado quando disponível"
    )
    documento_autor: str | None = Field(
        default=None, description="Autor observado do documento principal vinculado"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_pasta_url(cls, value: Any) -> Any:
        return com_url_da_pasta(value, campo="pasta_url")


class ExpedienteDetalhe(PinkModel):
    expediente: ExpedienteDados = Field(
        description="Linha principal do expediente com breadcrumbs do caso"
    )
    comentarios: list[ExpedienteComentario] = Field(
        default_factory=list,
        description="Comentários observados do expediente em ordem da query de domínio",
    )


class ExpedienteResultado(PinkModel):
    dados: Observacao[ExpedienteDetalhe] = Field(
        description="Detalhe do expediente observado no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


async def _listar(
    metabase: Metabase,
    artifacts: ArtifactStore,
    filtro: ExpedienteFiltro,
    *,
    limite: int,
) -> ExpedienteListagem:
    query_args = filtro.model_dump()
    query_args["processo"] = None
    setor = query_args.pop("setor")

    async def selecao():
        ids = await ids_do_setor(metabase, setor) if setor is not None else None
        expression = expedientes_filter(setor_ids=ids, **query_args)
        if filtro.processo is not None:
            expression = expression.filter(
                expression.numero.isin(cnj_storage_variants(filtro.processo))
            )
        return expression

    async def enriquecer(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        expediente_ids = [int(row["expediente_id"]) for row in rows]
        tarefas: list[dict[str, Any]] = []
        if expediente_ids:
            try:
                tarefas = await metabase.rows(tarefas_abertas_for_expedientes(expediente_ids))
            except (ConsultaSemCard, ObservacaoTruncada):
                tarefas = []
                for expediente_id in expediente_ids:
                    try:
                        tarefas.extend(
                            await metabase.rows(tarefas_abertas_for_expediente(expediente_id))
                        )
                    except ObservacaoTruncada as exc:
                        raise RemoteObservationFailure(
                            "tarefas abertas do expediente "
                            f"{expediente_id} foram truncadas pela fonte em "
                            f"{exc.truncado_em} linhas"
                        ) from exc
        por_expediente: dict[int, list[int]] = {}
        for tarefa in tarefas:
            por_expediente.setdefault(int(tarefa["expediente_id"]), []).append(
                int(tarefa["tarefa_id"])
            )
        for row in rows:
            ids = por_expediente.get(int(row["expediente_id"]), [])
            row["tarefas_ids"] = ",".join(str(item) for item in ids) if ids else None
        return rows

    alternativa = (
        expedientes_abertos_setor(setor)
        if setor is not None and filtro == ExpedienteFiltro(setor=setor, aberto=True)
        else None
    )
    resultado = await materializar_colecao(
        metabase,
        artifacts,
        selecao,
        ExpedienteResumo,
        limite=limite,
        alternativa=alternativa,
        enriquecer=enriquecer,
    )
    return ExpedienteListagem(dados=resultado.dados)


async def _obter(metabase: Metabase, expediente_id: ExpedienteId) -> ExpedienteResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return ExpedienteResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )
    try:
        rows = await metabase.rows(expediente_detail(expediente_id))
        if not rows:
            return ExpedienteResultado(
                dados=Ausente(
                    fonte=Fonte.METABASE, motivo=f"expediente {expediente_id} não encontrado"
                )
            )
        comments = await metabase.rows(comentarios_for_expediente(expediente_id))
    except RemoteObservationFailure as exc:
        return ExpedienteResultado(dados=Indisponivel(fonte=Fonte.METABASE, motivo=str(exc)))
    detalhe = ExpedienteDetalhe(
        expediente=ExpedienteDados.model_validate(rows[0]),
        comentarios=TypeAdapter(list[ExpedienteComentario]).validate_python(comments),
    )
    return ExpedienteResultado(dados=Observado(valor=detalhe))


def build_expediente_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="expediente_listar",
        tags={"expediente", "read", "parquet"},
        efeito=READ,
    )
    async def expediente_listar(
        limite: Limite,
        filtro: Annotated[
            ExpedienteFiltro,
            Field(description="Filtros combináveis da listagem; omita para listar sem restrições"),
        ] = ExpedienteFiltro(),
    ) -> ExpedienteListagem:
        """Materializa uma seleção de expedientes limitada por `limite`, dentro dos filtros."""
        metabase = get_metabase()
        artifacts = get_artifacts()
        return await _listar(metabase, artifacts, filtro, limite=limite)

    @catalogo.operacao(
        nome="expediente_obter",
        tags={"expediente", "read"},
        efeito=READ,
    )
    async def expediente_obter(
        expediente_id: ExpedienteId,
    ) -> ExpedienteResultado:
        """Obtém expediente e seus comentários, com ausência observada explícita."""
        metabase = get_metabase()
        return await _obter(metabase, expediente_id)

    return catalogo
