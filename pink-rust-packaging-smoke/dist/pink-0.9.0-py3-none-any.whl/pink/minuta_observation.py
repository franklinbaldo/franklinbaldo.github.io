"""Pure observation semantics for a Google-backed minuta.

This module deliberately has no catalog, Ibis or DuckDB dependency.  The
Google HTTP adapter raises :class:`MinutaDocumentNotFound`; the `minuta_obter`
operation returns this result as is.
"""

from __future__ import annotations

from typing import Protocol

from pink.domain_types import GoogleDocId
from pink.minuta_core import MinutaDetalhe, MinutaResultado
from pink.models import (
    Desconhecido,
    Disponibilidade,
    Fonte,
    Indisponivel,
    IntegracaoStatus,
    Observado,
)
from pink.write_safety import RemoteObservationFailure


class MinutaObservedState(Protocol):
    """Read-only view of the immutable Google response consumed by Pink."""

    @property
    def google_doc_id(self) -> str: ...

    @property
    def revision_id(self) -> str: ...

    @property
    def title(self) -> str | None: ...


class MinutaObservationPort(Protocol):
    async def probe(self) -> IntegracaoStatus: ...

    async def document_state(self, google_doc_id: str) -> MinutaObservedState: ...


class MinutaDocumentNotFound(RemoteObservationFailure):
    """The document is absent or invisible to the active Google identity."""


async def obter_minuta(
    google: MinutaObservationPort,
    google_doc_id: GoogleDocId,
) -> MinutaResultado:
    """Observe Pink's knowledge of one minuta without any catalog machinery."""
    status = await google.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return MinutaResultado(
            dados=Indisponivel(fonte=Fonte.GOOGLE, motivo=status.detalhe or "Google indisponível")
        )
    try:
        state = await google.document_state(google_doc_id)
    except MinutaDocumentNotFound:
        return MinutaResultado(
            dados=Desconhecido(
                motivo=(
                    f"Google respondeu 404 para o Doc {google_doc_id}; a resposta não distingue "
                    "documento ausente de documento invisível para esta identidade"
                )
            )
        )
    except RemoteObservationFailure as exc:
        return MinutaResultado(dados=Indisponivel(fonte=Fonte.GOOGLE, motivo=str(exc)))
    return MinutaResultado(
        dados=Observado(
            valor=MinutaDetalhe.model_validate(
                {
                    "google_doc_id": state.google_doc_id,
                    "revision_id": state.revision_id,
                    "title": state.title,
                }
            )
        )
    )
