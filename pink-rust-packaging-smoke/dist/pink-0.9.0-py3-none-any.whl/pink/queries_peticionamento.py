"""Ibis expressions for Pink 0.8 peticionamento reads."""

from __future__ import annotations

from pink.schema import componentes_digitais, documentos, protocolos


def documento_existe(documento_id: int):
    """Observe the active document identity without requiring protocol attempts."""
    return (
        documentos.filter((documentos.id == documento_id) & documentos.apagado_em.isnull())
        .select(documento_id=documentos.id)
        .limit(1)
    )


def peticionamentos_for_documento(documento_id: int):
    """Return every protocol attempt attached to any live component of one document."""
    protocol = protocolos.filter(protocolos.apagado_em.isnull()).select(
        protocolo_id=protocolos.id,
        componente_digital_id=protocolos.componentes_digitais_id,
        status_codigo=protocolos.status,
        mensagem=protocolos.mensagem,
        destino=protocolos.destino_dados,
        etapa_falha=protocolos.etapa_falha,
        recibo_componente_id=protocolos.recibo_componentes_digitais_id,
        criado_em=protocolos.criado_em,
        atualizado_em=protocolos.atualizado_em,
    )
    petition_component = componentes_digitais.filter(
        componentes_digitais.apagado_em.isnull()
    ).select(
        componente_digital_id=componentes_digitais.id,
        documento_id=componentes_digitais.documentos_id,
    )
    receipt_base = componentes_digitais.view()
    receipt_component = receipt_base.filter(receipt_base.apagado_em.isnull()).select(
        recibo_componente_id=receipt_base.id,
        recibo_documento_id=receipt_base.documentos_id,
        recibo_hash=receipt_base.hash,
        recibo_file_name=receipt_base.file_name,
    )

    return (
        protocol.inner_join(
            petition_component,
            protocol.componente_digital_id == petition_component.componente_digital_id,
        )
        .left_join(
            receipt_component,
            protocol.recibo_componente_id == receipt_component.recibo_componente_id,
        )
        .filter(petition_component.documento_id == documento_id)
        .select(
            protocolo_id=protocol.protocolo_id,
            componente_digital_id=protocol.componente_digital_id,
            documento_id=petition_component.documento_id,
            status_codigo=protocol.status_codigo,
            mensagem=protocol.mensagem,
            destino=protocol.destino,
            etapa_falha=protocol.etapa_falha,
            recibo_componente_id=protocol.recibo_componente_id,
            recibo_documento_id=receipt_component.recibo_documento_id,
            recibo_hash=receipt_component.recibo_hash,
            recibo_file_name=receipt_component.recibo_file_name,
            criado_em=protocol.criado_em,
            atualizado_em=protocol.atualizado_em,
        )
        .order_by(protocol.criado_em.asc(), protocol.protocolo_id.asc())
    )
