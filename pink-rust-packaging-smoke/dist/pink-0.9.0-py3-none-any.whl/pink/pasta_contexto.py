"""Pasta context aggregation without legacy service adapters."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import Field, TypeAdapter, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.documento import DocumentoResumo
from pink.pasta_models import PastaResponsabilidade
from pink.domain_types import (
    Cnj,
    CorrenteTematicaId,
    PastaId,
    ProcessoId,
    SetorSigla,
    com_url_da_pasta,
)
from pink.expediente import ExpedienteResumo
from pink.integrations import Metabase
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
)
from pink.queries import tarefas_filter
from pink.queries_case import documentos_filter, expedientes_filter
from pink.queries_context import correntes_for_pasta, pasta_detail, pasta_resumo_latest
from pink.system import Runtime
from pink.tarefa import TarefaResumo

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class PastaDados(PastaResponsabilidade):
    pasta_id: PastaId
    outro_numero: str | None = Field(
        default=None, description="Outro número de referência observado na pasta"
    )
    anotacao: str | None = Field(
        default=None, description="Anotação operacional atualmente observada"
    )
    aberto_em: datetime | None = Field(
        default=None, description="Instante de abertura observado da pasta"
    )
    atualizado_em: datetime | None = Field(
        default=None, description="Última atualização observada da pasta"
    )
    status: str | None = Field(default=None, description="Status físico observado da pasta")
    setor: SetorSigla = Field(
        description="Setor atual da pasta, distinto do setor responsável pela etiqueta"
    )
    processo_id: ProcessoId | None = Field(
        default=None, description="Registro físico de processo associado à pasta"
    )
    numero: Cnj | None = Field(
        default=None, description="Número CNJ canônico do processo associado"
    )
    fonte_dados: str | None = Field(default=None, description="Fonte física observada do processo")
    competencia: int | None = Field(default=None, description="Código de competência observado")
    valor_causa: Decimal | None = Field(
        default=None, description="Valor da causa observado no registro de processo associado"
    )
    ajuizado_em: datetime | None = Field(
        default=None, description="Instante de ajuizamento observado do processo"
    )
    classe: str | None = Field(default=None, description="Nome da classe processual observada")
    classe_codigo: int | None = Field(
        default=None, description="Código nacional da classe processual quando disponível"
    )
    pdf_resource_uri: str = Field(
        description="URI de recurso do PDF integral live correspondente exatamente a esta pasta"
    )
    kanoe_url: str = Field(
        description="Página desta pasta na interface web do Kanoê, para o humano abrir (é o id da pasta, não do processo judicial)"
    )

    @model_validator(mode="before")
    @classmethod
    def derive_pdf_resource_uri(cls, value: Any) -> Any:
        """Derive the stable PDF Resource URI and reject a conflicting supplied value."""
        if not isinstance(value, dict):
            return value
        pasta_id = value.get("pasta_id")
        if pasta_id is None:
            return value
        expected = f"pink://pasta/{pasta_id}/pdf"
        supplied = value.get("pdf_resource_uri")
        if supplied is not None and supplied != expected:
            raise ValueError("pdf_resource_uri diverge de pasta_id")
        return com_url_da_pasta({**value, "pdf_resource_uri": expected})


class ResumoPasta(PinkModel):
    resumo_id: int = Field(gt=0, description="ID físico da versão de resumo da pasta")
    resumo: str | None = Field(default=None, description="Texto do resumo observado")
    versao: int = Field(ge=0, description="Versão física observada do resumo")
    criado_em: datetime | None = Field(
        default=None, description="Instante de criação da versão de resumo"
    )


class CorrentePasta(PinkModel):
    corrente_id: CorrenteTematicaId
    nome: str = Field(description="Nome observado da corrente temática")
    descricao: str | None = Field(
        default=None, description="Descrição observada da corrente temática"
    )


class PastaContexto(PinkModel):
    pasta: PastaDados = Field(description="Linha principal da pasta com breadcrumbs do processo")
    resumo: Observacao[ResumoPasta] = Field(
        description="Resumo mais recente observado, com ausência explícita quando a pasta não possui resumo"
    )
    expedientes: list[ExpedienteResumo] = Field(
        default_factory=list,
        description="Expedientes vinculados observados para esta pasta",
    )
    tarefas: list[TarefaResumo] = Field(
        default_factory=list,
        description="Tarefas abertas e concluídas observadas para esta pasta",
    )
    documentos: list[DocumentoResumo] = Field(
        default_factory=list,
        description="Documentos observados para esta pasta",
    )
    correntes: list[CorrentePasta] = Field(
        default_factory=list,
        description="Correntes temáticas atualmente vinculadas à pasta",
    )


class PastaResultado(PinkModel):
    dados: Observacao[PastaContexto] = Field(
        description="Contexto agregado da pasta observado no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


async def _obter(metabase: Metabase, pasta_id: PastaId) -> PastaResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return PastaResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )
    main_rows = await metabase.rows(pasta_detail(pasta_id))
    if not main_rows:
        return PastaResultado(
            dados=Ausente(fonte=Fonte.METABASE, motivo=f"pasta {pasta_id} não encontrada")
        )

    summary_rows = await metabase.rows(pasta_resumo_latest(pasta_id))
    resumo: Observacao[ResumoPasta] = (
        Observado(valor=ResumoPasta.model_validate(summary_rows[0]))
        if summary_rows
        else Ausente(fonte=Fonte.METABASE, motivo="pasta sem resumo registrado")
    )
    expedientes = await metabase.rows(expedientes_filter(pasta_id=pasta_id))
    tarefas = await metabase.rows(tarefas_filter(pasta_id=pasta_id, aberta=None))
    documentos = await metabase.rows(documentos_filter(pasta_id=pasta_id))
    correntes = await metabase.rows(correntes_for_pasta(pasta_id))

    contexto = PastaContexto(
        pasta=PastaDados.model_validate(main_rows[0]),
        resumo=resumo,
        expedientes=TypeAdapter(list[ExpedienteResumo]).validate_python(expedientes),
        tarefas=TypeAdapter(list[TarefaResumo]).validate_python(tarefas),
        documentos=TypeAdapter(list[DocumentoResumo]).validate_python(documentos),
        correntes=TypeAdapter(list[CorrentePasta]).validate_python(correntes),
    )
    return PastaResultado(dados=Observado(valor=contexto))


def build_pasta_contexto_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    @catalogo.operacao(
        nome="pasta_obter",
        tags={"pasta", "read"},
        efeito=READ,
    )
    async def pasta_obter(
        pasta_id: PastaId,
    ) -> PastaResultado:
        """Obtém contexto agregado e anuncia o PDF integral como URI de recurso."""
        metabase = get_metabase()
        return await _obter(metabase, pasta_id)

    return catalogo
