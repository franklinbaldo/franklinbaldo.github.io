"""A sector sigla is resolved into ids before any selection is expressed.

Measured against production (MySQL 8.4, `ratio`), the setor filter is the
difference between a scan and an index: with the sigla in the predicate --
`CAST(sigla AS BINARY) = ...`, which is how Ibis compiles string equality for
MySQL -- the optimizer scans `pastas` whole (EXPLAIN: ALL, 257k rows) because
it cannot estimate how many sectors match, and no hint survives the derived
tables Ibis emits. With the id as a literal it drives from `setores` (const)
into `pastas.setores_id` (ref, ~2k rows): `pasta_listar` 4.0 s -> 0.2 s,
`tarefa_listar` 3.8 s -> 0.1 s, `expediente_listar` 3.1 s -> 0.1 s, same
rows. The resolution itself costs ~10 ms.

Siglas are not unique (six are shared by two active sectors), so the result
is a tuple and every selection filters with `isin`; an unknown sigla resolves
to no ids and the selection compiles to `WHERE FALSE`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import ConfigDict, Field

from pink import schema
from pink.domain_types import SetorId
from pink.models import PinkModel


class Setor(PinkModel):
    """A sector as identified by either institutional source."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    id: SetorId
    sigla: str | None = Field(description="Sigla informada pela fonte")
    nome: str | None = Field(description="Nome informado pela fonte")
    cnpj: str | None = Field(
        description="CNPJ informado pela fonte, aceito sem validar formato ou dígitos verificadores"
    )


if TYPE_CHECKING:
    from ibis.expr import types as ir

    from pink.integrations import Metabase


def setores_por_sigla(sigla: str) -> ir.Table:
    """Ids of every sector carrying this sigla; `isin` compiles to a plain `IN`."""
    s = schema.setores
    return s.filter(s.sigla.isin([sigla]) & (s.ativo == 1)).select(setor_id=s.id)


def setores_ativos(sigla: str) -> ir.Table:
    """All active identities of the exact abbreviation, including shared siglas."""
    s = schema.setores
    return (
        s.filter(s.sigla.isin([sigla]) & (s.ativo == 1))
        .select("id", "sigla", "nome", "cnpj")
        .order_by("id")
    )


async def ids_do_setor(metabase: Metabase, sigla: str) -> tuple[int, ...]:
    """One small observation so the main selection carries literal ids."""
    linhas = await metabase.rows(setores_por_sigla(sigla))
    return tuple(int(linha["setor_id"]) for linha in linhas)
