"""The PJe timeline of a pasta, as the Kanoê serves it: movements per source, per day, per hour.

Measured live on 2026-09-10: `GET /api/timeline-pje/movimentacoes/fonte-dados?pastaId=`
names the sources the pasta has (one per instância), and
`POST /api/timeline-pje/movimentacoes?pastaId=&fonteDadosCodigo=` answers
`[{fonteDados, dias: [{data, horas: [{hora, movimentacoes: [{dataMovimento,
movimentosJudiciais, componentesDigitais}]}]}]}]`. The source has no limit
parameter, so this is the one collection whose limit is applied by Pink after
the observation: the rows are ordered from the most recent movement, the limit
keeps that many, and what stayed out is said in `Parcial`.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import date, datetime
from typing import Annotated, Any

import ibis
from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.artifacts import AMOSTRA, ArtifactStore
from pink.domain_types import Limite, PastaId
from pink.integrations import Kanoe
from pink.models import (
    Ausente,
    Colecao,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observado,
    Parcial,
    PinkModel,
    ResultadoColecao,
)
from pink.system import Runtime
from pink.write_safety import RemoteObservationFailure

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class TimelineFiltro(PinkModel):
    pasta_id: PastaId
    fonte: str | None = Field(
        default=None,
        description="Código da fonte de dados (a instância), ex.: `TJRO_APRESENTACAO_SG`; omitido, todas as fontes da pasta",
    )


class MovimentoTimeline(PinkModel):
    fonte_codigo: str = Field(description="Código da fonte de dados (instância) do movimento")
    fonte_nome: str = Field(description="Nome do tribunal/instância da fonte")
    data: date = Field(description="Dia do movimento")
    hora: str = Field(description="Hora do movimento, como a timeline agrupa (HH:MM)")
    data_movimento: datetime | None = Field(
        default=None, description="Instante do movimento informado pela fonte"
    )
    movimento: str | None = Field(
        default=None,
        description="Movimento judicial registrado (nome), quando o item é um movimento",
    )
    componente_id: int | None = Field(
        default=None, description="Componente digital juntado, quando o item é um documento"
    )
    componente_nome: str | None = Field(default=None, description="Nome do documento juntado")
    componente_tem_resumo: bool | None = Field(
        default=None, description="Se o Kanoê já tem resumo para o componente (ver `resumo_obter`)"
    )


class TimelineListagem(ResultadoColecao[MovimentoTimeline]):
    """Resultado Pydantic concreto da timeline do PJe de uma pasta."""


SCHEMA = ibis.schema(
    {
        "fonte_codigo": "string",
        "fonte_nome": "string",
        "data": "date",
        "hora": "string",
        "data_movimento": "timestamp",
        "movimento": "string",
        "componente_id": "int64",
        "componente_nome": "string",
        "componente_tem_resumo": "boolean",
    }
)


def achatar(fontes: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """One row per judicial movement or per attached document, in the source's nesting order."""
    linhas: list[dict[str, Any]] = []
    for fonte in fontes:
        dados = fonte.get("fonteDados") or {}
        codigo, nome = str(dados.get("codigo") or ""), str(dados.get("nome") or "")
        for dia in fonte.get("dias") or []:
            for hora in dia.get("horas") or []:
                for mov in hora.get("movimentacoes") or []:
                    base = {
                        "fonte_codigo": codigo,
                        "fonte_nome": nome,
                        "data": dia.get("data"),
                        "hora": str(hora.get("hora") or ""),
                        "data_movimento": mov.get("dataMovimento"),
                    }
                    itens = 0
                    for judicial in mov.get("movimentosJudiciais") or []:
                        linhas.append({**base, "movimento": judicial.get("nome")})
                        itens += 1
                    for comp in mov.get("componentesDigitais") or []:
                        linhas.append(
                            {
                                **base,
                                "componente_id": comp.get("id"),
                                "componente_nome": comp.get("nome"),
                                "componente_tem_resumo": comp.get("hasResumo"),
                            }
                        )
                        itens += 1
                    if not itens:
                        linhas.append(base)
    return linhas


def build_timeline_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_kanoe() -> Kanoe:
        return runtime.kanoe

    def get_artifacts() -> ArtifactStore:
        return runtime.artifacts

    @catalogo.operacao(
        nome="timeline_listar",
        tags={"timeline", "pasta", "processo", "read", "parquet"},
        efeito=READ,
    )
    async def timeline_listar(
        limite: Limite,
        filtro: Annotated[
            TimelineFiltro, Field(description="A pasta e, opcionalmente, a fonte (instância)")
        ],
    ) -> TimelineListagem:
        """Lista a timeline do PJe de uma pasta (movimentos e documentos juntados), pela API do Kanoê.

        A fonte não pagina: os movimentos mais recentes vêm primeiro e o limite
        corta a seleção depois da observação; o que ficou fora é dito em `Parcial`.
        Não depende do Metabase.
        """
        kanoe = get_kanoe()
        artifacts = get_artifacts()
        status = await kanoe.probe()
        if status.estado is Disponibilidade.INDISPONIVEL:
            return TimelineListagem(
                dados=Indisponivel(fonte=Fonte.KANOE, motivo=status.detalhe or "Kanoê indisponível")
            )
        try:
            fontes = await kanoe.timeline_fontes(filtro.pasta_id)
            escolhidas = [f for f in fontes if filtro.fonte is None or f.codigo == filtro.fonte]
            if filtro.fonte is not None and not escolhidas:
                return TimelineListagem(
                    dados=Ausente(
                        fonte=Fonte.KANOE,
                        motivo=(
                            f"a pasta {filtro.pasta_id} não tem a fonte {filtro.fonte!r}; "
                            f"fontes observadas: {', '.join(f.codigo for f in fontes) or 'nenhuma'}"
                        ),
                    )
                )
            brutos: list[Mapping[str, Any]] = []
            for fonte in escolhidas:
                brutos.extend(await kanoe.timeline_movimentacoes(filtro.pasta_id, fonte.codigo))
        except RemoteObservationFailure as exc:
            return TimelineListagem(dados=Indisponivel(fonte=Fonte.KANOE, motivo=str(exc)))
        linhas = achatar(brutos)
        linhas.sort(key=lambda x: (str(x.get("data") or ""), x.get("hora") or ""), reverse=True)
        selecao = linhas[:limite]
        dataset, itens = artifacts.publish_parquet(
            rows=selecao, model=MovimentoTimeline, schema=SCHEMA
        )
        colecao = Colecao[MovimentoTimeline](
            total=len(itens), amostra=itens[:AMOSTRA], dataset=dataset
        )
        if len(linhas) > limite:
            return TimelineListagem(
                dados=Parcial(
                    valor=colecao,
                    ausente=(
                        f"{len(linhas) - limite} movimento(s) mais antigo(s) que o {limite}º: "
                        "a fonte entrega a timeline inteira e o limite cortou depois da "
                        "observação; aumente o limite ou filtre por fonte",
                    ),
                )
            )
        return TimelineListagem(dados=Observado(valor=colecao))

    return catalogo
