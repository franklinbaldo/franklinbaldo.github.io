"""Typed peticionamento lifecycle observation for Pink 0.8."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import Field, TypeAdapter, model_validator

from pink.catalogo import Catalogo, Efeito
from pink.domain_types import ComponenteDigitalId, DocumentoId, ProtocoloId
from pink.integrations import Metabase
from pink.models import (
    Ausente,
    Disponibilidade,
    Fonte,
    Indisponivel,
    Observacao,
    Observado,
    PinkModel,
)
from pink.queries_peticionamento import documento_existe, peticionamentos_for_documento
from pink.system import Runtime

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


class EstadoPeticionamento(StrEnum):
    NAO_PETICIONADO = "nao_peticionado"
    PROCESSANDO = "processando"
    PROTOCOLADO = "protocolado"
    FALHOU = "falhou"
    DESCONHECIDO = "desconhecido"


class TentativaPeticionamento(PinkModel):
    protocolo_id: ProtocoloId
    componente_digital_id: ComponenteDigitalId
    documento_id: DocumentoId
    status_codigo: int = Field(description="Código de status observado na fonte de protocolo")
    estado: EstadoPeticionamento = Field(description="Estado semântico derivado do status remoto")
    mensagem: str | None = Field(default=None, description="Mensagem remota associada à tentativa")
    destino: str | None = Field(default=None, description="Destino do protocolo quando informado")
    etapa_falha: int | None = Field(
        default=None, description="Etapa remota de falha quando informada"
    )
    recibo_componente_id: ComponenteDigitalId | None = Field(
        default=None,
        description="Componente digital do recibo quando já materializado",
    )
    recibo_documento_id: DocumentoId | None = Field(
        default=None,
        description="Documento do recibo quando já materializado",
    )
    recibo_hash: str | None = Field(default=None, description="Hash observado do recibo")
    recibo_file_name: str | None = Field(
        default=None, description="Nome de arquivo observado do recibo"
    )
    criado_em: datetime = Field(description="Instante de criação da tentativa")
    atualizado_em: datetime | None = Field(default=None, description="Última atualização observada")
    recibo_resource_uri: str | None = Field(
        default=None,
        description="URI de recurso do recibo quando o componente digital já foi observado",
    )

    @model_validator(mode="before")
    @classmethod
    def derive_recibo_resource_uri(cls, value: Any) -> Any:
        """Derive the receipt Resource URI and reject a conflicting supplied value."""
        if not isinstance(value, dict):
            return value
        componente_id = value.get("recibo_componente_id")
        expected = (
            f"pink://documento/componente/{componente_id}" if componente_id is not None else None
        )
        supplied = value.get("recibo_resource_uri")
        if supplied is not None and supplied != expected:
            raise ValueError("recibo_resource_uri diverge de recibo_componente_id")
        return {**value, "recibo_resource_uri": expected}


class Peticionamento(PinkModel):
    documento_id: DocumentoId
    estado: EstadoPeticionamento = Field(
        description="Estado atual derivado da tentativa cronologicamente mais recente, ou nao_peticionado sem tentativas"
    )
    acompanhamento_ok: bool = Field(
        description="True somente quando a tentativa atual está protocolada e possui recibo observável"
    )
    tentativa_atual: TentativaPeticionamento | None = Field(
        default=None,
        description="Tentativa cronologicamente mais recente, quando existe",
    )
    tentativas: list[TentativaPeticionamento] = Field(
        default_factory=list,
        description="Tentativas em ordem cronológica, da mais antiga para a mais recente",
    )


class PeticionamentoResultado(PinkModel):
    dados: Observacao[Peticionamento] = Field(
        description="Ciclo de peticionamento observado no Metabase, ou estado explícito de ausência/indisponibilidade"
    )


def _estado(status: int) -> EstadoPeticionamento:
    return {
        1: EstadoPeticionamento.PROCESSANDO,
        2: EstadoPeticionamento.PROTOCOLADO,
        3: EstadoPeticionamento.FALHOU,
    }.get(status, EstadoPeticionamento.DESCONHECIDO)


async def _obter(metabase: Metabase, documento_id: DocumentoId) -> PeticionamentoResultado:
    status = await metabase.probe()
    if status.estado is Disponibilidade.INDISPONIVEL:
        return PeticionamentoResultado(
            dados=Indisponivel(
                fonte=Fonte.METABASE, motivo=status.detalhe or "Metabase indisponível"
            )
        )

    if not await metabase.rows(documento_existe(documento_id)):
        return PeticionamentoResultado(
            dados=Ausente(
                fonte=Fonte.METABASE,
                motivo=f"documento {documento_id} não encontrado entre os documentos ativos",
            )
        )

    rows = await metabase.rows(peticionamentos_for_documento(documento_id))
    attempts = TypeAdapter(list[TentativaPeticionamento]).validate_python(
        [{**row, "estado": _estado(int(row["status_codigo"]))} for row in rows]
    )
    current = attempts[-1] if attempts else None
    current_state = current.estado if current is not None else EstadoPeticionamento.NAO_PETICIONADO
    acompanhamento_ok = bool(
        current is not None
        and current.estado is EstadoPeticionamento.PROTOCOLADO
        and current.recibo_componente_id is not None
    )
    return PeticionamentoResultado(
        dados=Observado(
            valor=Peticionamento(
                documento_id=documento_id,
                estado=current_state,
                acompanhamento_ok=acompanhamento_ok,
                tentativa_atual=current,
                tentativas=attempts,
            )
        )
    )


def build_peticionamento_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_metabase() -> Metabase:
        return runtime.metabase

    @catalogo.operacao(
        nome="peticionamento_obter",
        tags={"peticionamento", "read"},
        efeito=READ,
    )
    async def peticionamento_obter(
        documento_id: DocumentoId,
    ) -> PeticionamentoResultado:
        """Observa o ciclo de protocolo somente depois de provar que o documento existe."""
        metabase = get_metabase()
        return await _obter(metabase, documento_id)

    return catalogo
