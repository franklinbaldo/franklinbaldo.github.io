"""System capability catalogo for Pink 0.8."""

from __future__ import annotations

from dataclasses import dataclass, field


from pink.catalogo import Catalogo, Efeito
from pink.artifacts import ArtifactStore
from pink.integrations import Kanoe, Metabase, Probe
from pink.models import RuntimeContext, SystemStatus
from pink.system_logic import observe_status

READ = Efeito(leitura=True, idempotente=True, mundo_aberto=True)


@dataclass(frozen=True)
class Runtime:
    """Explicit external runtime dependencies for one Pink server instance."""

    metabase: Metabase
    kanoe: Kanoe
    google: Probe
    artifacts: ArtifactStore = field(default_factory=ArtifactStore.temporary)
    contexto: RuntimeContext = field(default_factory=RuntimeContext)


def build_system_catalogo(runtime: Runtime) -> Catalogo:
    """Build the system catalogo with request-time DI over explicit runtime objects."""
    catalogo = Catalogo()

    def get_runtime() -> Runtime:
        return runtime

    @catalogo.operacao(
        nome="status",
        tags={"system", "read"},
        efeito=READ,
    )
    async def status() -> SystemStatus:
        """Report effective non-secret context plus material integration availability."""
        injected = get_runtime()
        return await observe_status(
            metabase=injected.metabase,
            kanoe=injected.kanoe,
            google=injected.google,
            contexto=injected.contexto,
        )

    return catalogo
