"""Composable Ibis expressions over Pink 0.8's physical schema knowledge."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date, timedelta

from ibis.expr import types as ir

from pink import schema


def pastas_filter(
    *,
    setor_ids: Sequence[int] | ir.IntegerColumn | None = None,
    processo: str | None = None,
    caixa_id: int | None = None,
    com_tarefa: bool | None = None,
    com_caixa: bool | None = None,
    com_corrente: bool | None = None,
    prazo_ate: date | None = None,
    ordenar_por: str = "prazo",
):
    """Physical-query implementation behind the `pasta_listar` capability."""
    p = schema.pastas
    s = schema.setores
    pj = schema.processos_jud
    e = schema.expedientes
    t = schema.tarefas
    c = schema.caixas
    cp = schema.caixas_pastas
    ct = schema.corrente_tematica
    pct = schema.pastas_corrente_tematica

    pastas_ativas = p.filter(p.apagado_em.isnull())
    if setor_ids is not None:
        # Ids literais, resolvidos antes (`pink.setores`): com a sigla no predicado
        # o MySQL varria `pastas` inteira e materializava cada agregado sobre a
        # base inteira; com o id constante ele dirige por `setores_id` e os
        # agregados ficam restritos às pastas do setor -- 4 s -> 0,2 s, medido.
        pastas_ativas = pastas_ativas.filter(p.setores_id.isin(setor_ids))
        pastas_da_selecao = pastas_ativas.select(pasta_id=p.id)
        e = e.filter(e.pastas_id.isin(pastas_da_selecao.pasta_id))
        t = t.filter(t.pastas_id.isin(pastas_da_selecao.pasta_id))
        cp = cp.filter(cp.pastas_id.isin(pastas_da_selecao.pasta_id))
        pct = pct.filter(pct.pastas_id.isin(pastas_da_selecao.pasta_id))

    open_exp_agg = (
        e.filter(e.fechado == 0)
        .group_by(e.pastas_id)
        .aggregate(
            n_expedientes_abertos=e.id.count(),
            proximo_prazo=e.prazo.min().cast("date"),
        )
    )
    open_exp = open_exp_agg.select(
        exp_pasta_id=open_exp_agg.pastas_id,
        n_expedientes_abertos=open_exp_agg.n_expedientes_abertos,
        proximo_prazo=open_exp_agg.proximo_prazo,
    )

    open_tar_agg = (
        t.filter(t.apagado_em.isnull() & t.data_hora_conclusao_prazo.isnull())
        .group_by(t.pastas_id)
        .aggregate(n_tarefas_abertas=t.id.count())
    )
    open_tar = open_tar_agg.select(
        tar_pasta_id=open_tar_agg.pastas_id,
        n_tarefas_abertas=open_tar_agg.n_tarefas_abertas,
    )

    # Projetar antes de agregar: agrupar por `cp.pastas_id` e reduzir `c.id`
    # referencia as tabelas de origem, não a relação que o join produziu, e o
    # DuckDB reprova isso com "Referenced table not found". Renomear as colunas
    # depois do agregado não resolve, porque o problema está dentro dele.
    caixas_ativas = cp.inner_join(
        c, [cp.caixas_id == c.id, c.apagado_em.isnull(), c.ativo == 1]
    ).select(pastas_id=cp.pastas_id, caixa_id=c.id)
    active_caixa_agg = caixas_ativas.group_by(caixas_ativas.pastas_id).aggregate(
        caixa_id=caixas_ativas.caixa_id.max()
    )
    active_caixa = active_caixa_agg.select(
        caixa_pasta_id=active_caixa_agg.pastas_id,
        caixa_id=active_caixa_agg.caixa_id,
    )

    correntes_ativas = pct.inner_join(
        ct,
        [
            pct.corrente_tematica_id == ct.id,
            ct.apagado_em.isnull(),
            ct.ativo == 1,
        ],
    ).select(pastas_id=pct.pastas_id, corrente_id=ct.id)
    active_corrente_agg = correntes_ativas.group_by(correntes_ativas.pastas_id).aggregate(
        n_correntes=correntes_ativas.corrente_id.nunique()
    )

    active_corrente = active_corrente_agg.select(
        corrente_pasta_id=active_corrente_agg.pastas_id,
        n_correntes=active_corrente_agg.n_correntes,
    )

    active_pasta = pastas_ativas.select(
        pasta_id=p.id,
        processo_id=p.processos_judiciais_id,
        setor_id=p.setores_id,
        setor_responsavel_etiqueta_id=p.setor_responsavel_etiqueta,
        atividade_em=p.atualizado_em,
    )
    sector = s.select(setor_id=s.id, setor=s.sigla)
    process = pj.select(processo_id=pj.id, numero=pj.numero)

    pasta_sector = active_pasta.inner_join(sector, active_pasta.setor_id == sector.setor_id).select(
        active_pasta,
        setor=sector.setor,
    )
    base = pasta_sector.left_join(process, pasta_sector.processo_id == process.processo_id).select(
        pasta_id=pasta_sector.pasta_id,
        numero=process.numero,
        setor=pasta_sector.setor,
        setor_responsavel_etiqueta_id=pasta_sector.setor_responsavel_etiqueta_id,
        atividade_em=pasta_sector.atividade_em,
    )

    responsavel = s.select(
        responsavel_id=s.id,
        setor_responsavel_etiqueta_sigla=s.sigla,
        setor_responsavel_etiqueta_nome=s.nome,
        setor_responsavel_etiqueta_cnpj=s.cnpj,
    )
    base = base.left_join(
        responsavel, base.setor_responsavel_etiqueta_id == responsavel.responsavel_id
    ).select(
        base,
        responsavel.setor_responsavel_etiqueta_sigla,
        responsavel.setor_responsavel_etiqueta_nome,
        responsavel.setor_responsavel_etiqueta_cnpj,
    )
    q = base.left_join(open_exp, base.pasta_id == open_exp.exp_pasta_id).select(
        base,
        n_expedientes_abertos=open_exp.n_expedientes_abertos.fill_null(0),
        proximo_prazo=open_exp.proximo_prazo,
    )
    q = q.left_join(open_tar, q.pasta_id == open_tar.tar_pasta_id).select(
        q,
        n_tarefas_abertas=open_tar.n_tarefas_abertas.fill_null(0),
    )
    q = q.left_join(active_caixa, q.pasta_id == active_caixa.caixa_pasta_id).select(
        q,
        caixa_id=active_caixa.caixa_id,
    )
    q = q.left_join(active_corrente, q.pasta_id == active_corrente.corrente_pasta_id).select(
        q,
        n_correntes=active_corrente.n_correntes.fill_null(0),
    )

    if processo is not None:
        q = q.filter(q.numero == processo)
    if caixa_id is not None:
        q = q.filter(q.caixa_id == caixa_id)
    if com_tarefa is not None:
        condition = q.n_tarefas_abertas > 0
        q = q.filter(condition if com_tarefa else ~condition)
    if com_caixa is not None:
        condition = q.caixa_id.notnull()
        q = q.filter(condition if com_caixa else ~condition)
    if com_corrente is not None:
        condition = q.n_correntes > 0
        q = q.filter(condition if com_corrente else ~condition)
    if prazo_ate is not None:
        q = q.filter(q.proximo_prazo.notnull() & (q.proximo_prazo <= prazo_ate))

    if ordenar_por == "atividade":
        return q.order_by(q.atividade_em.desc(nulls_first=False), q.pasta_id.asc())
    return q.order_by(q.proximo_prazo.asc(nulls_first=False), q.pasta_id.asc())


def tarefas_filter(
    *,
    setor_ids: Sequence[int] | ir.IntegerColumn | None = None,
    processo: str | None = None,
    pasta_id: int | None = None,
    usuario_id: int | None = None,
    aberta: bool | None = True,
    prazo_de: date | None = None,
    prazo_ate: date | None = None,
    especie_id: int | None = None,
):
    """Filter task collection against the physical Caipora tables."""
    t = schema.tarefas
    p = schema.pastas
    s = schema.setores
    pj = schema.processos_jud
    et = schema.especies_tarefas

    pastas_ativas = p.filter(p.apagado_em.isnull())
    if setor_ids is not None:
        # Id literal, resolvido antes (`pink.setores`), para o MySQL dirigir por
        # `pastas.setores_id` em vez de varrer `pastas` -- 3,8 s -> 0,1 s, medido.
        pastas_ativas = pastas_ativas.filter(p.setores_id.isin(setor_ids))

    q = (
        t.filter(t.apagado_em.isnull())
        .inner_join(pastas_ativas, t.pastas_id == pastas_ativas.id)
        .inner_join(s, pastas_ativas.setores_id == s.id)
        .left_join(pj, pastas_ativas.processos_judiciais_id == pj.id)
        .left_join(et, t.especies_tarefas_id == et.id)
        .select(
            tarefa_id=t.id,
            pasta_id=pastas_ativas.id,
            setor=s.sigla,
            numero=pj.numero,
            titulo=et.nome,
            urgente=t.urgente.cast("boolean"),
            prazo=t.data_hora_final_prazo,
            concluida_em=t.data_hora_conclusao_prazo,
            criado_em=t.criado_em,
            especie_id=t.especies_tarefas_id,
            usuario_id=t.usuarios_responsavel_id,
        )
    )

    if processo is not None:
        q = q.filter(q.numero == processo)
    if pasta_id is not None:
        q = q.filter(q.pasta_id == pasta_id)
    if usuario_id is not None:
        q = q.filter(q.usuario_id == usuario_id)
    if aberta is True:
        q = q.filter(q.concluida_em.isnull())
    elif aberta is False:
        q = q.filter(q.concluida_em.notnull())
    if especie_id is not None:
        q = q.filter(q.especie_id == especie_id)
    if prazo_de is not None:
        q = q.filter(q.prazo >= prazo_de)
    if prazo_ate is not None:
        q = q.filter(q.prazo < prazo_ate + timedelta(days=1))

    return q.order_by(q.concluida_em.isnull().desc(), q.prazo, q.tarefa_id)


def tarefa_detail(tarefa_id: int):
    """Single task with pasta/process/species/status context."""
    t = schema.tarefas
    p = schema.pastas
    s = schema.setores
    responsavel = schema.setores.view()
    pj = schema.processos_jud
    et = schema.especies_tarefas
    st = schema.status_tarefa
    d = schema.documentos

    return (
        t.filter((t.id == tarefa_id) & t.apagado_em.isnull())
        .inner_join(p, [t.pastas_id == p.id, p.apagado_em.isnull()])
        .inner_join(s, p.setores_id == s.id)
        .left_join(responsavel, t.setores_responsavel_id == responsavel.id)
        .left_join(pj, p.processos_judiciais_id == pj.id)
        .left_join(et, t.especies_tarefas_id == et.id)
        .left_join(st, t.status_tarefa_id == st.id)
        .left_join(d, t.documentos_id == d.id)
        .select(
            tarefa_id=t.id,
            titulo=et.nome,
            descricao=et.descricao,
            status=st.descricao,
            urgente=t.urgente.cast("boolean"),
            post_it=t.post_it,
            prazo_inicio=t.data_hora_inicio_prazo,
            prazo=t.data_hora_final_prazo,
            concluida_em=t.data_hora_conclusao_prazo,
            criado_em=t.criado_em,
            pasta_id=p.id,
            setor_pasta=s.sigla,
            setor_responsavel=responsavel.sigla,
            processo_id=pj.id,
            numero=pj.numero,
            expediente_id=t.expediente_id,
            documento_id=t.documentos_id,
            documento_autor=d.autor,
        )
    )


def comentarios_for_tarefa(tarefa_id: int):
    c = schema.comentarios_tarefa
    return (
        c.filter(c.tarefa_id == tarefa_id)
        .select(
            comentario_id=c.id,
            comentario=c.comentario,
            criado_em=c.criado_em,
            criado_por=c.criado_por,
        )
        .order_by(c.criado_em)
    )


def historicos_for_tarefa(tarefa_id: int):
    h = schema.historicos_tarefa
    return (
        h.filter(h.tarefa_id == tarefa_id)
        .select(
            historico_id=h.id,
            descricao=h.descricao,
            acao=h.acao,
            criado_em=h.criado_em,
            comentario_tarefa_id=h.comentario_tarefa_id,
        )
        .order_by(h.criado_em)
    )


def etiquetas_for_tarefa(tarefa_id: int):
    te = schema.tarefas_etiquetas
    e = schema.etiquetas
    return (
        te.filter([te.tarefas_id == tarefa_id, te.apagado_em.isnull()])
        .inner_join(e, [te.etiquetas_id == e.id, e.apagado_em.isnull()])
        .select(etiqueta_id=e.id, nome=e.nome)
        .order_by(e.nome)
    )
