CREATE TABLE "Expediente" (
    title VARCHAR,
    pasta_id BIGINT,
    expediente_id BIGINT,
    cnj VARCHAR,
    tipo_kanoe BIGINT,
    prazo_kanoe TIMESTAMPTZ,
    fechado BOOLEAN,
    criado_em TIMESTAMPTZ,
    n_comentarios_kanoe BIGINT,
    resumo VARCHAR,
    estado VARCHAR,
    estado_desde TIMESTAMPTZ,
    responsavel VARCHAR,
    revisor VARCHAR,
    triado_em TIMESTAMPTZ,
    proxima_acao VARCHAR,
    proxima_acao_em DATE,
    prazo_oficial_observado VARCHAR,
    prazo_verificado_em TIMESTAMPTZ,
    prazo_fonte VARCHAR,
    entregaveis VARCHAR[],
    resultado_resumo VARCHAR
);

COMMENT ON TABLE "Expediente" IS 'Um arquivo por expediente do Kanoê: observação escrita pelo Pink e trabalho interno escrito pelo setor.';
COMMENT ON COLUMN "Expediente".prazo_kanoe IS 'Prazo como o Kanoê registra, sem conferência.';
COMMENT ON COLUMN "Expediente".prazo_oficial_observado IS 'Data ou instante preservado como observado na fonte oficial.';
