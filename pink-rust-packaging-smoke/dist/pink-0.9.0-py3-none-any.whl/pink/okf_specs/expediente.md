---
type: Spec
title: SPEC — Expediente
description: "Contrato do conceito OKF Expediente: a observação do Kanoê escrita pelo Pink e o trabalho interno escrito pelo setor, num arquivo por expediente."
timestamp: 2026-09-24T18:00:00-04:00
---

# SPEC — `Expediente`

`Expediente` é o registro versionado de um expediente do Kanoê: a comunicação
que chegou ao setor, com prazo, e o trabalho interno que ela exige até ser
resolvida. Um arquivo por expediente. Ele não substitui o Kanoê nem a tarefa
oficial, e não cria prazo processual.

Este contrato é publicado pelo Pink (`pink okf specs --destino <dir>`). O
repositório consumidor o copia e o valida; não o edita.

## Identidade

A identidade é `pasta_id` + `expediente_id`, lida do frontmatter. Diretório e
nome do arquivo (`<pasta_id>/<AAAA-MM-DD>-<expediente_id>.md`) são convenção de
organização e nunca são usados para inferir se um expediente já foi
materializado. Quando o tribunal comunica o mesmo ato por canais distintos, há
um expediente para cada canal e, portanto, um arquivo para cada.

## Quem escreve cada campo

Dois escritores dividem o arquivo, e cada um só toca os seus campos.

| Escritor                                     | Campos                                                                                                                                                                                                                                              |
| -------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Pink** (`pink okf expedientes`)            | `type`, `title`, `pasta_id`, `expediente_id`, `cnj`, `tipo_kanoe`, `prazo_kanoe`, `fechado`, `criado_em`, `n_comentarios_kanoe`, e a seção `## Teor`                                                                                                |
| **Setor** (pessoa ou agente, e suas rotinas) | `resumo`, `estado`, `estado_desde`, `responsavel`, `revisor`, `triado_em`, `proxima_acao`, `proxima_acao_em`, `prazo_oficial_observado`, `prazo_verificado_em`, `prazo_fonte`, `bloqueio`, `entregaveis`, `resultado_resumo`, e o restante do corpo |

A escrita do Pink é idempotente: num arquivo existente, só troca as linhas dos
seus campos cujo valor mudou, e deixa o resto byte a byte. `title`,
`criado_em`, `pasta_id` e `expediente_id` são imutáveis e só entram quando
ausentes. O Pink também atualiza o expediente que fechou desde a última rodada
(`fechado: true`), porque ele sai da seleção de abertos.

`prazo_kanoe` é o prazo como o Kanoê registra, sem conferência. O prazo
conferido na fonte oficial, com data e fonte da verificação, é
`prazo_oficial_observado`, escrito pelo setor.

## Estados

O campo `estado`, do setor, aceita exatamente:

1. `triado` — demanda compreendida e ainda não puxada;
2. `fazendo` — execução ativa;
3. `revisao` — entrega submetida a revisão;
4. `pronto_para_ato` — ato pronto e aguardando decisão ou assinatura;
5. `confirmacao` — ato praticado, aguardando confirmação na fonte oficial;
6. `concluido` — resultado confirmado;
7. `cancelado` — providência deixou de ser necessária, com justificativa.

Expediente sem `estado` é a fila de entrada: materializado, ainda não lido.
Bloqueio não é estado; um expediente bloqueado permanece na coluna.

## Frontmatter

```yaml
---
# Pink
type: Expediente
title: <string>
pasta_id: <int>
expediente_id: <int>
cnj: <NNNNNNN-DD.AAAA.J.TR.OOOO>   # quando a pasta tem processo vinculado
tipo_kanoe: <int>                  # código do tipo do expediente no Kanoê
prazo_kanoe: <ISO 8601 com fuso>   # prazo como o Kanoê registra
fechado: <bool>
criado_em: <ISO 8601 com fuso>     # imutável
n_comentarios_kanoe: <int>
# Setor
resumo: <id de Resumo>             # exigido quando há `estado`
estado: <enum dos sete estados>
estado_desde: <ISO 8601 com fuso>
responsavel: <identidade interna>
revisor: <identidade interna>      # obrigatório em revisao
triado_em: <ISO 8601 com fuso>     # imutável depois de gravado
proxima_acao: <string>             # ausente apenas em estado terminal
proxima_acao_em: <date>
prazo_oficial_observado: <date ou datetime>
prazo_verificado_em: <ISO 8601 com fuso>
prazo_fonte: <string>
bloqueio:
  motivo: <string>
  desde: <ISO 8601 com fuso>
  depende_de: <string>
  responsavel_cobranca: <identidade interna>
  revisar_em: <date>
  contingencia: <string>
  prazo_correndo: <bool>
  prazo_correndo_fonte: <string>
entregaveis: [<string>]
resultado_resumo: <string>         # obrigatório em concluido/cancelado
---
```

Os horários do Pink seguem a convenção já adotada pelo consumidor: o relógio
que a fonte devolve, com o fuso do setor (`-04:00`).

## Corpo

O corpo começa pela seção `## Teor`, escrita pelo Pink **uma vez**, quando o
arquivo é criado. O teor de um expediente não muda depois de criado; por isso
ele é versionado de forma incremental, um expediente por vez, e nunca como
história inteira do processo. Arquivo criado antes desta regra pode não ter a
seção.

Depois do teor, o corpo é do setor: raciocínio, justificativa e notas de
trabalho escritos por pessoa ou agente. Automação não escreve ali placeholders,
avisos, headings vazios ou repetição do frontmatter.

## Transições e relógios

Ao mudar `estado`, atualiza-se `estado_desde`. Ao abrir ou refazer um bloqueio,
`bloqueio.desde` registra o início atual.

- idade no estágio = agora − `estado_desde`;
- duração do bloqueio = agora − `bloqueio.desde`;
- lead time = `estado_desde` final − `triado_em`;
- prazo oficial restante = `prazo_oficial_observado` − agora, quando há fonte verificada.

## Validação estrutural

O consumidor reprova:

- YAML/OKF inválido, campo obrigatório ausente ou enum desconhecido;
- identidade interna desconhecida;
- combinação condicional inválida, como `prazo_oficial_observado` sem fonte ou
  estado terminal sem resultado;
- data/hora sem formato ou fuso exigido;
- `expediente_id` duplicado no corpus;
- `resumo` ausente no expediente que declara `estado`, ou que não resolva para
  exatamente um conceito `Resumo`.

Do expediente na fila de entrada exigem-se apenas os campos do Pink.

## Fonte de verdade

Kanoê, SEI, PJe e publicações oficiais continuam soberanos para atos, ciência e
prazos. Concluir o trabalho sem conferir a fonte é proibido, e concluir não
fecha o expediente no Kanoê.
