"""Guarded Kanoê writes for pasta organization and tramitação."""

from __future__ import annotations

from dataclasses import replace
from typing import Annotated

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.caixa_state_resource import caixa_busca_handle
from pink.domain_types import (
    CaixaId,
    CorrenteTematicaId,
    PastaId,
    SetorId,
    SetorSigla,
    TextoNaoVazio,
    TramitacaoId,
)
from pink.integrations import Kanoe
from pink.setor_config import TomlSetor
from pink.models import (
    Ambigua,
    Confirmada,
    EfeitoEscrita,
    EfeitosEmLote,
    PinkModel,
    Recusada,
    Submetida,
)
from pink.system import Runtime
from pink.write_safety import (
    RemoteObservationFailure,
    RemoteWriteFailure,
    observe_precondition,
    refuse_if_unavailable,
    write_and_confirm,
)

WRITE = Efeito(
    leitura=False,
    destrutivo=False,
    idempotente=False,
    mundo_aberto=True,
)
DESTRUCTIVE = replace(WRITE, destrutivo=True)
IDEMPOTENT_WRITE = replace(WRITE, idempotente=True)
IDEMPOTENT_DESTRUCTIVE = replace(IDEMPOTENT_WRITE, destrutivo=True)


class AnotacaoEmLote(PinkModel):
    pasta_id: PastaId
    anotacao_base: str | None = Field(
        description="Anotação observada antes da edição; None representa ausência observada"
    )
    texto: TextoNaoVazio


def _fora_do_plano_basico(texto: str) -> bool:
    """Characters beyond U+FFFF (emoji) break the batch endpoint with a 500 -- measured live."""
    return any(ord(c) > 0xFFFF for c in texto)


def build_pasta_write_catalogo(runtime: Runtime) -> Catalogo:
    catalogo = Catalogo()

    def get_kanoe() -> Kanoe:
        return runtime.kanoe

    @catalogo.operacao(
        nome="pasta_anotar_lote",
        tags={"pasta", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def pasta_anotar_lote(
        itens: Annotated[
            list[AnotacaoEmLote],
            Field(
                min_length=1,
                description="Uma anotação por pasta, cada uma com a base observada; o lote inteiro é recusado se uma base divergir",
            ),
        ],
    ) -> EfeitosEmLote:
        """Substitui a anotação de várias pastas numa só chamada, cada uma guardada pela sua base.

        O gesto da triagem: anotar muitas pastas de uma vez. Nenhuma escrita
        acontece se qualquer base divergir ou se um texto tiver caractere fora
        do plano básico (emoji), que o endpoint em lote do Kanoê rejeita
        (medido em 2026-09-10).
        """
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="pasta_anotar_lote", nome="Kanoê")
        if unavailable is not None:
            return EfeitosEmLote(efeitos=[unavailable for _ in itens])
        ids = [item.pasta_id for item in itens]
        if len(set(ids)) != len(ids):
            return EfeitosEmLote(
                efeitos=[
                    Recusada(operacao="pasta_anotar_lote", motivo="pasta repetida no lote")
                    for _ in itens
                ]
            )
        recusas: dict[int, str] = {}
        atuais: dict[int, str | None] = {}
        for item in itens:
            if _fora_do_plano_basico(item.texto):
                recusas[item.pasta_id] = (
                    "o endpoint em lote do Kanoê rejeita caracteres fora do plano básico (emoji)"
                )
                continue
            observado = await observe_precondition(
                operacao="pasta_anotar_lote",
                observe=lambda pasta_id=item.pasta_id: kanoe.pasta_annotation(pasta_id),
            )
            if isinstance(observado, Recusada):
                recusas[item.pasta_id] = observado.motivo
                continue
            atuais[item.pasta_id] = observado
            if observado != item.anotacao_base:
                recusas[item.pasta_id] = (
                    "a anotação mudou desde a leitura-base; "
                    f"esperado {item.anotacao_base!r}, observado {observado!r}"
                )
        if recusas:
            return EfeitosEmLote(
                efeitos=[
                    Recusada(
                        operacao="pasta_anotar_lote",
                        motivo=recusas.get(
                            item.pasta_id, "lote recusado por outra pasta; nada foi escrito"
                        ),
                    )
                    for item in itens
                ]
            )
        pendentes = {
            item.pasta_id: item.texto for item in itens if atuais[item.pasta_id] != item.texto
        }
        if pendentes:
            try:
                await kanoe.set_pasta_annotations(pendentes)
            except RemoteWriteFailure as exc:
                if not exc.effect_may_have_occurred:
                    raise
                return EfeitosEmLote(
                    efeitos=[
                        Ambigua(
                            operacao="pasta_anotar_lote",
                            handle=f"kanoe:pasta:{item.pasta_id}:anotacao",
                            detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                        )
                        for item in itens
                    ]
                )
        efeitos: list[EfeitoEscrita] = []
        for item in itens:
            if item.pasta_id not in pendentes:
                efeitos.append(
                    Confirmada(
                        operacao="pasta_anotar_lote",
                        recurso_id=item.pasta_id,
                        detalhe="a anotação observada já era exatamente o texto desejado",
                    )
                )
                continue
            handle = f"kanoe:pasta:{item.pasta_id}:anotacao"
            try:
                depois = await kanoe.pasta_annotation(item.pasta_id)
            except RemoteObservationFailure as exc:
                efeitos.append(
                    Submetida(
                        operacao="pasta_anotar_lote",
                        handle=handle,
                        detalhe=f"lote aceito; a reobservação falhou: {exc}",
                    )
                )
                continue
            if depois == item.texto:
                efeitos.append(Confirmada(operacao="pasta_anotar_lote", recurso_id=item.pasta_id))
            else:
                efeitos.append(
                    Submetida(
                        operacao="pasta_anotar_lote",
                        handle=handle,
                        detalhe=f"lote aceito, mas a anotação reobservada diverge: {depois!r}",
                    )
                )
        return EfeitosEmLote(efeitos=efeitos)

    @catalogo.operacao(
        nome="pasta_anotar",
        tags={"pasta", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def pasta_anotar(
        pasta_id: PastaId,
        texto: TextoNaoVazio,
        anotacao_base: Annotated[
            str | None,
            Field(
                description="Anotação observada antes da edição; None representa ausência observada"
            ),
        ],
    ) -> EfeitoEscrita:
        """Substitui a anotação somente se ela ainda for exatamente `anotacao_base`."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="pasta_anotar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        current = await observe_precondition(
            operacao="pasta_anotar",
            observe=lambda: kanoe.pasta_annotation(pasta_id),
        )
        if isinstance(current, Recusada):
            return current
        if current != anotacao_base:
            return Recusada(
                operacao="pasta_anotar",
                motivo=(
                    "a anotação mudou desde a leitura-base; "
                    f"esperado {anotacao_base!r}, observado {current!r}"
                ),
            )
        if current == texto:
            return Confirmada(
                operacao="pasta_anotar",
                recurso_id=pasta_id,
                detalhe="a anotação observada já é exatamente o texto desejado",
            )
        return await write_and_confirm(
            operacao="pasta_anotar",
            recurso_id=pasta_id,
            write=lambda: kanoe.set_pasta_annotation(pasta_id, texto),
            observe=lambda: kanoe.pasta_annotation(pasta_id),
            expected=texto,
            handle=f"kanoe:pasta:{pasta_id}:anotacao",
        )

    @catalogo.operacao(
        nome="pasta_caixa_definir",
        tags={"pasta", "caixa", "write"},
        efeito=IDEMPOTENT_WRITE,
    )
    async def pasta_caixa_definir(
        pasta_id: PastaId,
        setor: SetorSigla,
        caixa_id: CaixaId,
        caixa_base: Annotated[
            CaixaId | None,
            Field(description="Caixa observada antes da mudança; None representa pasta sem caixa"),
        ],
    ) -> EfeitoEscrita:
        """Move a pasta somente se a caixa observada no Kanoê ainda for `caixa_base`."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="pasta_caixa_definir", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        current = await observe_precondition(
            operacao="pasta_caixa_definir",
            observe=lambda: kanoe.pasta_organization(pasta_id, setor),
        )
        if isinstance(current, Recusada):
            return current
        if current.caixa_id != caixa_base:
            return Recusada(
                operacao="pasta_caixa_definir",
                motivo=f"a caixa mudou: esperado {caixa_base!r}, observado {current.caixa_id!r}",
            )
        if current.caixa_id == caixa_id:
            return Confirmada(
                operacao="pasta_caixa_definir",
                recurso_id=pasta_id,
                detalhe=f"a pasta já está na caixa desejada {caixa_id}",
            )
        return await write_and_confirm(
            operacao="pasta_caixa_definir",
            recurso_id=pasta_id,
            write=lambda: kanoe.set_pasta_box(pasta_id, caixa_id),
            observe=lambda: _observe_box(kanoe, pasta_id, setor),
            expected=caixa_id,
            handle=f"kanoe:pasta:{pasta_id}:organizacao:{setor}",
        )

    @catalogo.operacao(
        nome="pasta_correntes_atualizar",
        tags={"pasta", "corrente", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def pasta_correntes_atualizar(
        pasta_id: PastaId,
        setor: SetorSigla,
        corrente_ids: Annotated[
            tuple[CorrenteTematicaId, ...],
            Field(description="Conjunto exato de correntes temáticas desejado após a atualização"),
        ],
        correntes_base: Annotated[
            tuple[CorrenteTematicaId, ...],
            Field(
                description="Conjunto de correntes observado antes da edição; é uma precondition"
            ),
        ],
    ) -> EfeitoEscrita:
        """Define o conjunto exato de correntes com optimistic concurrency explícita."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="pasta_correntes_atualizar", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        desired = tuple(sorted(set(corrente_ids)))
        expected_base = tuple(sorted(set(correntes_base)))
        current = await observe_precondition(
            operacao="pasta_correntes_atualizar",
            observe=lambda: kanoe.pasta_organization(pasta_id, setor),
        )
        if isinstance(current, Recusada):
            return current
        if current.corrente_ids != expected_base:
            return Recusada(
                operacao="pasta_correntes_atualizar",
                motivo=(
                    f"as correntes mudaram: esperado {expected_base!r}, "
                    f"observado {current.corrente_ids!r}"
                ),
            )
        current_set = set(current.corrente_ids)
        desired_set = set(desired)
        adicionar = tuple(sorted(desired_set - current_set))
        remover = tuple(sorted(current_set - desired_set))
        if not adicionar and not remover:
            return Confirmada(
                operacao="pasta_correntes_atualizar",
                recurso_id=pasta_id,
                detalhe="o conjunto de correntes observado já corresponde exatamente ao desejado",
            )
        return await write_and_confirm(
            operacao="pasta_correntes_atualizar",
            recurso_id=pasta_id,
            write=lambda: kanoe.update_pasta_correntes(pasta_id, adicionar, remover),
            observe=lambda: _observe_correntes(kanoe, pasta_id, setor),
            expected=desired,
            handle=f"kanoe:pasta:{pasta_id}:organizacao:{setor}",
        )

    @catalogo.operacao(
        nome="pasta_definir_correntes",
        tags={"pasta", "corrente", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def pasta_definir_correntes(
        pasta_id: PastaId,
        corrente_ids: Annotated[
            tuple[CorrenteTematicaId, ...],
            Field(description="Conjunto exato de correntes temáticas a serem definidas na pasta"),
        ],
        setor: Annotated[
            SetorSigla | None,
            Field(
                default=None,
                description="Sigla do setor no Kanoê (se omitido, usa o setor configurado no pink.toml)",
            ),
        ] = None,
        confirmar_remocao: Annotated[
            bool,
            Field(
                default=False,
                description="Confirmação explícita obrigatória se a operação resultar na remoção de correntes existentes",
            ),
        ] = False,
    ) -> EfeitoEscrita:
        """Define o conjunto de correntes da pasta de forma idempotente.

        Substitui todas as correntes atuais pelas novas. Exige confirmar_remocao=True
        quando houver remoção de alguma corrente pré-existente.
        Por padrão, utiliza o setor configurado no repositório se setor não for fornecido.
        """
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="pasta_definir_correntes", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable

        setor_efetivo = setor
        if setor_efetivo is None:
            config = TomlSetor().ler()
            setor_efetivo = config.setor
        if not setor_efetivo:
            return Recusada(
                operacao="pasta_definir_correntes",
                motivo="setor não configurado no pink.toml nem fornecido explicitamente",
            )

        current_correntes = await observe_precondition(
            operacao="pasta_definir_correntes",
            observe=lambda: kanoe.pasta_correntes(pasta_id),
        )
        if isinstance(current_correntes, Recusada):
            return current_correntes

        desired_set = set(corrente_ids)
        current_set = set(current_correntes)
        adicionar = tuple(sorted(desired_set - current_set))
        remover = tuple(sorted(current_set - desired_set))

        if not adicionar and not remover:
            return Confirmada(
                operacao="pasta_definir_correntes",
                recurso_id=pasta_id,
                detalhe=f"as correntes observadas já correspondem exatamente ao desejado: {tuple(sorted(desired_set))}",
            )

        if remover and not confirmar_remocao:
            return Recusada(
                operacao="pasta_definir_correntes",
                motivo=(
                    f"a operação removeria a(s) corrente(s) {remover}. "
                    "Para confirmar a remoção, execute novamente com confirmar_remocao=True"
                ),
            )

        return await write_and_confirm(
            operacao="pasta_definir_correntes",
            recurso_id=pasta_id,
            write=lambda: kanoe.update_pasta_correntes(pasta_id, adicionar, remover),
            observe=lambda: kanoe.pasta_correntes(pasta_id),
            expected=tuple(sorted(desired_set)),
            handle=f"kanoe:pasta:{pasta_id}:correntes",
        )

    @catalogo.operacao(
        nome="tramitacao_receber",
        tags={"tramitacao", "write", "destructive"},
        efeito=DESTRUCTIVE,
    )
    async def tramitacao_receber(
        pasta_id: PastaId,
        tramitacao_id: TramitacaoId,
    ) -> EfeitoEscrita:
        """Recebe a tramitação pendente da pasta e confirma que aquele vínculo desapareceu."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="tramitacao_receber", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        pending = await observe_precondition(
            operacao="tramitacao_receber",
            observe=lambda: kanoe.tramitacao_pending(pasta_id, tramitacao_id),
        )
        if isinstance(pending, Recusada):
            return pending
        if not pending:
            return Recusada(
                operacao="tramitacao_receber",
                motivo=(
                    f"tramitação {tramitacao_id} não é a tramitação pendente observada "
                    f"para a pasta {pasta_id}"
                ),
            )
        return await write_and_confirm(
            operacao="tramitacao_receber",
            recurso_id=tramitacao_id,
            write=lambda: kanoe.receive_tramitacao(pasta_id, tramitacao_id),
            observe=lambda: kanoe.tramitacao_pending(pasta_id, tramitacao_id),
            expected=False,
            handle=f"kanoe:pasta:{pasta_id}:tramitacao:{tramitacao_id}",
        )

    @catalogo.operacao(
        nome="caixa_criar",
        tags={"caixa", "write"},
        efeito=WRITE,
    )
    async def caixa_criar(
        nome: TextoNaoVazio,
        setor_id: SetorId,
    ) -> EfeitoEscrita:
        """Cria uma caixa e confirma pelo catálogo pesquisável do próprio Kanoê."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="caixa_criar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        normalized = nome.strip().upper()
        handle = caixa_busca_handle(setor_id, normalized)
        before = await observe_precondition(
            operacao="caixa_criar",
            observe=lambda: kanoe.find_boxes(normalized, setor_id),
        )
        if isinstance(before, Recusada):
            return before
        exact_before = {box.id for box in before if box.nome.strip().upper() == normalized}
        if exact_before:
            return Recusada(
                operacao="caixa_criar",
                motivo=f"já existe caixa com nome {normalized!r} no setor {setor_id}",
            )
        try:
            await kanoe.create_box(normalized, setor_id)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="caixa_criar",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        try:
            after = await kanoe.find_boxes(normalized, setor_id)
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="caixa_criar",
                handle=handle,
                detalhe=f"criação aceita; a busca pós-escrita ainda não pôde ser observada: {exc}",
            )
        created = [
            box
            for box in after
            if box.nome.strip().upper() == normalized and box.id not in exact_before
        ]
        if len(created) == 1:
            return Confirmada(operacao="caixa_criar", recurso_id=created[0].id)
        if not created:
            return Submetida(
                operacao="caixa_criar",
                handle=handle,
                detalhe="criação aceita, mas a caixa ainda não apareceu na busca exata",
            )
        return Ambigua(
            operacao="caixa_criar",
            handle=handle,
            detalhe=(
                "a busca pós-escrita encontrou mais de uma nova caixa candidata; "
                f"ids={[box.id for box in created]!r}"
            ),
        )

    return catalogo


async def _observe_box(kanoe: Kanoe, pasta_id: int, setor: str) -> int | None:
    return (await kanoe.pasta_organization(pasta_id, setor)).caixa_id


async def _observe_correntes(kanoe: Kanoe, pasta_id: int, setor: str) -> tuple[int, ...]:
    del setor
    return await kanoe.pasta_correntes(pasta_id)
