"""Task write capabilities with explicit effect semantics."""

from __future__ import annotations

from dataclasses import replace

from datetime import date
from typing import Annotated, ClassVar, Literal

from pydantic import Field

from pink.catalogo import Catalogo, Efeito
from pink.domain_types import (
    EtiquetaId,
    ExpedienteId,
    PastaId,
    SetorId,
    TarefaId,
    TextoNaoVazio,
)
from pink.integrations import Kanoe
from pink.models import (
    Ambigua,
    Confirmada,
    EfeitoEscrita,
    EspecieTarefa,
    PinkModel,
    Recusada,
    Submetida,
)
from pink.system import Runtime
from pink.write_safety import (
    RemoteObservationFailure,
    RemoteWriteFailure,
    observe_precondition,
    refuse_if_unavailable,
    write_and_confirm,
)

WRITE = Efeito(
    leitura=False,
    destrutivo=False,
    idempotente=False,
    mundo_aberto=True,
)
IDEMPOTENT_WRITE = replace(WRITE, idempotente=True)
DESTRUCTIVE = replace(WRITE, destrutivo=True)
IDEMPOTENT_DESTRUCTIVE = replace(IDEMPOTENT_WRITE, destrutivo=True)


class _NovaTarefa(PinkModel):
    """Campos que o `POST /api/tarefas` do Kanoê aceita, iguais para toda espécie.

    A espécie não é campo: é `ClassVar` de cada intenção, resolvida pela
    boundary. O agente diz o que quer fazer; qual id o Kanoê grava é
    conhecimento de integração, e sai do schema publicado.
    """

    especie: ClassVar[EspecieTarefa]

    # `intencao` não tem default em variante nenhuma: sem default ela entra em
    # `required` no schema publicado, e o agente não consegue montar um objeto
    # sem tag -- que casaria com todas as variantes e seria recusado pelo
    # `oneOf`.
    pasta_id: PastaId
    prazo_inicio: Annotated[date, Field(description="Data inicial inclusiva do prazo")]
    prazo: Annotated[date, Field(description="Data final inclusiva do prazo")]
    setor_responsavel_id: SetorId
    comentario_inicial: Annotated[
        str | None,
        Field(
            description=(
                "Comentário que acompanha a tarefa desde a criação. "
                "Comentários posteriores são outra coisa: vão para `tarefa_comentar`."
            )
        ),
    ] = None
    expediente_id: Annotated[
        ExpedienteId | None,
        Field(
            description="Expediente que motiva a tarefa; omita quando a tarefa não responde a expediente"
        ),
    ] = None
    urgente: Annotated[bool, Field(description="Marca a tarefa como urgente")] = False


class TarefaPeticionar(_NovaTarefa):
    """Registra o compromisso de peticionar e seu prazo. Não prepara peça nenhuma.

    É o estado real da triagem: chega o expediente, abre-se a tarefa com o
    prazo, e a peça só existe dias depois. Uma tarefa Peticionar sem peça não é
    tarefa pela metade -- é trabalho ainda a fazer, registrado com prazo.

    Isto não peticiona nem protocola. Quando a peça existir, ela entra nesta
    mesma tarefa por `documento_enviar`. `peticionamento_preparar` é outra porta
    de entrada -- cria a própria tarefa já com a peça -- e não completa esta. O
    protocolo no PJe é `POST /api/mni/protocolar`, operação separada sobre
    documento, e nem esta criação nem a conclusão da tarefa o disparam.
    """

    especie: ClassVar[EspecieTarefa] = EspecieTarefa.PETICIONAR
    intencao: Literal["peticionar"]


class TarefaSimples(_NovaTarefa):
    """Trabalho interno sem comportamento especializado no Kanoê.

    É o caso genérico deliberado, não o default por omissão: 15.491 tarefas, e
    nenhuma coluna, tabela satélite ou fluxo que a distinga das demais. Não é
    coringa: Efetuar Cálculo, Agravo de Instrumento e Agendamento têm carga
    própria que esta rota não transporta, e não viram `simples` por falta de
    opção -- ficam fora até que a rota real de escrita seja observada.
    """

    especie: ClassVar[EspecieTarefa] = EspecieTarefa.SIMPLES
    intencao: Literal["simples"]


class TarefaJustificativa(_NovaTarefa):
    """Pede que se elabore uma justificativa, cujo destino de protocolo é o SEI.

    É a única das espécies ativas com `pje=0, sei=1, preferencial=SEI` em
    `especies_tarefas_tipo_protocolo`. Como nas demais, a espécie diz o trabalho
    a fazer, não o ato: protocolar continua sendo operação à parte.

    Uma minoria das justificativas (232 de 40.442, concentradas em poucos
    setores) carrega um trio de análise -- responsável, setor e data de
    submissão --, preenchido por uma tela do Kanoê que Pink não observa. Não é
    invariante da espécie, e por isso não está aqui.
    """

    especie: ClassVar[EspecieTarefa] = EspecieTarefa.JUSTIFICATIVA
    intencao: Literal["justificativa"]


class TarefaProtocolarNoSei(_NovaTarefa):
    """Pede a uma pessoa que protocole no SEI. NÃO protocola, e concluir também não.

    A espécie de tarefa e o ato que ela pede são coisas separadas no Kanoê. O
    protocolo no SEI é `POST /api/sei/protocolar`, uma operação própria sobre
    documento, que esta tarefa não dispara nem na criação nem na conclusão --
    concluir só junta o documento produzido ao volume da pasta, como em qualquer
    espécie.

    A medição sustenta a separação: em 2025 houve 19.609 tarefas desta espécie e
    zero protocolos SEI em `ratio.protocolos`; em 2026, 15.087 tarefas contra
    384 protocolos, nenhum deles com recibo. Criar esta tarefa registra trabalho
    a fazer; nunca conclua daí que o documento foi protocolado.
    """

    especie: ClassVar[EspecieTarefa] = EspecieTarefa.PROTOCOLAR_NO_SEI
    intencao: Literal["protocolar_no_sei"]


# `peticionar` e `peticionamento_preparar` não são duas portas para a mesma
# intenção: são dois momentos distintos, e ambos reais. Criar a tarefa registra
# o compromisso e o prazo, na triagem, quando a peça ainda não existe; preparar
# o peticionamento tem a peça como objeto, e por isso exige o arquivo.
#
# Vale para as duas o mesmo aviso: nem criar nem concluir protocola. O protocolo
# no PJe é `POST /api/mni/protocolar`, operação separada sobre documento.
#
# Efetuar Cálculo (379), Agravo de Instrumento (391) e Agendamento (505) ficam
# de fora, por motivo diferente: as três têm carga própria comprovada --
# matéria e risco; órgão julgador, assuntos, interessados e representantes;
# data e tipo de agendamento com evento no Google -- e nenhuma delas é
# preenchível por `POST /api/tarefas`. Oferecê-las aqui criaria a casca da
# tarefa sem o que a torna aquela tarefa.
NovaTarefa = Annotated[
    TarefaPeticionar | TarefaSimples | TarefaJustificativa | TarefaProtocolarNoSei,
    Field(discriminator="intencao"),
]


def build_tarefa_write_catalogo(runtime: Runtime) -> Catalogo:
    """Build task mutations over the semantic Kanoê boundary."""
    catalogo = Catalogo()

    def get_kanoe() -> Kanoe:
        return runtime.kanoe

    @catalogo.operacao(
        nome="tarefa_criar",
        tags={"tarefa", "write"},
        efeito=WRITE,
    )
    async def tarefa_criar(
        tarefa: Annotated[
            NovaTarefa,
            Field(
                description=(
                    "Intenção de domínio da tarefa. `peticionar` registra o compromisso "
                    "e o prazo, antes de a peça existir. Para completar a peça nesta "
                    "mesma tarefa, use `documento_enviar`. `peticionamento_preparar` é "
                    "outra porta de entrada: cria a própria tarefa já com a peça. "
                    "Nenhuma das duas protocola."
                )
            ),
        ],
    ) -> EfeitoEscrita:
        """Cria tarefa somente com uma janela de prazo temporalmente válida."""
        kanoe = get_kanoe()
        if tarefa.prazo < tarefa.prazo_inicio:
            return Recusada(
                operacao="tarefa_criar",
                motivo="prazo final não pode ser anterior ao início do prazo",
            )
        unavailable = await refuse_if_unavailable(kanoe, operacao="tarefa_criar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        try:
            tarefa_id = await kanoe.create_tarefa(
                pasta_id=tarefa.pasta_id,
                # Aqui, e só aqui, a intenção vira id de espécie.
                especie_id=tarefa.especie,
                prazo=tarefa.prazo.isoformat(),
                prazo_inicio=tarefa.prazo_inicio.isoformat(),
                # `comentario_inicial` -> `postIt`: a tradução mora aqui.
                post_it=tarefa.comentario_inicial or "",
                expediente_id=tarefa.expediente_id,
                setor_responsavel_id=tarefa.setor_responsavel_id,
                urgente=tarefa.urgente,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="tarefa_criar",
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise

        if tarefa_id is None:
            return Ambigua(
                operacao="tarefa_criar",
                detalhe="Kanoê aceitou a criação sem devolver a identidade da tarefa",
            )

        try:
            pending = await kanoe.tarefa_pending(tarefa_id)
        except RemoteObservationFailure as exc:
            return Submetida(
                operacao="tarefa_criar",
                handle=f"kanoe://tarefa/{tarefa_id}/estado",
                detalhe=f"tarefa {tarefa_id} criada, mas a reobservação falhou: {exc}",
            )
        if pending:
            return Confirmada(operacao="tarefa_criar", recurso_id=tarefa_id)
        return Submetida(
            operacao="tarefa_criar",
            handle=f"kanoe://tarefa/{tarefa_id}/estado",
            detalhe="Kanoê devolveu o ID, mas a tarefa ainda não apareceu na projeção de pendentes",
        )

    @catalogo.operacao(
        nome="tarefa_comentar",
        tags={"tarefa", "write"},
        efeito=WRITE,
    )
    async def tarefa_comentar(
        tarefa_id: TarefaId,
        texto: TextoNaoVazio,
    ) -> EfeitoEscrita:
        """Adiciona comentário; sem read-back Kanoê comprovado, sucesso fica `submetida`."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="tarefa_comentar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        handle = f"pink://tarefa/{tarefa_id}"
        try:
            await kanoe.add_tarefa_comment(tarefa_id, texto)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="tarefa_comentar",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        return Submetida(
            operacao="tarefa_comentar",
            handle=handle,
            detalhe="comentário aceito; releia o handle até o comentário aparecer na observação",
        )

    @catalogo.operacao(
        nome="tarefa_etiquetas_atualizar",
        tags={"tarefa", "etiqueta", "write", "destructive"},
        efeito=IDEMPOTENT_DESTRUCTIVE,
    )
    async def tarefa_etiquetas_atualizar(
        tarefa_id: TarefaId,
        etiqueta_ids: Annotated[
            tuple[EtiquetaId, ...],
            Field(description="Conjunto exato de etiquetas desejado após a atualização"),
        ],
        etiquetas_base: Annotated[
            tuple[EtiquetaId, ...],
            Field(
                description="Conjunto de etiquetas observado antes da edição; é uma precondition"
            ),
        ],
    ) -> EfeitoEscrita:
        """Atualiza etiquetas somente sobre a lista-base que ainda pode ser observada."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(
            kanoe, operacao="tarefa_etiquetas_atualizar", nome="Kanoê"
        )
        if unavailable is not None:
            return unavailable
        desired = tuple(sorted(set(etiqueta_ids)))
        expected_base = tuple(sorted(set(etiquetas_base)))
        observed = await observe_precondition(
            operacao="tarefa_etiquetas_atualizar",
            observe=lambda: kanoe.tarefa_etiquetas(tarefa_id),
        )
        if isinstance(observed, Recusada):
            return observed
        current = tuple(sorted(set(observed)))
        if current != expected_base:
            return Recusada(
                operacao="tarefa_etiquetas_atualizar",
                motivo=f"as etiquetas mudaram: esperado {expected_base!r}, observado {current!r}",
            )
        if current == desired:
            return Confirmada(
                operacao="tarefa_etiquetas_atualizar",
                recurso_id=tarefa_id,
                detalhe="o conjunto de etiquetas observado já corresponde exatamente ao desejado",
            )
        current_set = set(current)
        desired_set = set(desired)
        adicionar = tuple(sorted(desired_set - current_set))
        remover = tuple(sorted(current_set - desired_set))
        if remover:
            return Recusada(
                operacao="tarefa_etiquetas_atualizar",
                motivo=(
                    "remoção de etiqueta recusada: a API Kanoê conhecida só possui "
                    "POST comprovado para anexar; nenhum DELETE foi comprovado"
                ),
            )
        return await write_and_confirm(
            operacao="tarefa_etiquetas_atualizar",
            recurso_id=tarefa_id,
            write=lambda: kanoe.update_tarefa_etiquetas(tarefa_id, adicionar, ()),
            observe=lambda: kanoe.tarefa_etiquetas(tarefa_id),
            expected=desired,
            handle=f"pink://tarefa/{tarefa_id}",
        )

    @catalogo.operacao(
        nome="tarefa_alterar",
        tags={"tarefa", "write"},
        efeito=IDEMPOTENT_WRITE,
    )
    async def tarefa_alterar(
        tarefa_id: TarefaId,
        tarefa: Annotated[
            NovaTarefa,
            Field(
                description=(
                    "Estado desejado completo da tarefa (mesma forma de `tarefa_criar`): "
                    "o Kanoê altera pelo objeto inteiro, então leia a tarefa antes "
                    "(`tarefa_obter`) e reenvie com o que mudou"
                )
            ),
        ],
    ) -> EfeitoEscrita:
        """Altera uma tarefa (prazo, início, comentário, urgência, setor) e confere o que o Kanoê devolve.

        Medido ao vivo em 2026-09-10: `PUT /api/tarefas/alterar` recebe a lista
        com o mesmo corpo da criação mais o id e ecoa a tarefa alterada; o eco
        conferido com a intenção é a postcondition.
        """
        kanoe = get_kanoe()
        if tarefa.prazo < tarefa.prazo_inicio:
            return Recusada(
                operacao="tarefa_alterar",
                motivo="prazo final não pode ser anterior ao início do prazo",
            )
        unavailable = await refuse_if_unavailable(kanoe, operacao="tarefa_alterar", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        try:
            eco = await kanoe.update_tarefa(
                tarefa_id=tarefa_id,
                pasta_id=tarefa.pasta_id,
                especie_id=tarefa.especie,
                prazo=tarefa.prazo.isoformat(),
                prazo_inicio=tarefa.prazo_inicio.isoformat(),
                post_it=tarefa.comentario_inicial or "",
                expediente_id=tarefa.expediente_id,
                setor_responsavel_id=tarefa.setor_responsavel_id,
                urgente=tarefa.urgente,
            )
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="tarefa_alterar",
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        if eco is None:
            return Ambigua(
                operacao="tarefa_alterar",
                detalhe=(
                    "Kanoê aceitou a alteração sem eco material suficiente para provar "
                    "a postcondition; não repita a escrita às cegas"
                ),
            )
        return Ambigua(
            operacao="tarefa_alterar",
            detalhe=(
                "Kanoê aceitou a alteração e ecoou apenas parte do estado "
                f"(post_it={eco.post_it!r}, prazo={eco.prazo!r}, urgente={eco.urgente!r}); "
                "o eco não prova pasta, espécie, início do prazo, expediente e setor. "
                "Não repita a escrita às cegas."
            ),
        )

    @catalogo.operacao(
        nome="tarefa_excluir",
        tags={"tarefa", "write", "destructive"},
        efeito=DESTRUCTIVE,
    )
    async def tarefa_excluir(
        tarefa_id: TarefaId,
    ) -> EfeitoEscrita:
        """Exclui definitivamente; sem read-back de existência comprovado, sucesso fica `submetida`."""
        kanoe = get_kanoe()
        unavailable = await refuse_if_unavailable(kanoe, operacao="tarefa_excluir", nome="Kanoê")
        if unavailable is not None:
            return unavailable
        handle = f"pink://tarefa/{tarefa_id}"
        try:
            await kanoe.delete_tarefa(tarefa_id)
        except RemoteWriteFailure as exc:
            if exc.effect_may_have_occurred:
                return Ambigua(
                    operacao="tarefa_excluir",
                    handle=handle,
                    detalhe=f"efeito remoto incerto após falha de transporte: {exc}",
                )
            raise
        return Submetida(
            operacao="tarefa_excluir",
            handle=handle,
            detalhe="DELETE aceito; releia o handle até a tarefa aparecer como ausente",
        )

    return catalogo
