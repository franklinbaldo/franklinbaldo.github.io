"""Reusable primitive domain types for the Pink 0.8 public surface."""

from __future__ import annotations

import re
from typing import Annotated, Any

from pydantic import AfterValidator, Field

_CNJ_FORMATTED = re.compile(r"^[0-9]{7}-[0-9]{2}\.[0-9]{4}\.[0-9]\.[0-9]{2}\.[0-9]{4}$")


def normalizar_cnj(value: str) -> str:
    """Return one canonical CNJ representation from exactly the two public input shapes."""
    if len(value) == 20 and value.isascii() and value.isdigit():
        digits = value
    elif _CNJ_FORMATTED.fullmatch(value):
        digits = value.translate(str.maketrans("", "", "-."))
    else:
        raise ValueError("CNJ deve estar formatado ou conter exatamente 20 dígitos ASCII")
    return f"{digits[:7]}-{digits[7:9]}.{digits[9:13]}.{digits[13]}.{digits[14:16]}.{digits[16:]}"


def cnj_digits(value: str) -> str:
    """Return the transport/storage digits for an already validated CNJ."""
    return value.translate(str.maketrans("", "", "-."))


def cnj_storage_variants(value: str) -> tuple[str, str]:
    """Return the two physical representations known to exist in Caipora data."""
    canonical = normalizar_cnj(value)
    return canonical, cnj_digits(canonical)


def validar_texto_nao_branco(value: str) -> str:
    """Preserve authored strings while rejecting values made only of whitespace."""
    if not value.strip():
        raise ValueError("valor deve conter ao menos um caractere não branco")
    return value


TextoNaoVazio = Annotated[
    str,
    AfterValidator(validar_texto_nao_branco),
    Field(
        min_length=1,
        description="Texto que contém ao menos um caractere não branco; espaços significativos são preservados",
        examples=["Manifestação juntada aos autos."],
    ),
]

Cnj = Annotated[
    str,
    AfterValidator(normalizar_cnj),
    Field(
        description="Número CNJ do processo; aceita exatamente a forma formatada ou somente os 20 dígitos ASCII",
        examples=["0001234-56.2024.8.22.0001", "00012345620248220001"],
    ),
]

ProcessoId = Annotated[
    int,
    Field(gt=0, description="ID físico do processo judicial no Caipora", examples=[112233]),
]
PastaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da pasta no Kanoê", examples=[12345]),
]
TarefaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da tarefa no Kanoê", examples=[67890]),
]
ExpedienteId = Annotated[
    int,
    Field(gt=0, description="ID remoto do expediente no Kanoê", examples=[34567]),
]
DocumentoId = Annotated[
    int,
    Field(gt=0, description="ID remoto do documento no Kanoê/Caipora", examples=[45678]),
]
ComponenteDigitalId = Annotated[
    int,
    Field(
        gt=0, description="ID remoto do componente digital do documento no Kanoê", examples=[56789]
    ),
]
ProtocoloId = Annotated[
    int,
    Field(
        gt=0, description="ID remoto da tentativa de protocolo no Kanoê/Caipora", examples=[778899]
    ),
]
SetorId = Annotated[
    int,
    Field(gt=0, description="ID remoto do setor responsável no Kanoê", examples=[12]),
]
SetorSigla = Annotated[
    str,
    AfterValidator(validar_texto_nao_branco),
    Field(
        min_length=1,
        description="Sigla explícita e não vazia do setor no Kanoê",
        examples=["PGE-PAT"],
    ),
]
CaixaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da caixa organizacional no Kanoê", examples=[321]),
]
CorrenteTematicaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da corrente temática no Kanoê", examples=[654]),
]
TramitacaoId = Annotated[
    int,
    Field(gt=0, description="ID remoto da tramitação da pasta no Kanoê", examples=[987]),
]
EspecieTarefaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da espécie de tarefa no Kanoê", examples=[183]),
]
Limite = Annotated[
    int,
    Field(
        gt=0,
        description=(
            "Quantidade máxima de itens desta seleção, na ordem determinística da consulta. "
            "Obrigatório: listar é sempre uma seleção explicitamente limitada pelo caller, "
            "nunca 'todo o universo'"
        ),
        examples=[50],
    ),
]
EtiquetaId = Annotated[
    int,
    Field(gt=0, description="ID remoto da etiqueta de tarefa no Kanoê", examples=[42]),
]
ModeloMinutaId = Annotated[
    int,
    Field(gt=0, description="ID remoto do modelo de minuta no Kanoê", examples=[30]),
]
GoogleDocId = Annotated[
    str,
    AfterValidator(validar_texto_nao_branco),
    Field(
        min_length=1,
        description="ID opaco e não vazio do Google Doc que materializa a minuta",
        examples=["1AbCdEfGhIjKlMnOpQrStUvWxYz"],
    ),
]
RevisionId = Annotated[
    str,
    AfterValidator(validar_texto_nao_branco),
    Field(
        min_length=1,
        description="revisionId não vazio do Google Docs observado antes da edição; é uma precondition",
        examples=["rev-42"],
    ),
]

DatasetArtifactUri = Annotated[
    str,
    Field(
        pattern=r"^pink://artifact/[0-9a-f]{32}$",
        description="URI do dataset Parquet imutável owned pelo runtime Pink",
        examples=["pink://artifact/0123456789abcdef0123456789abcdef"],
    ),
]

FileArtifactUri = Annotated[
    str,
    Field(
        pattern=r"^pink://file/[0-9a-f]{32}$",
        description=(
            "URI de artifact binário owned pelo runtime Pink. Para um arquivo local, rode "
            "`pink arquivo-publicar <caminho>` e use o campo `uri` devolvido; não envie "
            "filesystem path nem base64 para a operação de domínio."
        ),
        examples=["pink://file/0123456789abcdef0123456789abcdef"],
    ),
]


KANOE_WEB_URL = "https://kanoe.sistemas.pge.ro.gov.br"


def kanoe_pasta_url(pasta_id: int) -> str:
    """Página da pasta na interface web do Kanoê -- é o id da pasta, não do processo judicial."""
    return f"{KANOE_WEB_URL}/admin/processo/{pasta_id}"


def com_url_da_pasta(valor: Any, *, campo: str = "kanoe_url") -> Any:
    """Before-validator: derive the pasta's web page from `pasta_id`; a divergent supplied value is an error."""
    if not isinstance(valor, dict):
        return valor
    pasta_id = valor.get("pasta_id")
    if pasta_id is None:
        return valor
    esperado = kanoe_pasta_url(pasta_id)
    fornecido = valor.get(campo)
    if fornecido is not None and fornecido != esperado:
        raise ValueError(f"{campo} diverge de pasta_id")
    return {**valor, campo: esperado}
